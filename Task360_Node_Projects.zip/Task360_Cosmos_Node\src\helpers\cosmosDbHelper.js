const { CosmosClient } = require("@azure/cosmos");
const { DefaultAzureCredential } = require("@azure/identity");

let _cosmosClient = null;
let _container = null;
let _initialized = false;

async function initialize() {
    if (_initialized) return;

    const endpoint = process.env.CosmosDbEndpoint;
    const databaseName = process.env.CosmosDbDatabaseName;
    const containerName = process.env.CosmosDbContainerName;

    if (!endpoint || !databaseName || !containerName) {
        throw new Error("CosmosDbEndpoint, CosmosDbDatabaseName, and CosmosDbContainerName must be set");
    }

    const credential = new DefaultAzureCredential();
    _cosmosClient = new CosmosClient({
        endpoint,
        aadCredentials: credential,
    });

    const { database } = await _cosmosClient.databases.createIfNotExists({ id: databaseName });
    const { container } = await database.containers.createIfNotExists({
        id: containerName,
        partitionKey: { paths: ["/sourceTaskId"] },
    });

    _container = container;
    _initialized = true;
}

function getContainer() {
    if (!_initialized) {
        throw new Error("CosmosDbHelper not initialized. Call initialize() first.");
    }
    return _container;
}

function getClient() {
    if (!_initialized) {
        throw new Error("CosmosDbHelper not initialized. Call initialize() first.");
    }
    return _cosmosClient;
}

module.exports = { initialize, getContainer, getClient };
