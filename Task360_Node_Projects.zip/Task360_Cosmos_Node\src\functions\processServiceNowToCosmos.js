const { app } = require("@azure/functions");
const cosmosDb = require("../helpers/cosmosDbHelper");

const MAX_PARALLELISM = 50;

/**
 * Build a unified Cosmos DB document from an incoming ServiceNow event.
 */
function buildDocument(data, recordType, category) {
    const sourceTaskId = data.sys_id;
    if (!sourceTaskId || sourceTaskId === "unknown") {
        return null;
    }

    const document = {
        id: sourceTaskId,
        sourceSystem: "ServiceNow",
        sourceTaskId,
        title: data.short_description || "",
        sourceRecordType: recordType,
    };

    // Map priority (ServiceNow 1-5 to 0-100 scale)
    if (data.priority != null) {
        const snPriority = parseInt(data.priority, 10);
        if (!isNaN(snPriority)) {
            const priorityMap = { 1: 100, 2: 85, 3: 65, 4: 40, 5: 20 };
            document.priority = priorityMap[snPriority] ?? 50;
            document.sourcePriority = String(snPriority);
        }
    }

    // Map status (ServiceNow state to normalized status)
    if (data.state != null) {
        const stateMap = {
            "1": "pending",
            "2": "in_progress",
            "3": "completed",
            "4": "cancelled",
            "6": "completed",
            "7": "completed",
        };
        document.status = stateMap[String(data.state)] || "pending";
        document.sourceStatus = String(data.state);
    }

    document.category = category;

    // Map user fields based on record type
    if (recordType === "sysapproval_approver") {
        document.assignedToEmail = data.approver_email || "";
        document.assignedToName = data.assigned_to || "";
        document.approverEmail = data.approver_email || "";
        document.requesterEmail = data.requested_for_email || "";
    } else if (recordType === "sc_request" || recordType === "sc_req_item") {
        document.assignedToEmail = data.assigned_to || "";
        document.assignedToName = data.assigned_to || "";
        document.requesterEmail = data.requested_for_email || "";
    } else {
        document.assignedToEmail = data.assigned_to_email || "";
        document.assignedToName = data.assigned_to || "";
    }

    // Map dates
    if (data.opened_at) {
        const d = new Date(data.opened_at);
        if (!isNaN(d.getTime())) document.createdDate = d.toISOString();
    }
    if (data.sys_updated_on) {
        const d = new Date(data.sys_updated_on);
        if (!isNaN(d.getTime())) document.lastModifiedDate = d.toISOString();
    }
    if (data.due_date) {
        const d = new Date(data.due_date);
        if (!isNaN(d.getTime())) document.dueDate = d.toISOString();
    }

    document.description = data.work_notes || data.short_description || "";

    // Create deep link to ServiceNow
    if (data.sys_id) {
        let tableName;
        if (recordType === "sysapproval_approver") tableName = "sysapproval_approver";
        else if (recordType === "sc_request") tableName = "sc_request";
        else if (recordType === "sc_req_item") tableName = "sc_req_item";
        else tableName = "task";
        document.deepLink = `https://dev186866.service-now.com/${tableName}.do?sys_id=${data.sys_id}`;
    }

    // Store raw JSON in metadata
    document.metadataJson = JSON.stringify(data);

    document._ts = Math.floor(Date.now() / 1000);

    return document;
}

/**
 * Process a batch of Event Hub messages into Cosmos DB with bounded parallelism.
 */
async function processEvents(messages, context, expectedRecordType, category) {
    context.log(`🚀 Function started processing ${messages.length} ${category} events from Event Hub (parallelism: ${MAX_PARALLELISM})`);

    await cosmosDb.initialize();
    const container = cosmosDb.getContainer();

    let successCount = 0;
    let failureCount = 0;

    // Use a simple concurrency limiter
    const pLimit = require("p-limit");
    const limit = pLimit(MAX_PARALLELISM);

    const tasks = messages.map((message) =>
        limit(async () => {
            let sourceTaskId = "unknown";
            try {
                const data = typeof message === "string" ? JSON.parse(message) : message;
                const recordType = data.record_type || expectedRecordType;
                if (!recordType) {
                    context.warn(`⚠️ No record_type found in event, skipping`);
                    failureCount++;
                    return;
                }

                sourceTaskId = recordType === "sysapproval_approver"
                    ? (data.sys_id || "unknown")
                    : (data.number || "unknown");

                const document = buildDocument(data, recordType, category);
                if (!document) {
                    context.warn(`⚠️ No valid sys_id found, skipping record | RecordType: ${recordType}`);
                    failureCount++;
                    return;
                }

                await container.items.upsert(document);
                successCount++;
            } catch (e) {
                failureCount++;
                context.error(`❌ Error processing ${category} event | SourceID: ${sourceTaskId} | Error: ${e.message}`);
            }
        })
    );

    await Promise.all(tasks);

    context.log(`✅ Batch complete | Category: ${category} | Success: ${successCount} | Failed: ${failureCount} | Total: ${messages.length}`);
}

// --- Event Hub Triggered Functions ---

app.eventHub("processServiceNowTask", {
    connection: "EventHubConnectionString",
    eventHubName: "task360-events",
    consumerGroup: "task360-workers",
    cardinality: "many",
    handler: async (messages, context) => {
        await processEvents(messages, context, "task", "Task");
    },
});

app.eventHub("processServiceNowRequest", {
    connection: "EventHubConnectionString",
    eventHubName: "task360-requests",
    consumerGroup: "task360-workers",
    cardinality: "many",
    handler: async (messages, context) => {
        await processEvents(messages, context, null, "Request");
    },
});

app.eventHub("processServiceNowApproval", {
    connection: "EventHubConnectionString",
    eventHubName: "task360-approvals",
    consumerGroup: "task360-workers",
    cardinality: "many",
    handler: async (messages, context) => {
        await processEvents(messages, context, "sysapproval_approver", "Approval");
    },
});
