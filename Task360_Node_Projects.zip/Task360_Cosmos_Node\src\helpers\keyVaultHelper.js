const { SecretClient } = require("@azure/keyvault-secrets");
const { DefaultAzureCredential } = require("@azure/identity");

let _secretClient = null;

function _ensureClient() {
    if (!_secretClient) {
        const keyVaultUrl = process.env.KeyVaultUrl;
        if (!keyVaultUrl) {
            throw new Error("KeyVaultUrl environment variable is not set");
        }
        const credential = new DefaultAzureCredential();
        _secretClient = new SecretClient(keyVaultUrl, credential);
    }
}

async function getSecret(secretName) {
    _ensureClient();
    try {
        const secret = await _secretClient.getSecret(secretName);
        return secret.value;
    } catch (e) {
        throw new Error(`Failed to retrieve secret '${secretName}' from Key Vault: ${e.message}`);
    }
}

module.exports = { getSecret };
