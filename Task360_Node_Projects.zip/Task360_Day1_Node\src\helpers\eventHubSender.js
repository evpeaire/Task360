const { EventHubProducerClient } = require("@azure/event-hubs");
const { DefaultAzureCredential } = require("@azure/identity");

// Event Hub routing based on record type
const EVENT_HUB_ROUTES = {
    task: "task360-events",
    sc_request: "task360-requests",
    sc_req_item: "task360-requests",
    sysapproval_approver: "task360-approvals",
};

// Task subtypes that should be routed to task360-events
const TASK_SUBTYPES = [
    "incident", "problem", "change_request", "change_task",
    "sc_task", "catalog_task", "follow_on_task", "sc_req_item",
    "demand", "enhancement", "defect", "incident_task",
];

class EventHubSender {
    constructor() {
        this.eventhubNamespace = process.env.EVENTHUB_NAMESPACE || "task360eventhubs.servicebus.windows.net";
        this.credential = new DefaultAzureCredential();
        this.producers = new Map();
    }

    _getClient(eventHubName) {
        if (!this.producers.has(eventHubName)) {
            const client = new EventHubProducerClient(
                this.eventhubNamespace,
                eventHubName,
                this.credential
            );
            this.producers.set(eventHubName, client);
            console.log(`Created Event Hub producer client for ${eventHubName}`);
        }
        return this.producers.get(eventHubName);
    }

    _routePayload(payload) {
        const recordType = (payload.record_type || "unknown").toLowerCase().replace(/ /g, "_");
        const sourceId = payload.sys_id || "unknown";

        let eventHubName = EVENT_HUB_ROUTES[recordType];

        if (!eventHubName && TASK_SUBTYPES.includes(recordType)) {
            eventHubName = "task360-events";
            console.log(`📍 Routing task subtype '${recordType}' to task360-events | SourceID: ${sourceId}`);
        }

        if (!eventHubName && recordType !== "sysapproval_approver") {
            eventHubName = "task360-events";
            console.warn(`⚠️ Unknown record_type '${recordType}' - defaulting to task360-events | SourceID: ${sourceId}`);
        }

        if (!eventHubName) {
            console.error(`❌ Cannot route record_type: ${recordType} | SourceID: ${sourceId}`);
        }

        return eventHubName;
    }

    async sendEvent(payload) {
        const eventHubName = this._routePayload(payload);
        if (!eventHubName) return false;

        const sourceId = payload.sys_id || "unknown";
        const recordType = payload.record_type || "unknown";

        try {
            const producer = this._getClient(eventHubName);
            const batch = await producer.createBatch();
            batch.tryAdd({ body: payload });
            await producer.sendBatch(batch);
            console.log(`✅ Sent event | Hub: ${eventHubName} | RecordType: ${recordType} | SourceID: ${sourceId}`);
            return true;
        } catch (e) {
            console.error(`❌ Event Hub send failed | Hub: ${eventHubName} | SourceID: ${sourceId} | Error: ${e.message}`);
            return false;
        }
    }

    async sendEventsBatch(payloads) {
        if (!payloads || payloads.length === 0) return { success: 0, failure: 0 };

        // Group payloads by destination Event Hub
        const hubGroups = new Map();
        let skipped = 0;

        for (const payload of payloads) {
            const hubName = this._routePayload(payload);
            if (hubName) {
                if (!hubGroups.has(hubName)) hubGroups.set(hubName, []);
                hubGroups.get(hubName).push(payload);
            } else {
                skipped++;
            }
        }

        console.log(`📦 Batching ${payloads.length} events across ${hubGroups.size} Event Hubs (skipped ${skipped} unroutable)`);

        let successCount = 0;
        let failureCount = skipped;

        for (const [hubName, group] of hubGroups) {
            try {
                const producer = this._getClient(hubName);
                let batch = await producer.createBatch();
                let batchesSent = 0;

                for (const payload of group) {
                    const added = batch.tryAdd({ body: payload });
                    if (!added) {
                        // Batch is full — send it and start a new one
                        if (batch.count > 0) {
                            await producer.sendBatch(batch);
                            successCount += batch.count;
                            batchesSent++;
                        }
                        batch = await producer.createBatch();
                        batch.tryAdd({ body: payload });
                    }
                }

                // Send remaining events
                if (batch.count > 0) {
                    await producer.sendBatch(batch);
                    successCount += batch.count;
                    batchesSent++;
                }

                console.log(`✅ Sent ${group.length} events to ${hubName} in ${batchesSent} batch(es)`);
            } catch (e) {
                failureCount += group.length;
                console.error(`❌ Batch send failed | Hub: ${hubName} | Count: ${group.length} | Error: ${e.message}`);
            }
        }

        return { success: successCount, failure: failureCount };
    }

    async closeAll() {
        for (const [name, producer] of this.producers) {
            try {
                await producer.close();
                console.log(`Closed producer for ${name}`);
            } catch (e) {
                console.error(`Error closing producer for ${name}: ${e.message}`);
            }
        }
        this.producers.clear();
    }
}

module.exports = { EventHubSender };
