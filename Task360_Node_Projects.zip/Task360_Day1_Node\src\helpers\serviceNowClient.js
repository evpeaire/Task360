const axios = require("axios");
const keyvault = require("./keyvaultHelper");

class ServiceNowClient {
    constructor() {
        this.instance = process.env.SERVICENOW_INSTANCE;
        this.username = process.env.SERVICENOW_USERNAME;
        this.clientId = process.env.SERVICENOW_CLIENT_ID;

        if (!this.instance) {
            throw new Error("SERVICENOW_INSTANCE environment variable is not set");
        }

        this.baseUrl = `https://${this.instance}/api/now`;
        this.password = null;
        this.clientSecret = null;
        this.authHeader = null;
    }

    async initialize() {
        // Get sensitive values from Key Vault
        try {
            this.password = await keyvault.getSecret("servicenow-password");
            console.log("✓ Retrieved ServiceNow password from Key Vault");
        } catch (e) {
            console.warn(`⚠️ Could not get ServiceNow password from Key Vault: ${e.message}`);
        }

        try {
            this.clientSecret = await keyvault.getSecret("servicenow-client-secret");
            console.log("✓ Retrieved ServiceNow client secret from Key Vault");
        } catch (e) {
            console.warn(`⚠️ Could not get ServiceNow client secret from Key Vault: ${e.message}`);
        }

        if (this.username && this.password) {
            // Basic auth
            const encoded = Buffer.from(`${this.username}:${this.password}`).toString("base64");
            this.authHeader = `Basic ${encoded}`;
        } else if (this.clientId && this.clientSecret) {
            await this._setupOAuth();
        } else {
            throw new Error("Either username/password or client_id/client_secret must be provided");
        }
    }

    async _setupOAuth() {
        const tokenUrl = `https://${this.instance}/oauth_token.do`;
        const response = await axios.post(tokenUrl, new URLSearchParams({
            grant_type: "client_credentials",
            client_id: this.clientId,
            client_secret: this.clientSecret,
        }).toString(), {
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
        });
        this.authHeader = `Bearer ${response.data.access_token}`;
    }

    async getRecentChanges(tableName, minutesAgo = 5, startTime = null) {
        let cutoffTime;
        if (startTime) {
            cutoffTime = startTime instanceof Date ? startTime : new Date(startTime);
            console.log(`🕐 Using custom start time: ${cutoffTime.toISOString()} | Table: ${tableName}`);
        } else {
            cutoffTime = new Date(Date.now() - minutesAgo * 60 * 1000);
            console.log(`🕐 Querying last ${minutesAgo} minutes | Table: ${tableName}`);
        }

        const cutoffStr = _formatDateForServiceNow(cutoffTime);
        const nowStr = _formatDateForServiceNow(new Date());

        let query;
        if (startTime) {
            query = `sys_created_on>=${cutoffStr}^sys_created_on<=${nowStr}^ORsys_updated_on>=${cutoffStr}^sys_updated_on<=${nowStr}`;
        } else {
            query = `sys_created_onONLast ${minutesAgo} minutes@javascript:gs.minutesAgoStart(${minutesAgo})@javascript:gs.minutesAgoEnd(0)^ORsys_updated_onONLast ${minutesAgo} minutes@javascript:gs.minutesAgoStart(${minutesAgo})@javascript:gs.minutesAgoEnd(0)`;
        }

        const url = `${this.baseUrl}/table/${tableName}`;
        const params = {
            sysparm_query: query,
            sysparm_display_value: "true",
            sysparm_exclude_reference_link: "true",
            sysparm_limit: 1000,
            sysparm_fields: _getFieldsForTable(tableName),
        };

        // Retry logic: attempt up to 2 times
        let lastError;
        for (let attempt = 1; attempt <= 2; attempt++) {
            try {
                if (attempt > 1) {
                    console.warn(`🔄 Retrying ServiceNow API call | Table: ${tableName} | Attempt: ${attempt}/2`);
                }
                console.log(`🌐 Calling ServiceNow API | Table: ${tableName} | Attempt: ${attempt}`);

                const response = await axios.get(url, {
                    params,
                    headers: { Authorization: this.authHeader },
                });

                const records = response.data.result || [];
                if (records.length > 0) {
                    console.log(`✅ Retrieved ${records.length} records | Table: ${tableName} | TimeWindow: ${minutesAgo}min`);
                    const first = records[0];
                    const last = records[records.length - 1];
                    console.log(`  First: ${first.number || first.sys_id} | Updated: ${first.sys_updated_on}`);
                    console.log(`  Last: ${last.number || last.sys_id} | Updated: ${last.sys_updated_on}`);
                } else {
                    console.log(`ℹ️ No records found | Table: ${tableName} | TimeWindow: ${minutesAgo}min`);
                }

                if (attempt > 1) console.log(`✓ Retry successful | Table: ${tableName}`);
                return records;
            } catch (e) {
                lastError = e;
                console.error(`❌ ServiceNow API error | Table: ${tableName} | Attempt: ${attempt}/2 | Error: ${e.message}`);
                if (attempt >= 2) {
                    console.error(`❌ All 2 attempts failed | Table: ${tableName}`);
                    throw e;
                }
            }
        }
        throw lastError;
    }

    async getRequestItem(documentId) {
        const url = `${this.baseUrl}/table/sc_req_item/${documentId}`;
        const params = {
            sysparm_display_value: "true",
            sysparm_fields: "short_description,request.requested_for.email",
        };
        const response = await axios.get(url, {
            params,
            headers: { Authorization: this.authHeader },
        });
        return response.data.result || {};
    }
}

function _formatDateForServiceNow(date) {
    const pad = (n) => String(n).padStart(2, "0");
    return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())} ${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())}`;
}

function _getFieldsForTable(tableName) {
    if (tableName === "task") {
        return "sys_id,number,short_description,state,priority,assigned_to,assigned_to.email,assignment_group,assignment_group.email,work_notes,sys_updated_on,category,subcategory,opened_at,sys_class_name";
    } else if (tableName === "sysapproval_approver") {
        return "sys_id,state,approver,approver.email,document_id,sys_updated_on,sys_created_on,source_table";
    }
    return "";
}

module.exports = { ServiceNowClient };
