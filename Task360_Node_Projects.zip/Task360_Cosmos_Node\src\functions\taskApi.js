const { app } = require("@azure/functions");
const cosmosDb = require("../helpers/cosmosDbHelper");

// --- GET /api/tasks ---
app.http("getTasks", {
    methods: ["GET"],
    authLevel: "function",
    route: "tasks",
    handler: async (request, context) => {
        context.log("📋 GetTasks API called");

        try {
            await cosmosDb.initialize();
            const container = cosmosDb.getContainer();

            const url = new URL(request.url);
            const status = url.searchParams.get("status");
            const category = url.searchParams.get("category");
            const assignedToEmail = url.searchParams.get("assignedToEmail");
            const search = url.searchParams.get("search");
            const top = parseInt(url.searchParams.get("top"), 10) || 50;

            const conditions = [];
            const parameters = [{ name: "@top", value: top }];

            if (status) {
                conditions.push("c.status = @status");
                parameters.push({ name: "@status", value: status });
            }
            if (category) {
                conditions.push("c.category = @category");
                parameters.push({ name: "@category", value: category });
            }
            if (assignedToEmail) {
                conditions.push("c.assignedToEmail = @assignedToEmail");
                parameters.push({ name: "@assignedToEmail", value: assignedToEmail });
            }
            if (search) {
                conditions.push("CONTAINS(LOWER(c.title), LOWER(@search))");
                parameters.push({ name: "@search", value: search });
            }

            let query = "SELECT TOP @top * FROM c";
            if (conditions.length > 0) {
                query += " WHERE " + conditions.join(" AND ");
            }
            query += " ORDER BY c.lastModifiedDate DESC";

            const { resources } = await container.items
                .query({ query, parameters }, { enableCrossPartitionQuery: true })
                .fetchAll();

            context.log(`✅ GetTasks returned ${resources.length} results`);

            return {
                jsonBody: { count: resources.length, tasks: resources },
            };
        } catch (e) {
            context.error(`❌ Error in GetTasks: ${e.message}`);
            return { status: 500 };
        }
    },
});

// --- GET /api/tasks/item/{id} ---
app.http("getTaskById", {
    methods: ["GET"],
    authLevel: "function",
    route: "tasks/item/{id}",
    handler: async (request, context) => {
        const id = request.params.id;
        context.log(`🔍 GetTaskById API called | ID: ${id}`);

        try {
            await cosmosDb.initialize();
            const container = cosmosDb.getContainer();

            const { resources } = await container.items
                .query({
                    query: "SELECT * FROM c WHERE c.id = @id",
                    parameters: [{ name: "@id", value: id }],
                }, { enableCrossPartitionQuery: true })
                .fetchAll();

            if (resources.length > 0) {
                context.log(`✅ Found task | ID: ${id}`);
                return { jsonBody: resources[0] };
            }

            context.warn(`⚠️ Task not found | ID: ${id}`);
            return {
                status: 404,
                jsonBody: { message: `Task with id '${id}' not found` },
            };
        } catch (e) {
            context.error(`❌ Error in GetTaskById | ID: ${id}: ${e.message}`);
            return { status: 500 };
        }
    },
});

// --- POST /api/tasks/search ---
app.http("searchTasks", {
    methods: ["POST"],
    authLevel: "function",
    route: "tasks/search",
    handler: async (request, context) => {
        context.log("🔎 SearchTasks API called");

        try {
            const body = await request.json();

            await cosmosDb.initialize();
            const container = cosmosDb.getContainer();

            const conditions = [];
            const parameters = [];
            const top = body.top || 50;
            parameters.push({ name: "@top", value: top });

            if (body.query) {
                conditions.push("(CONTAINS(LOWER(c.title), LOWER(@search)) OR CONTAINS(LOWER(c.description), LOWER(@search)) OR CONTAINS(LOWER(c.sourceTaskId), LOWER(@search)))");
                parameters.push({ name: "@search", value: body.query });
            }
            if (body.status) {
                conditions.push("c.status = @status");
                parameters.push({ name: "@status", value: body.status });
            }
            if (body.category) {
                conditions.push("c.category = @category");
                parameters.push({ name: "@category", value: body.category });
            }
            if (body.assignedToEmail) {
                conditions.push("c.assignedToEmail = @assignedToEmail");
                parameters.push({ name: "@assignedToEmail", value: body.assignedToEmail });
            }

            let query = "SELECT TOP @top * FROM c";
            if (conditions.length > 0) {
                query += " WHERE " + conditions.join(" AND ");
            }
            query += " ORDER BY c.lastModifiedDate DESC";

            const { resources } = await container.items
                .query({ query, parameters }, { enableCrossPartitionQuery: true })
                .fetchAll();

            context.log(`✅ SearchTasks returned ${resources.length} results`);

            return {
                jsonBody: { count: resources.length, tasks: resources },
            };
        } catch (e) {
            context.error(`❌ Error in SearchTasks: ${e.message}`);
            return { status: 500 };
        }
    },
});

// --- GET /api/tasks/summary ---
app.http("getTaskSummary", {
    methods: ["GET"],
    authLevel: "function",
    route: "tasks/summary",
    handler: async (request, context) => {
        context.log("📊 GetTaskSummary API called");

        try {
            await cosmosDb.initialize();
            const container = cosmosDb.getContainer();

            const { resources: statusResults } = await container.items
                .query("SELECT c.status, COUNT(1) as count FROM c GROUP BY c.status", { enableCrossPartitionQuery: true })
                .fetchAll();

            const { resources: categoryResults } = await container.items
                .query("SELECT c.category, COUNT(1) as count FROM c GROUP BY c.category", { enableCrossPartitionQuery: true })
                .fetchAll();

            const { resources: totalResults } = await container.items
                .query("SELECT VALUE COUNT(1) FROM c", { enableCrossPartitionQuery: true })
                .fetchAll();

            const totalCount = totalResults[0] || 0;

            context.log(`✅ GetTaskSummary complete | Total: ${totalCount}`);

            return {
                jsonBody: {
                    totalTasks: totalCount,
                    byStatus: statusResults,
                    byCategory: categoryResults,
                },
            };
        } catch (e) {
            context.error(`❌ Error in GetTaskSummary: ${e.message}`);
            return { status: 500 };
        }
    },
});
