const { SecretClient } = require("@azure/keyvault-secrets");
const { DefaultAzureCredential } = require("@azure/identity");

let _client = null;
const _cache = new Map();

function _ensureClient() {
    if (!_client) {
        const keyvaultUrl = process.env.KEYVAULT_URL;
        if (!keyvaultUrl) {
            throw new Error("KEYVAULT_URL environment variable is not set");
        }
        const credential = new DefaultAzureCredential();
        _client = new SecretClient(keyvaultUrl, credential);
        console.log(`✓ Key Vault client initialized: ${keyvaultUrl}`);
    }
}

async function getSecret(secretName) {
    if (_cache.has(secretName)) {
        return _cache.get(secretName);
    }

    _ensureClient();

    const secret = await _client.getSecret(secretName);
    const value = secret.value;
    _cache.set(secretName, value);
    console.log(`✓ Retrieved secret from Key Vault: ${secretName}`);
    return value;
}

module.exports = { getSecret };
