const { app } = require("@azure/functions");
const { ServiceNowClient } = require("../helpers/serviceNowClient");
const { EventHubSender } = require("../helpers/eventHubSender");
const syncTracker = require("../helpers/cosmosSyncTracker");
const { formatTaskPayload, formatApprovalPayload } = require("../helpers/payloadFormatters");

app.timer("servicenowSyncTimer", {
    // Every minute (NCRONTAB: second minute hour day month weekday)
    schedule: "0 * * * * *",
    runOnStartup: false,
    handler: async (myTimer, context) => {
        const utcTimestamp = new Date().toISOString();

        if (myTimer.isPastDue) {
            context.warn("⚠️ The timer is past due!");
        }

        context.log(`🚀 ServiceNow sync function started | Timestamp: ${utcTimestamp}`);

        let eventHubSender = null;
        let totalRecords = 0;
        let syncSuccessful = false;
        let errorMessage = null;
        let trackerAvailable = false;

        try {
            // Initialize clients
            context.log("🔧 Initializing clients...");
            const snClient = new ServiceNowClient();
            await snClient.initialize();
            context.log("✓ ServiceNow client initialized");

            eventHubSender = new EventHubSender();
            context.log("✓ Event Hub sender initialized");

            // Initialize Cosmos DB sync tracker
            try {
                await syncTracker.initialize();
                trackerAvailable = true;
                context.log("✓ Cosmos DB sync tracker initialized");
            } catch (e) {
                context.warn(`⚠️ Could not initialize sync tracker: ${e.message}. Proceeding without sync tracking.`);
            }

            // Get the last successful sync time from Cosmos DB
            let lastSyncTime = null;
            if (trackerAvailable) {
                context.log("🔍 Checking for last successful sync time...");
                lastSyncTime = await syncTracker.getLastSuccessfulSync("ServiceNow");
            }

            let taskRecords, approvalRecords;

            if (lastSyncTime) {
                context.log(`📅 Using last successful sync time: ${lastSyncTime.toISOString()}`);
                context.log("📊 Fetching changes from task table since last sync...");
                taskRecords = await snClient.getRecentChanges("task", 5, lastSyncTime);
                context.log("📊 Fetching changes from sysapproval_approver table since last sync...");
                approvalRecords = await snClient.getRecentChanges("sysapproval_approver", 5, lastSyncTime);
            } else {
                context.log("📅 No previous successful sync found - using default 5 minute window");
                context.log("📊 Fetching changes from task table...");
                taskRecords = await snClient.getRecentChanges("task", 5);
                context.log("📊 Fetching changes from sysapproval_approver table...");
                approvalRecords = await snClient.getRecentChanges("sysapproval_approver", 5);
            }

            // Process task records
            context.log(`🔄 Processing task records | Count: ${taskRecords.length}`);
            const taskPayloads = [];
            let taskFormatErrors = 0;
            for (const record of taskRecords) {
                try {
                    taskPayloads.push(formatTaskPayload(record));
                } catch (e) {
                    taskFormatErrors++;
                    context.error(`❌ Error formatting task record | SourceID: ${record.sys_id || "unknown"} | Error: ${e.message}`);
                }
            }
            const taskResult = await eventHubSender.sendEventsBatch(taskPayloads);
            context.log(`✅ Task processing complete | Success: ${taskResult.success} | Failed: ${taskFormatErrors + taskResult.failure} | Total: ${taskRecords.length}`);

            // Process approval records
            context.log(`🔄 Processing approval records | Count: ${approvalRecords.length}`);
            const approvalPayloads = [];
            let approvalFormatErrors = 0;
            for (const record of approvalRecords) {
                try {
                    approvalPayloads.push(await formatApprovalPayload(record, snClient));
                } catch (e) {
                    approvalFormatErrors++;
                    context.error(`❌ Error formatting approval record | SourceID: ${record.sys_id || "unknown"} | Error: ${e.message}`);
                }
            }
            const approvalResult = await eventHubSender.sendEventsBatch(approvalPayloads);
            context.log(`✅ Approval processing complete | Success: ${approvalResult.success} | Failed: ${approvalFormatErrors + approvalResult.failure} | Total: ${approvalRecords.length}`);

            totalRecords = taskRecords.length + approvalRecords.length;
            syncSuccessful = true;

            context.log(`✅ ServiceNow sync completed successfully | Tasks: ${taskRecords.length} | Approvals: ${approvalRecords.length} | Total: ${totalRecords}`);
        } catch (e) {
            syncSuccessful = false;
            errorMessage = e.message;
            context.error(`❌ Error during ServiceNow sync: ${errorMessage}`);
        } finally {
            // Log the sync attempt to Cosmos DB
            if (trackerAvailable) {
                try {
                    context.log("💾 Logging sync attempt to Cosmos DB...");
                    await syncTracker.logSyncAttempt("ServiceNow", syncSuccessful, totalRecords, errorMessage);
                    context.log("✓ Sync attempt logged to Cosmos DB");
                } catch (e) {
                    context.error(`❌ Failed to log sync attempt to Cosmos DB: ${e.message}`);
                }
            }

            // Clean up Event Hub connections
            if (eventHubSender) {
                try {
                    await eventHubSender.closeAll();
                    context.log("✓ Event Hub connections closed");
                } catch (e) {
                    context.warn(`⚠️ Error closing Event Hub connections: ${e.message}`);
                }
            }

            // If sync failed, re-throw after logging
            if (!syncSuccessful && errorMessage) {
                throw new Error(`ServiceNow sync failed: ${errorMessage}`);
            }
        }
    },
});
