const { CosmosClient } = require("@azure/cosmos");
const { DefaultAzureCredential } = require("@azure/identity");
const { v4: uuidv4 } = require("uuid");

let _container = null;
let _initialized = false;

async function initialize() {
    if (_initialized) return;

    const endpoint = process.env.CosmosDbEndpoint;
    const databaseName = process.env.CosmosDbDatabaseName || "Task360DB";
    const containerName = process.env.CosmosDbSyncContainerName || "SyncTracking";

    if (!endpoint) {
        throw new Error("CosmosDbEndpoint environment variable is not set");
    }

    const credential = new DefaultAzureCredential();
    const client = new CosmosClient({ endpoint, aadCredentials: credential });

    const { database } = await client.databases.createIfNotExists({ id: databaseName });
    const { container } = await database.containers.createIfNotExists({
        id: containerName,
        partitionKey: { paths: ["/sourceSystem"] },
    });

    _container = container;
    _initialized = true;
    console.log(`✓ Cosmos DB sync tracker initialized | Endpoint: ${endpoint} | Container: ${containerName}`);
}

async function getLastSuccessfulSync(sourceSystem = "ServiceNow") {
    await initialize();

    const querySpec = {
        query: "SELECT TOP 1 c.syncTime FROM c WHERE c.sourceSystem = @source AND c.success = true ORDER BY c.syncTime DESC",
        parameters: [{ name: "@source", value: sourceSystem }],
    };

    const { resources } = await _container.items
        .query(querySpec, { partitionKey: sourceSystem })
        .fetchAll();

    if (resources.length > 0 && resources[0].syncTime) {
        const syncTime = new Date(resources[0].syncTime);
        console.log(`Last successful sync was at: ${syncTime.toISOString()}`);
        return syncTime;
    }

    console.log("No previous successful sync found");
    return null;
}

async function logSyncAttempt(sourceSystem, success, recordCount, errorMessage = null) {
    try {
        await initialize();

        const syncTime = new Date().toISOString();
        const document = {
            id: uuidv4(),
            sourceSystem,
            syncTime,
            success,
            recordCount,
            label: `${sourceSystem} Sync - ${syncTime}`,
        };

        if (errorMessage) {
            document.errorMessage = errorMessage.substring(0, 500);
        }

        await _container.items.upsert(document);
        console.log(`Successfully logged sync attempt to Cosmos DB: success=${success}, records=${recordCount}`);
        return true;
    } catch (e) {
        console.error(`Error logging sync attempt to Cosmos DB: ${e.message}`);
        return false;
    }
}

module.exports = { initialize, getLastSuccessfulSync, logSyncAttempt };
