/**
 * Format a task record according to the ServiceNow business rule structure.
 */
function formatTaskPayload(record) {
    const recordType = typeof record.sys_class_name === "object"
        ? (record.sys_class_name?.value || "task")
        : (record.sys_class_name || "task");

    const assignedToEmail = typeof record["assigned_to.email"] === "object"
        ? (record["assigned_to.email"]?.display_value || "")
        : (record["assigned_to.email"] || "");

    const assignmentGroupEmail = typeof record["assignment_group.email"] === "object"
        ? (record["assignment_group.email"]?.display_value || "")
        : (record["assignment_group.email"] || "");

    const payload = {
        record_type: recordType,
        sys_id: record.sys_id || "",
        number: record.number || "",
        short_description: record.short_description || "",
        state: record.state || "",
        priority: record.priority || "",
        assigned_to: typeof record.assigned_to === "object"
            ? (record.assigned_to?.display_value || "")
            : (record.assigned_to || ""),
        assigned_to_email: assignedToEmail,
        assignment_group: typeof record.assignment_group === "object"
            ? (record.assignment_group?.display_value || "")
            : (record.assignment_group || ""),
        assignment_group_email: assignmentGroupEmail,
        work_notes: record.work_notes || "",
        sys_updated_on: record.sys_updated_on || "",
        category: record.category || "",
        subcategory: record.subcategory || "",
        opened_at: record.opened_at || "",
    };

    // Add email addresses for requests
    if (["sc_request", "sc_req_item"].includes(recordType)) {
        const requestedFor = record.requested_for;
        payload.requested_for_email = typeof requestedFor === "object"
            ? (requestedFor?.email || "")
            : "";
    }

    return payload;
}

/**
 * Format an approval record according to the ServiceNow business rule structure.
 */
async function formatApprovalPayload(record, snClient) {
    const approverDisplay = typeof record.approver === "object"
        ? (record.approver?.display_value || "")
        : (record.approver || "");

    const approverEmail = typeof record["approver.email"] === "object"
        ? (record["approver.email"]?.display_value || "")
        : (record["approver.email"] || "");

    const documentId = record.document_id || "";
    const sourceTable = record.source_table || "";

    const payload = {
        record_type: "sysapproval_approver",
        sys_id: record.sys_id || "",
        state: record.state || "",
        approver_email: approverEmail,
        assigned_to: approverDisplay,
        document_id: documentId,
        short_description: "",
        requested_for_email: "",
        sys_updated_on: record.sys_updated_on || "",
        opened_at: record.sys_created_on || "",
    };

    // Get requested_for email from the linked request if source is sc_req_item
    if (sourceTable === "sc_req_item" && documentId) {
        try {
            const reqItem = await snClient.getRequestItem(documentId);
            payload.short_description = reqItem.short_description || "";
            const reqEmail = reqItem["request.requested_for.email"];
            if (typeof reqEmail === "object") {
                payload.requested_for_email = reqEmail?.display_value || "";
            } else {
                payload.requested_for_email = reqEmail ? String(reqEmail) : "";
            }
        } catch (e) {
            console.warn(`Could not fetch related sc_req_item data: ${e.message}`);
        }
    }

    return payload;
}

module.exports = { formatTaskPayload, formatApprovalPayload };
