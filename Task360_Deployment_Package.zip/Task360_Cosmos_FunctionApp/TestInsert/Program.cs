﻿using Microsoft.Azure.Cosmos;
using Azure.Identity;
using Newtonsoft.Json.Linq;

Console.WriteLine("Creating test document in Cosmos DB...");

var endpoint = "https://task360cosmosdb.documents.azure.com:443/";
var key = "NHNXHtyjC2pajWHfSQRuYFTgguNhyLJQK90VHlgfDCwQUEIVXG0QIruXMg2QSV94w1RSeHTe9L3eACDb3k1hWg==";

using var client = new CosmosClient(endpoint, key);

var database = client.GetDatabase("Task360DB");
var container = database.GetContainer("Tasks");

var testDocument = new JObject
{
    ["id"] = "test-123",
    ["sourceSystem"] = "ServiceNow",
    ["sourceTaskId"] = "test-sys-id-001",
    ["title"] = "Sample Production Bug Fix",
    ["sourceRecordType"] = "task",
    ["category"] = "Task",
    ["priority"] = 85,
    ["sourcePriority"] = "2",
    ["status"] = "in_progress",
    ["sourceStatus"] = "2",
    ["assignedToEmail"] = "john.doe@example.com",
    ["assignedToName"] = "John Doe",
    ["description"] = "Critical production bug affecting customer orders. Need immediate attention.",
    ["createdDate"] = DateTime.Parse("2026-02-04T10:30:00Z"),
    ["lastModifiedDate"] = DateTime.Parse("2026-02-04T14:00:00Z"),
    ["dueDate"] = DateTime.Parse("2026-02-05T17:00:00Z"),
    ["deepLink"] = "https://dev186866.service-now.com/task.do?sys_id=test-sys-id-001",
    ["metadataJson"] = "{\"sys_id\":\"test-sys-id-001\",\"number\":\"TASK0001234\",\"short_description\":\"Sample Production Bug Fix\"}",
    ["_ts"] = DateTimeOffset.UtcNow.ToUnixTimeSeconds()
};

var partitionKey = new PartitionKey("test-sys-id-001");

try
{
    var response = await container.CreateItemAsync(testDocument, partitionKey);
    Console.WriteLine($"✅ Test document created successfully!");
    Console.WriteLine($"Document ID: {response.Resource["id"]}");
    Console.WriteLine($"Status Code: {response.StatusCode}");
    Console.WriteLine($"\n✨ Go to Azure Portal Data Explorer and refresh - you should see all fields now!");
}
catch (CosmosException ex)
{
    Console.WriteLine($"❌ Error: {ex.StatusCode} - {ex.Message}");
}
