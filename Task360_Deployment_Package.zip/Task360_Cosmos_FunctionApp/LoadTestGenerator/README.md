# Task360 Load Test Generator

Stress-tests the Task360 pipeline at **both bottlenecks** — Event Hub ingestion and Cosmos DB writes — using synthetic ServiceNow-style data. Bypasses the ServiceNow demo tenant entirely.

## Three Test Modes

```
┌──────────────────────────────────────────────────────────────────────────┐
│                                                                          │
│  MODE: eventhub (full pipeline)                                          │
│  LoadTestGenerator ──▶ Event Hub ──▶ Azure Functions ──▶ Cosmos DB       │
│  (batched sends)       (queued)      (batches of 100)   (1-at-a-time)   │
│                                                                          │
│  MODE: pipeline (simulate real Python code bottleneck)                   │
│  LoadTestGenerator ──▶ Event Hub ──▶ Azure Functions ──▶ Cosmos DB       │
│  (1-at-a-time sends)   (queued)      (batches of 100)   (1-at-a-time)   │
│                                                                          │
│  MODE: cosmos (isolate DB bottleneck)                                    │
│  LoadTestGenerator ──────────────────────────────────▶ Cosmos DB         │
│  (sequential vs parallel)                               (direct writes)  │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```
│                      │     │  • task360-requests   │     │  (unchanged)         │
│  Generates 5k-10k   │     │  • task360-approvals  │     │                      │
│  fake tasks per      │     └──────────────────────┘     └──────────┬───────────┘
│  batch               │                                             │
└─────────────────────┘                                             ▼
                                                          ┌──────────────────────┐
                                                          │   Cosmos DB          │
                                                          │   Task360DB/Tasks    │
                                                          └──────────────────────┘
```

**No changes to your existing pipeline.** The generator produces JSON payloads with the exact same schema that ServiceNow sends (sys_id, number, short_description, priority, state, assigned_to_email, etc.), so the downstream functions process them identically.

## Prerequisites

- .NET 6.0 SDK
- Azure CLI logged in (`az login`) — uses `DefaultAzureCredential`
- Event Hub namespace: `task360eventhubs.servicebus.windows.net`
- Role: **Azure Event Hubs Data Sender** (for eventhub/pipeline modes)
- Role: **Cosmos DB Data Contributor** on `task360cosmosdb` (for cosmos mode)

## Quick Start

```powershell
cd LoadTestGenerator
dotnet restore
```

### Mode 1: eventhub (full pipeline test)

Sends batched events into Event Hub. Your deployed Functions pick them up and write to Cosmos DB.

```powershell
# Single burst of 5,000 events
dotnet run -- --mode eventhub 5000 1 1

# 7,500 events every 5 min, runs forever (Ctrl+C to stop) — this is the default
dotnet run

# 10,000 events every 5 min for 1 hour (12 batches)
dotnet run -- --mode eventhub 10000 5 12
```

### Mode 2: cosmos (isolate DB bottleneck)

Writes directly to Cosmos DB, bypassing Event Hub. Runs sequential first (simulating your real function's one-at-a-time writes), then parallel if you specify concurrency > 1. Shows you the speedup comparison.

```powershell
# 5,000 docs sequential only (simulates current function behavior)
dotnet run -- --mode cosmos 5000

# 5,000 docs sequential THEN parallel with 50 writers (shows speedup)
dotnet run -- --mode cosmos 5000 50

# 10,000 docs with 100 concurrent writers (stress test Cosmos RU/s limits)
dotnet run -- --mode cosmos 10000 100
```

### Mode 3: pipeline (simulate real Python code bottleneck)

Sends events one-at-a-time, exactly like your real Python `send_event()` does. Then sends the same volume batched and shows you the difference.

```powershell
# 1,000 events one-at-a-time (shows the real bottleneck)
dotnet run -- --mode pipeline 1000

# 500 events for a quick comparison
dotnet run -- --mode pipeline 500
```

## Command-Line Arguments

```text
dotnet run -- --mode eventhub [batchSize=7500] [intervalMin=5] [totalBatches=0]
dotnet run -- --mode cosmos   [batchSize=5000] [concurrency=1]
dotnet run -- --mode pipeline [batchSize=1000]
```

## Event Distribution

Each batch is split to mimic realistic ServiceNow traffic:

| Category | % | Event Hub | Record Types |
|----------|---|-----------|--------------|
| Tasks | 60% | task360-events | incident, change_request, problem, sc_task |
| Requests | 25% | task360-requests | sc_request, sc_req_item |
| Approvals | 15% | task360-approvals | sysapproval_approver |

## What Gets Generated

Each synthetic event includes all the fields your `ProcessServiceNowToCosmos` function expects:

- `sys_id` — unique 32-char hex (matches ServiceNow format)
- `number` — realistic prefix (INC, CHG, PRB, REQ, RITM, SCTASK)
- `short_description` — from a pool of 30 realistic IT descriptions
- `priority` — 1-5, weighted distribution
- `state` — 1/2/3/4/7, weighted to match real patterns (30% new, 35% in-progress, etc.)
- `assigned_to_email` / `approver_email` — realistic `first.last@barclays.com`
- `opened_at`, `sys_updated_on`, `due_date` — realistic timestamps
- `work_notes` — tagged with `[Load Test]` so you can identify/clean up synthetic data

## Identifying & Cleaning Up Test Data

All synthetic records have `[Load Test]` in their `work_notes` / `description` field. To clean up after testing:

```sql
-- Cosmos DB query to find all load test records
SELECT * FROM c WHERE CONTAINS(c.description, "[Load Test]")

-- Count them
SELECT VALUE COUNT(1) FROM c WHERE CONTAINS(c.description, "[Load Test]")
```

You can delete them via the Cosmos DB Data Explorer or a script.

## Tuning for Your Scenario

### Test Cosmos DB throughput
Increase batch size and reduce interval:
```powershell
dotnet run -- 10000 1 10    # 10k events every minute for 10 minutes
```

### Test sustained load over time
```powershell
dotnet run -- 7500 5 0      # 7.5k every 5 min, runs indefinitely
```

### Test burst handling
```powershell
dotnet run -- 10000 1 1     # Single burst of 10k
```

## Monitoring

While the load test runs, monitor these:

1. **Event Hub metrics** (Azure Portal → Event Hub namespace → Metrics)
   - Incoming Messages, Throttled Requests, Outgoing Messages

2. **Function App** (Azure Portal → Function App → Monitor)
   - Execution count, duration, failures

3. **Cosmos DB** (Azure Portal → Cosmos DB → Metrics)
   - Request Units consumed, document count, throttled requests (429s)

4. **Application Insights** (if configured)
   - Live Metrics Stream for real-time view
