using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Azure.Identity;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json.Linq;

namespace LoadTestGenerator
{
    /// <summary>
    /// Writes synthetic task documents directly to Cosmos DB,
    /// replicating the exact same document structure and logic
    /// that ProcessServiceNowToCosmos uses.
    /// 
    /// This lets you stress-test Cosmos DB throughput independently
    /// from Event Hub, and compare sequential vs parallel writes.
    /// </summary>
    public class CosmosDbLoadTester : IAsyncDisposable
    {
        private readonly CosmosClient _client;
        private Container _container;
        private readonly string _endpoint;
        private readonly string _databaseName;
        private readonly string _containerName;

        public CosmosDbLoadTester(string endpoint, string databaseName, string containerName)
        {
            _endpoint = endpoint;
            _databaseName = databaseName;
            _containerName = containerName;

            var credential = new DefaultAzureCredential();
            _client = new CosmosClient(endpoint, credential, new CosmosClientOptions
            {
                // Allow bulk execution for parallel writes
                AllowBulkExecution = true,
                // Connection settings tuned for load testing
                MaxRetryAttemptsOnRateLimitedRequests = 10,
                MaxRetryWaitTimeOnRateLimitedRequests = TimeSpan.FromSeconds(30)
            });
        }

        public async Task InitializeAsync()
        {
            var database = _client.GetDatabase(_databaseName);
            _container = database.GetContainer(_containerName);
        }

        /// <summary>
        /// Counts documents matching the load test marker in Cosmos DB.
        /// Uses COUNT aggregate to minimize RU cost.
        /// </summary>
        public async Task<int> CountLoadTestDocumentsAsync(CancellationToken ct = default)
        {
            var query = new QueryDefinition(
                "SELECT VALUE COUNT(1) FROM c WHERE CONTAINS(c.description, '[Load Test]', true)");

            using var iterator = _container.GetItemQueryIterator<int>(query);
            if (iterator.HasMoreResults)
            {
                var response = await iterator.ReadNextAsync(ct);
                return response.FirstOrDefault();
            }
            return 0;

            // Verify connectivity
            var props = await _container.ReadContainerAsync();
            Console.WriteLine($"  ✓ Connected to Cosmos DB | Database: {_databaseName} | Container: {_containerName} | PartitionKey: {props.Resource.PartitionKeyPath}");
        }

        /// <summary>
        /// Write documents sequentially — one at a time, just like
        /// the real ProcessServiceNowToCosmos function does.
        /// This shows you the real-world bottleneck.
        /// </summary>
        public async Task<WriteResult> WriteSequentialAsync(
            List<(string json, string recordType, string category)> events,
            CancellationToken ct)
        {
            var result = new WriteResult();
            var sw = Stopwatch.StartNew();

            foreach (var (json, recordType, category) in events)
            {
                if (ct.IsCancellationRequested) break;

                try
                {
                    var document = BuildCosmosDocument(json, recordType, category);
                    string sourceTaskId = document["sourceTaskId"]?.ToString();
                    var partitionKey = new PartitionKey(sourceTaskId);

                    await _container.UpsertItemAsync(document, partitionKey);
                    result.SuccessCount++;
                }
                catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                {
                    result.ThrottleCount++;
                    result.FailureCount++;
                }
                catch (Exception)
                {
                    result.FailureCount++;
                }
            }

            sw.Stop();
            result.Elapsed = sw.Elapsed;
            return result;
        }

        /// <summary>
        /// Write documents in parallel with configurable concurrency.
        /// This shows you what Cosmos DB can actually handle when
        /// the one-at-a-time bottleneck is removed.
        /// </summary>
        public async Task<WriteResult> WriteParallelAsync(
            List<(string json, string recordType, string category)> events,
            int maxConcurrency,
            CancellationToken ct)
        {
            var result = new WriteResult();
            var sw = Stopwatch.StartNew();

            var semaphore = new SemaphoreSlim(maxConcurrency, maxConcurrency);
            var tasks = new List<Task>();

            foreach (var (json, recordType, category) in events)
            {
                if (ct.IsCancellationRequested) break;

                await semaphore.WaitAsync(ct);

                tasks.Add(Task.Run(async () =>
                {
                    try
                    {
                        var document = BuildCosmosDocument(json, recordType, category);
                        string sourceTaskId = document["sourceTaskId"]?.ToString();
                        var partitionKey = new PartitionKey(sourceTaskId);

                        await _container.UpsertItemAsync(document, partitionKey);
                        Interlocked.Increment(ref result.SuccessCount);
                    }
                    catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                    {
                        Interlocked.Increment(ref result.ThrottleCount);
                        Interlocked.Increment(ref result.FailureCount);
                    }
                    catch (Exception)
                    {
                        Interlocked.Increment(ref result.FailureCount);
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                }, ct));
            }

            await Task.WhenAll(tasks);
            sw.Stop();
            result.Elapsed = sw.Elapsed;
            return result;
        }

        /// <summary>
        /// Build a Cosmos DB document using the exact same mapping logic
        /// as ProcessServiceNowToCosmos.UpsertToCosmosDb().
        /// New documents every time (no query-then-upsert overhead).
        /// </summary>
        private JObject BuildCosmosDocument(string json, string recordType, string category)
        {
            var data = JObject.Parse(json);
            string sourceTaskId = data["sys_id"]?.ToString();

            var document = new JObject
            {
                ["id"] = Guid.NewGuid().ToString(),
                ["sourceSystem"] = "ServiceNow",
                ["sourceTaskId"] = sourceTaskId,
                ["title"] = data["short_description"]?.ToString() ?? "",
                ["sourceRecordType"] = recordType,
                ["category"] = category
            };

            // Map priority (ServiceNow 1-5 to 0-100 scale)
            if (data["priority"] != null && int.TryParse(data["priority"].ToString(), out int snPriority))
            {
                int normalizedPriority = snPriority switch
                {
                    1 => 100, 2 => 85, 3 => 65, 4 => 40, 5 => 20, _ => 50
                };
                document["priority"] = normalizedPriority;
                document["sourcePriority"] = snPriority.ToString();
            }

            // Map status
            if (data["state"] != null)
            {
                string snState = data["state"].ToString();
                string normalizedStatus = snState switch
                {
                    "1" => "pending", "2" => "in_progress", "3" => "completed",
                    "7" => "completed", "4" => "cancelled", "6" => "completed",
                    _ => "pending"
                };
                document["status"] = normalizedStatus;
                document["sourceStatus"] = snState;
            }

            // Map user fields based on record type
            if (recordType == "sysapproval_approver")
            {
                document["assignedToEmail"] = data["approver_email"]?.ToString() ?? "";
                document["assignedToName"] = data["assigned_to"]?.ToString() ?? "";
                document["approverEmail"] = data["approver_email"]?.ToString() ?? "";
                document["requesterEmail"] = data["requested_for_email"]?.ToString() ?? "";
            }
            else if (recordType == "sc_request" || recordType == "sc_req_item")
            {
                document["assignedToEmail"] = data["assigned_to"]?.ToString() ?? "";
                document["assignedToName"] = data["assigned_to"]?.ToString() ?? "";
                document["requesterEmail"] = data["requested_for_email"]?.ToString() ?? "";
            }
            else
            {
                document["assignedToEmail"] = data["assigned_to_email"]?.ToString() ?? "";
                document["assignedToName"] = data["assigned_to"]?.ToString() ?? "";
            }

            // Map dates
            if (data["opened_at"] != null && DateTime.TryParse(data["opened_at"].ToString(), out DateTime createdDate))
                document["createdDate"] = createdDate;

            if (data["sys_updated_on"] != null && DateTime.TryParse(data["sys_updated_on"].ToString(), out DateTime modifiedDate))
                document["lastModifiedDate"] = modifiedDate;

            if (data["due_date"] != null && DateTime.TryParse(data["due_date"].ToString(), out DateTime dueDate))
                document["dueDate"] = dueDate;

            // Description tagged for cleanup
            document["description"] = data["work_notes"]?.ToString() ?? data["short_description"]?.ToString() ?? "";

            // Deep link
            if (data["sys_id"] != null)
            {
                string sysId = data["sys_id"].ToString();
                string tableName = recordType == "sysapproval_approver" ? "sysapproval_approver"
                                 : recordType == "sc_request" ? "sc_request"
                                 : recordType == "sc_req_item" ? "sc_req_item"
                                 : "task";
                document["deepLink"] = $"https://dev186866.service-now.com/{tableName}.do?sys_id={sysId}";
            }

            document["metadataJson"] = data.ToString();
            document["_ts"] = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

            return document;
        }

        /// <summary>
        /// Query for all documents containing "[Load Test]" in the description
        /// and delete them in parallel.
        /// </summary>
        public async Task<WriteResult> DeleteLoadTestDocumentsAsync(int concurrency = 50, CancellationToken ct = default)
        {
            var sw = Stopwatch.StartNew();
            int successCount = 0;
            int failureCount = 0;

            // Query all load test documents
            Console.Write("🔍 Querying for load test documents... ");
            var query = new QueryDefinition("SELECT c.id, c.sourceTaskId FROM c WHERE CONTAINS(c.description, '[Load Test]', true)");
            var docs = new List<(string id, string partitionKey)>();

            using var iterator = _container.GetItemQueryIterator<JObject>(query);
            while (iterator.HasMoreResults && !ct.IsCancellationRequested)
            {
                var response = await iterator.ReadNextAsync(ct);
                foreach (var doc in response)
                {
                    string id = doc["id"]?.ToString();
                    string pk = doc["sourceTaskId"]?.ToString();
                    if (id != null && pk != null)
                        docs.Add((id, pk));
                }
            }
            Console.WriteLine($"Found {docs.Count:N0} documents");

            if (docs.Count == 0)
            {
                sw.Stop();
                return new WriteResult { SuccessCount = 0, FailureCount = 0, Elapsed = sw.Elapsed };
            }

            // Delete in parallel with semaphore
            Console.Write($"🗑️  Deleting {docs.Count:N0} documents ({concurrency} parallel)... ");
            var semaphore = new SemaphoreSlim(concurrency, concurrency);
            var tasks = new List<Task>(docs.Count);

            foreach (var (id, pk) in docs)
            {
                if (ct.IsCancellationRequested) break;

                tasks.Add(Task.Run(async () =>
                {
                    await semaphore.WaitAsync(ct);
                    try
                    {
                        await _container.DeleteItemAsync<JObject>(id, new PartitionKey(pk), cancellationToken: ct);
                        int count = Interlocked.Increment(ref successCount);
                        if (count % 100 == 0)
                            Console.Write($"\r🗑️  Deleting {docs.Count:N0} documents ({concurrency} parallel)... {count:N0}/{docs.Count:N0}    ");
                    }
                    catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
                    {
                        // Already deleted, count as success
                        Interlocked.Increment(ref successCount);
                    }
                    catch (Exception)
                    {
                        Interlocked.Increment(ref failureCount);
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                }));
            }

            await Task.WhenAll(tasks);
            sw.Stop();

            Console.WriteLine("Done!");

            return new WriteResult
            {
                SuccessCount = successCount,
                FailureCount = failureCount,
                Elapsed = sw.Elapsed
            };
        }

        public async ValueTask DisposeAsync()
        {
            _client?.Dispose();
        }

        public class WriteResult
        {
            public int SuccessCount;
            public int FailureCount;
            public int ThrottleCount;
            public TimeSpan Elapsed;

            public double EventsPerSecond => SuccessCount / (Elapsed.TotalSeconds > 0 ? Elapsed.TotalSeconds : 1);
        }
    }
}
