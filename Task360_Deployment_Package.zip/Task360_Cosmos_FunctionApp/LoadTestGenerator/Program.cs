using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Azure.Identity;
using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Producer;
using Microsoft.Azure.Cosmos;

namespace LoadTestGenerator
{
    /// <summary>
    /// Load Test Generator for Task360.
    /// 
    /// Three modes to stress-test different bottlenecks:
    /// 
    ///   eventhub  - Sends batched events to Event Hub (tests Event Hub ingestion + downstream Functions + Cosmos)
    ///   cosmos    - Writes directly to Cosmos DB (tests DB throughput in isolation, sequential vs parallel)
    ///   pipeline  - Sends events one-at-a-time to Event Hub (simulates the real Python code's bottleneck)
    /// 
    /// Usage:
    ///   dotnet run -- --mode eventhub [batchSize] [intervalMinutes] [totalBatches]
    ///   dotnet run -- --mode cosmos [batchSize] [concurrency]
    ///   dotnet run -- --mode pipeline [batchSize]
    /// 
    /// Examples:
    ///   dotnet run                                 → eventhub mode, 7500 events, every 5 min, forever
    ///   dotnet run -- --mode cosmos 5000 1          → 5000 docs to Cosmos, sequential (like real code)
    ///   dotnet run -- --mode cosmos 5000 50         → 5000 docs to Cosmos, 50 concurrent writes
    ///   dotnet run -- --mode pipeline 1000          → 1000 events one-at-a-time to Event Hub
    ///   dotnet run -- --mode eventhub 10000 5 3     → 10000 batched events, every 5 min, 3 batches
    /// </summary>
    class Program
    {
        // ── Configuration ──────────────────────────────────────────────
        private const string EventHubNamespace = "task360eventhubs.servicebus.windows.net";
        private const string TaskEventHub = "task360-events";
        private const string RequestEventHub = "task360-requests";
        private const string ApprovalEventHub = "task360-approvals";

        // Cosmos DB (matches your local.settings.json)
        private const string CosmosEndpoint = "https://task360cosmosdb-provisioned.documents.azure.com:443/";
        private const string CosmosDatabase = "Task360DB";
        private const string CosmosContainer = "Tasks";

        // Max events per EventHub SendAsync batch
        private const int MaxEventsPerSend = 500;

        static async Task Main(string[] args)
        {
            Console.WriteLine("═══════════════════════════════════════════════════════════════");
            Console.WriteLine("  Task360 Load Test Generator");
            Console.WriteLine("  Stress-test Event Hub ingestion and Cosmos DB throughput");
            Console.WriteLine("═══════════════════════════════════════════════════════════════");
            Console.WriteLine();

            // Parse --mode flag and collect positional args
            string mode = "eventhub";
            var positionalArgs = new List<string>();

            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "--mode" && i + 1 < args.Length)
                {
                    mode = args[++i].ToLower();
                }
                else
                {
                    positionalArgs.Add(args[i]);
                }
            }

            switch (mode)
            {
                case "eventhub":
                    await RunEventHubMode(positionalArgs);
                    break;
                case "cosmos":
                    await RunCosmosMode(positionalArgs);
                    break;
                case "pipeline":
                    await RunPipelineMode(positionalArgs);
                    break;
                case "cleanup":
                    await RunCleanupMode(positionalArgs);
                    break;
                case "count":
                    await RunCountMode();
                    break;
                case "seed":
                    await RunSeedMode(positionalArgs);
                    break;
                default:
                    Console.WriteLine($"Unknown mode: {mode}");
                    Console.WriteLine("Valid modes: eventhub, cosmos, pipeline, cleanup, count, seed");
                    Console.WriteLine();
                    PrintUsage();
                    break;
            }
        }

        static void PrintUsage()
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("  dotnet run -- --mode eventhub [batchSize] [intervalMin] [totalBatches]");
            Console.WriteLine("  dotnet run -- --mode cosmos   [batchSize] [concurrency]");
            Console.WriteLine("  dotnet run -- --mode pipeline [batchSize]");
            Console.WriteLine("  dotnet run -- --mode cleanup  [concurrency]");
            Console.WriteLine("  dotnet run -- --mode seed     [total] [assignedCount] [email]");
            Console.WriteLine();
            Console.WriteLine("Modes:");
            Console.WriteLine("  eventhub  - Batched Event Hub sends → Functions → Cosmos DB (full pipeline)");
            Console.WriteLine("  cosmos    - Direct Cosmos DB writes (isolate DB bottleneck)");
            Console.WriteLine("  pipeline  - One-at-a-time Event Hub sends (simulate real Python code)");
            Console.WriteLine("  cleanup   - Delete all [Load Test] documents from Cosmos DB");
            Console.WriteLine("  seed      - Insert docs directly to Cosmos with optional email assignment");
        }

        // ────────────────────────────────────────────────────────────────
        //  MODE 1: EVENTHUB — batched sends to Event Hub (full pipeline test)
        // ────────────────────────────────────────────────────────────────
        static async Task RunEventHubMode(List<string> args)
        {
            int batchSize = args.Count > 0 && int.TryParse(args[0], out int b) ? b : 7500;
            int intervalMinutes = args.Count > 1 && int.TryParse(args[1], out int m) ? m : 5;
            int totalBatches = args.Count > 2 && int.TryParse(args[2], out int t) ? t : 0;

            Console.WriteLine("  Mode:            EVENT HUB (batched sends → full pipeline)");
            Console.WriteLine($"  Batch size:      {batchSize:N0} events");
            Console.WriteLine($"  Interval:        {intervalMinutes} minutes");
            Console.WriteLine($"  Total batches:   {(totalBatches == 0 ? "∞ (Ctrl+C to stop)" : totalBatches.ToString())}");
            Console.WriteLine($"  Event Hubs:      {EventHubNamespace}");
            Console.WriteLine($"  Split:           60% tasks / 25% requests / 15% approvals");
            Console.WriteLine();

            var credential = new DefaultAzureCredential();

            Console.Write("🔌 Connecting to Event Hubs... ");
            var taskProducer = new EventHubProducerClient(EventHubNamespace, TaskEventHub, credential);
            var requestProducer = new EventHubProducerClient(EventHubNamespace, RequestEventHub, credential);
            var approvalProducer = new EventHubProducerClient(EventHubNamespace, ApprovalEventHub, credential);
            Console.WriteLine("Connected ✓");
            Console.WriteLine();

            var cts = new CancellationTokenSource();
            Console.CancelKeyPress += (_, e) => { e.Cancel = true; cts.Cancel(); };

            int batchNumber = 0;
            long totalSent = 0;

            try
            {
                while (!cts.IsCancellationRequested)
                {
                    batchNumber++;
                    if (totalBatches > 0 && batchNumber > totalBatches) break;

                    Console.WriteLine($"━━━ Batch {batchNumber}{(totalBatches > 0 ? $"/{totalBatches}" : "")} ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

                    var sw = Stopwatch.StartNew();
                    Console.Write($"  📦 Generating {batchSize:N0} synthetic events... ");
                    var allEvents = SyntheticDataFactory.GenerateBatch(batchSize);
                    Console.WriteLine($"Done ({sw.ElapsedMilliseconds}ms)");

                    var taskEvents = allEvents.Where(e => e.category == "Task").Select(e => e.json).ToList();
                    var requestEvents = allEvents.Where(e => e.category == "Request").Select(e => e.json).ToList();
                    var approvalEvents = allEvents.Where(e => e.category == "Approval").Select(e => e.json).ToList();

                    Console.WriteLine($"  📊 Split: {taskEvents.Count:N0} tasks | {requestEvents.Count:N0} requests | {approvalEvents.Count:N0} approvals");

                    sw.Restart();
                    Console.Write("  🚀 Sending to Event Hubs (batched)... ");

                    var sendTasks = new[]
                    {
                        SendEventsBatchedAsync(taskProducer, taskEvents, "Tasks", cts.Token),
                        SendEventsBatchedAsync(requestProducer, requestEvents, "Requests", cts.Token),
                        SendEventsBatchedAsync(approvalProducer, approvalEvents, "Approvals", cts.Token)
                    };

                    var results = await Task.WhenAll(sendTasks);
                    sw.Stop();

                    int batchSent = results.Sum();
                    totalSent += batchSent;

                    double eventsPerSecond = batchSent / (sw.Elapsed.TotalSeconds > 0 ? sw.Elapsed.TotalSeconds : 1);
                    Console.WriteLine($"Done!");
                    Console.WriteLine($"  ✅ Sent {batchSent:N0} events in {sw.Elapsed.TotalSeconds:F1}s ({eventsPerSecond:F0} events/sec)");
                    Console.WriteLine($"  📈 Running total: {totalSent:N0} events");

                    if (totalBatches == 0 || batchNumber < totalBatches)
                    {
                        Console.WriteLine($"  ⏳ Next batch in {intervalMinutes} minutes... (Ctrl+C to stop)");
                        Console.WriteLine();
                        try { await Task.Delay(TimeSpan.FromMinutes(intervalMinutes), cts.Token); }
                        catch (TaskCanceledException) { break; }
                    }
                }
            }
            finally
            {
                Console.WriteLine();
                Console.WriteLine($"  Event Hub mode complete. Total events sent: {totalSent:N0}");
                await taskProducer.DisposeAsync();
                await requestProducer.DisposeAsync();
                await approvalProducer.DisposeAsync();
            }

            // ── End-to-end monitoring: poll Cosmos DB until all documents land ──
            if (totalSent > 0)
            {
                Console.WriteLine();
                Console.WriteLine("━━━ Monitoring Cosmos DB (end-to-end timing) ━━━━━━━━━━━━━━━");
                Console.Write("🔌 Connecting to Cosmos DB... ");
                await using var monitor = new CosmosDbLoadTester(CosmosEndpoint, CosmosDatabase, CosmosContainer);
                await monitor.InitializeAsync();
                Console.WriteLine("Connected ✓");

                // Get baseline count (docs already in DB before this test)
                int baselineCount = await monitor.CountLoadTestDocumentsAsync();
                Console.WriteLine($"  📊 Baseline load test docs in DB: {baselineCount:N0}");
                Console.WriteLine($"  🎯 Target: {baselineCount + totalSent:N0} (baseline + {totalSent:N0} new)");
                Console.WriteLine();

                var e2eSw = Stopwatch.StartNew();
                int lastCount = baselineCount;
                int stableChecks = 0;
                int pollInterval = 5; // seconds

                while (!cts.IsCancellationRequested)
                {
                    await Task.Delay(TimeSpan.FromSeconds(pollInterval), cts.Token).ConfigureAwait(false);

                    int currentCount = await monitor.CountLoadTestDocumentsAsync(cts.Token);
                    int newDocs = currentCount - baselineCount;
                    double pct = totalSent > 0 ? (double)newDocs / totalSent * 100 : 0;
                    double rate = e2eSw.Elapsed.TotalSeconds > 0 ? newDocs / e2eSw.Elapsed.TotalSeconds : 0;
                    double eta = rate > 0 ? (totalSent - newDocs) / rate : 0;

                    Console.Write($"\r  📈 {newDocs:N0}/{totalSent:N0} docs in DB ({pct:F1}%) | {rate:F0} docs/sec | Elapsed: {e2eSw.Elapsed:mm\\:ss} | ETA: {eta:F0}s    ");

                    // Check if we've reached the target or progress has stalled
                    if (newDocs >= totalSent)
                    {
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.WriteLine($"  ✅ All {totalSent:N0} documents landed in Cosmos DB!");
                        break;
                    }

                    if (currentCount == lastCount)
                    {
                        stableChecks++;
                        if (stableChecks >= 12) // 60 seconds with no progress
                        {
                            Console.WriteLine();
                            Console.WriteLine();
                            Console.WriteLine($"  ⚠️  No new documents for 60s. {newDocs:N0}/{totalSent:N0} landed ({pct:F1}%).");
                            Console.WriteLine($"      Some events may have failed or are still retrying.");
                            break;
                        }
                    }
                    else
                    {
                        stableChecks = 0;
                    }
                    lastCount = currentCount;
                }

                e2eSw.Stop();
                int finalCount = await monitor.CountLoadTestDocumentsAsync();
                int finalNew = finalCount - baselineCount;
                double finalRate = e2eSw.Elapsed.TotalSeconds > 0 ? finalNew / e2eSw.Elapsed.TotalSeconds : 0;

                Console.WriteLine($"  ⏱️  End-to-end time: {e2eSw.Elapsed:hh\\:mm\\:ss} ({e2eSw.Elapsed.TotalSeconds:F1}s)");
                Console.WriteLine($"  📊 Final: {finalNew:N0} docs written | {finalRate:F0} docs/sec average throughput");
                Console.WriteLine($"  📊 Success rate: {(totalSent > 0 ? (double)finalNew / totalSent * 100 : 0):F1}%");
            }
        }

        // ────────────────────────────────────────────────────────────────
        //  MODE 2: COSMOS — direct writes to Cosmos DB (isolate DB bottleneck)
        // ────────────────────────────────────────────────────────────────
        static async Task RunCosmosMode(List<string> args)
        {
            int batchSize = args.Count > 0 && int.TryParse(args[0], out int b) ? b : 5000;
            int concurrency = args.Count > 1 && int.TryParse(args[1], out int c) ? c : 1;

            Console.WriteLine("  Mode:            COSMOS DB (direct writes, bypass Event Hub)");
            Console.WriteLine($"  Documents:       {batchSize:N0}");
            Console.WriteLine($"  Concurrency:     {(concurrency <= 1 ? "Sequential (simulates real function bottleneck)" : $"{concurrency} parallel writers")}");
            Console.WriteLine($"  Endpoint:        {CosmosEndpoint}");
            Console.WriteLine($"  Database:        {CosmosDatabase}/{CosmosContainer}");
            Console.WriteLine();

            Console.Write("🔌 Connecting to Cosmos DB... ");
            await using var tester = new CosmosDbLoadTester(CosmosEndpoint, CosmosDatabase, CosmosContainer);
            await tester.InitializeAsync();
            Console.WriteLine();

            var cts = new CancellationTokenSource();
            Console.CancelKeyPress += (_, e) => { e.Cancel = true; cts.Cancel(); };

            // Generate data
            Console.Write($"📦 Generating {batchSize:N0} synthetic documents... ");
            var sw = Stopwatch.StartNew();
            var events = SyntheticDataFactory.GenerateBatch(batchSize);
            Console.WriteLine($"Done ({sw.ElapsedMilliseconds}ms)");
            Console.WriteLine();

            // Always run sequential first
            Console.WriteLine("━━━ Sequential writes (simulates current function behavior) ━━━");
            Console.Write($"  💾 Writing {batchSize:N0} documents one-at-a-time... ");
            var seqResult = await tester.WriteSequentialAsync(events, cts.Token);
            Console.WriteLine($"Done!");
            Console.WriteLine($"  ✅ Success: {seqResult.SuccessCount:N0} | Failed: {seqResult.FailureCount:N0} | Throttled: {seqResult.ThrottleCount:N0}");
            Console.WriteLine($"  ⏱️  Time: {seqResult.Elapsed.TotalSeconds:F1}s | Rate: {seqResult.EventsPerSecond:F0} docs/sec");
            Console.WriteLine();

            // If concurrency > 1, also run parallel and compare
            if (concurrency > 1 && !cts.IsCancellationRequested)
            {
                Console.Write($"📦 Generating {batchSize:N0} fresh documents for parallel test... ");
                var parallelEvents = SyntheticDataFactory.GenerateBatch(batchSize);
                Console.WriteLine($"Done");
                Console.WriteLine();

                Console.WriteLine($"━━━ Parallel writes ({concurrency} concurrent) ━━━━━━━━━━━━━━━━━━━━━━");
                Console.Write($"  💾 Writing {batchSize:N0} documents with {concurrency} parallel writers... ");
                var parResult = await tester.WriteParallelAsync(parallelEvents, concurrency, cts.Token);
                Console.WriteLine($"Done!");
                Console.WriteLine($"  ✅ Success: {parResult.SuccessCount:N0} | Failed: {parResult.FailureCount:N0} | Throttled: {parResult.ThrottleCount:N0}");
                Console.WriteLine($"  ⏱️  Time: {parResult.Elapsed.TotalSeconds:F1}s | Rate: {parResult.EventsPerSecond:F0} docs/sec");
                Console.WriteLine();

                // Comparison
                Console.WriteLine("━━━ Comparison ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                double speedup = seqResult.Elapsed.TotalSeconds / (parResult.Elapsed.TotalSeconds > 0 ? parResult.Elapsed.TotalSeconds : 1);
                Console.WriteLine($"  Sequential:  {seqResult.EventsPerSecond:F0} docs/sec ({seqResult.Elapsed.TotalSeconds:F1}s)");
                Console.WriteLine($"  Parallel:    {parResult.EventsPerSecond:F0} docs/sec ({parResult.Elapsed.TotalSeconds:F1}s)");
                Console.WriteLine($"  Speedup:     {speedup:F1}x faster with {concurrency} parallel writers");

                if (parResult.ThrottleCount > 0)
                {
                    Console.WriteLine($"  ⚠️  {parResult.ThrottleCount} requests were throttled (429) — consider increasing Cosmos DB RU/s");
                }
            }

            Console.WriteLine();
            Console.WriteLine($"  Cosmos mode complete.");
        }

        // ────────────────────────────────────────────────────────────────
        //  MODE 3: PIPELINE — one-at-a-time sends (simulate real Python code)
        // ────────────────────────────────────────────────────────────────
        static async Task RunPipelineMode(List<string> args)
        {
            int batchSize = args.Count > 0 && int.TryParse(args[0], out int b) ? b : 1000;

            Console.WriteLine("  Mode:            PIPELINE (one-at-a-time, simulates real Python code)");
            Console.WriteLine($"  Events:          {batchSize:N0}");
            Console.WriteLine($"  Event Hubs:      {EventHubNamespace}");
            Console.WriteLine($"  ⚠️  This is intentionally slow — it shows the real bottleneck");
            Console.WriteLine();

            var credential = new DefaultAzureCredential();

            Console.Write("🔌 Connecting to Event Hubs... ");
            var taskProducer = new EventHubProducerClient(EventHubNamespace, TaskEventHub, credential);
            var requestProducer = new EventHubProducerClient(EventHubNamespace, RequestEventHub, credential);
            var approvalProducer = new EventHubProducerClient(EventHubNamespace, ApprovalEventHub, credential);
            Console.WriteLine("Connected ✓");
            Console.WriteLine();

            var cts = new CancellationTokenSource();
            Console.CancelKeyPress += (_, e) => { e.Cancel = true; cts.Cancel(); };

            // Generate data
            Console.Write($"📦 Generating {batchSize:N0} synthetic events... ");
            var allEvents = SyntheticDataFactory.GenerateBatch(batchSize);
            Console.WriteLine("Done");
            Console.WriteLine();

            // ── Phase 1: One-at-a-time (simulates real Python code) ──
            Console.WriteLine("━━━ Sending events one-at-a-time (like real Python code) ━━━");
            var sw = Stopwatch.StartNew();
            int sent = 0;
            int failed = 0;

            foreach (var (json, recordType, category) in allEvents)
            {
                if (cts.IsCancellationRequested) break;

                try
                {
                    // Pick the right producer based on category (same routing as Python code)
                    var producer = category switch
                    {
                        "Task" => taskProducer,
                        "Request" => requestProducer,
                        "Approval" => approvalProducer,
                        _ => taskProducer
                    };

                    // Send one event at a time — exactly like the real Python send_event()
                    using EventDataBatch batch = await producer.CreateBatchAsync(cts.Token);
                    batch.TryAdd(new EventData(Encoding.UTF8.GetBytes(json)));
                    await producer.SendAsync(batch, cts.Token);
                    sent++;

                    // Progress every 100 events
                    if (sent % 100 == 0)
                    {
                        double elapsed = sw.Elapsed.TotalSeconds;
                        double rate = sent / (elapsed > 0 ? elapsed : 1);
                        double eta = (batchSize - sent) / (rate > 0 ? rate : 1);
                        Console.Write($"\r  📤 Sent {sent:N0}/{batchSize:N0} ({rate:F0}/sec, ~{eta:F0}s remaining)    ");
                    }
                }
                catch (Exception)
                {
                    failed++;
                }
            }

            sw.Stop();
            Console.WriteLine();
            Console.WriteLine();

            double finalRate = sent / (sw.Elapsed.TotalSeconds > 0 ? sw.Elapsed.TotalSeconds : 1);
            Console.WriteLine($"  ✅ Sent: {sent:N0} | Failed: {failed:N0}");
            Console.WriteLine($"  ⏱️  Time: {sw.Elapsed.TotalSeconds:F1}s | Rate: {finalRate:F0} events/sec");
            Console.WriteLine();

            // ── Phase 2: Batched comparison ──
            if (!cts.IsCancellationRequested)
            {
                Console.Write("📊 Comparison: sending same volume batched... ");
                var sw2 = Stopwatch.StartNew();
                var taskEvents = allEvents.Where(e => e.category == "Task").Select(e => e.json).ToList();
                var requestEvents = allEvents.Where(e => e.category == "Request").Select(e => e.json).ToList();
                var approvalEvents = allEvents.Where(e => e.category == "Approval").Select(e => e.json).ToList();

                var sendTasks = new[]
                {
                    SendEventsBatchedAsync(taskProducer, taskEvents, "Tasks", cts.Token),
                    SendEventsBatchedAsync(requestProducer, requestEvents, "Requests", cts.Token),
                    SendEventsBatchedAsync(approvalProducer, approvalEvents, "Approvals", cts.Token)
                };
                var results = await Task.WhenAll(sendTasks);
                sw2.Stop();

                int batchedSent = results.Sum();
                double batchedRate = batchedSent / (sw2.Elapsed.TotalSeconds > 0 ? sw2.Elapsed.TotalSeconds : 1);
                Console.WriteLine($"Done!");
                Console.WriteLine($"  ⏱️  Time: {sw2.Elapsed.TotalSeconds:F1}s | Rate: {batchedRate:F0} events/sec");
                Console.WriteLine();

                double speedup = sw.Elapsed.TotalSeconds / (sw2.Elapsed.TotalSeconds > 0 ? sw2.Elapsed.TotalSeconds : 1);
                Console.WriteLine("━━━ Bottleneck Analysis ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                Console.WriteLine($"  One-at-a-time: {finalRate:F0} events/sec ({sw.Elapsed.TotalSeconds:F1}s)");
                Console.WriteLine($"  Batched:       {batchedRate:F0} events/sec ({sw2.Elapsed.TotalSeconds:F1}s)");
                Console.WriteLine($"  Speedup:       {speedup:F1}x faster with batched sends");
            }

            await taskProducer.DisposeAsync();
            await requestProducer.DisposeAsync();
            await approvalProducer.DisposeAsync();
        }

        // ────────────────────────────────────────────────────────────────
        //  MODE 5: COUNT — count load test documents in Cosmos DB
        // ────────────────────────────────────────────────────────────────
        static async Task RunCountMode()
        {
            Console.WriteLine("  Mode:            COUNT (query load test documents in Cosmos DB)");
            Console.WriteLine();

            await using var tester = new CosmosDbLoadTester(CosmosEndpoint, CosmosDatabase, CosmosContainer);
            await tester.InitializeAsync();

            Console.Write("  🔍 Counting load test documents... ");
            int count = await tester.CountLoadTestDocumentsAsync();
            Console.WriteLine($"{count:N0}");
            Console.WriteLine();
        }

        // ────────────────────────────────────────────────────────────────
        //  MODE 4: CLEANUP — delete all load test documents from Cosmos DB
        // ────────────────────────────────────────────────────────────────
        static async Task RunCleanupMode(List<string> args)
        {
            int concurrency = args.Count > 0 && int.TryParse(args[0], out int c) ? c : 50;

            Console.WriteLine("  Mode:            CLEANUP (delete load test documents from Cosmos DB)");
            Console.WriteLine($"  Concurrency:     {concurrency} parallel deletes");
            Console.WriteLine($"  Endpoint:        {CosmosEndpoint}");
            Console.WriteLine($"  Database:        {CosmosDatabase}/{CosmosContainer}");
            Console.WriteLine($"  Query:           CONTAINS(description, '[Load Test]')");
            Console.WriteLine();

            Console.Write("🔌 Connecting to Cosmos DB... ");
            await using var tester = new CosmosDbLoadTester(CosmosEndpoint, CosmosDatabase, CosmosContainer);
            await tester.InitializeAsync();
            Console.WriteLine();

            var cts = new CancellationTokenSource();
            Console.CancelKeyPress += (_, e) => { e.Cancel = true; cts.Cancel(); };

            var result = await tester.DeleteLoadTestDocumentsAsync(concurrency, cts.Token);

            Console.WriteLine();
            Console.WriteLine($"  ✅ Deleted: {result.SuccessCount:N0} | Failed: {result.FailureCount:N0}");
            Console.WriteLine($"  ⏱️  Time: {result.Elapsed.TotalSeconds:F1}s | Rate: {result.EventsPerSecond:F0} deletes/sec");
            Console.WriteLine();
            Console.WriteLine("  Cleanup complete.");
        }

        // ────────────────────────────────────────────────────────────────
        //  MODE 6: SEED — insert docs directly with optional email assignment
        // ────────────────────────────────────────────────────────────────
        static async Task RunSeedMode(List<string> args)
        {
            int total = args.Count > 0 && int.TryParse(args[0], out int t) ? t : 100;
            int assignedCount = args.Count > 1 && int.TryParse(args[1], out int a) ? a : 0;
            string assignedEmail = args.Count > 2 ? args[2] : null;

            Console.WriteLine("  Mode:            SEED (insert docs directly to Cosmos DB)");
            Console.WriteLine($"  Total documents: {total:N0}");
            if (assignedCount > 0 && !string.IsNullOrEmpty(assignedEmail))
            {
                Console.WriteLine($"  Assigned to:     {assignedEmail} ({assignedCount} docs)");
            }
            Console.WriteLine($"  Endpoint:        {CosmosEndpoint}");
            Console.WriteLine($"  Database:        {CosmosDatabase}/{CosmosContainer}");
            Console.WriteLine();

            Console.Write("🔌 Connecting to Cosmos DB... ");
            await using var tester = new CosmosDbLoadTester(CosmosEndpoint, CosmosDatabase, CosmosContainer);
            await tester.InitializeAsync();
            Console.WriteLine();

            // Generate data with email assignment
            Console.Write($"📦 Generating {total:N0} synthetic documents");
            if (assignedCount > 0) Console.Write($" ({assignedCount} assigned to {assignedEmail})");
            Console.Write("... ");

            var sw = Stopwatch.StartNew();
            var events = (assignedCount > 0 && !string.IsNullOrEmpty(assignedEmail))
                ? SyntheticDataFactory.GenerateBatchWithAssignment(total, assignedCount, assignedEmail)
                : SyntheticDataFactory.GenerateBatch(total);
            Console.WriteLine($"Done ({sw.ElapsedMilliseconds}ms)");
            Console.WriteLine();

            // Write with moderate parallelism
            var cts = new CancellationTokenSource();
            Console.CancelKeyPress += (_, e) => { e.Cancel = true; cts.Cancel(); };

            Console.Write($"💾 Writing {total:N0} documents to Cosmos DB... ");
            var result = await tester.WriteParallelAsync(events, Math.Min(total, 50), cts.Token);
            Console.WriteLine("Done!");
            Console.WriteLine($"  ✅ Success: {result.SuccessCount:N0} | Failed: {result.FailureCount:N0} | Throttled: {result.ThrottleCount:N0}");
            Console.WriteLine($"  ⏱️  Time: {result.Elapsed.TotalSeconds:F1}s | Rate: {result.EventsPerSecond:F0} docs/sec");

            if (assignedCount > 0 && !string.IsNullOrEmpty(assignedEmail))
            {
                Console.WriteLine();
                Console.WriteLine($"  📧 {assignedCount} documents assigned to: {assignedEmail}");
            }

            Console.WriteLine();
            Console.WriteLine("  Seed complete.");
        }

        // ────────────────────────────────────────────────────────────────
        //  Shared: batched Event Hub sender
        // ────────────────────────────────────────────────────────────────
        private static async Task<int> SendEventsBatchedAsync(
            EventHubProducerClient producer,
            List<string> jsonPayloads,
            string label,
            CancellationToken ct)
        {
            if (jsonPayloads.Count == 0) return 0;

            int sent = 0;

            for (int offset = 0; offset < jsonPayloads.Count && !ct.IsCancellationRequested; offset += MaxEventsPerSend)
            {
                var chunk = jsonPayloads.Skip(offset).Take(MaxEventsPerSend).ToList();

                using EventDataBatch batch = await producer.CreateBatchAsync(ct);

                foreach (var json in chunk)
                {
                    var eventData = new EventData(Encoding.UTF8.GetBytes(json));

                    if (!batch.TryAdd(eventData))
                    {
                        if (batch.Count > 0)
                        {
                            await producer.SendAsync(batch, ct);
                            sent += batch.Count;
                        }

                        using EventDataBatch overflowBatch = await producer.CreateBatchAsync(ct);
                        if (!overflowBatch.TryAdd(eventData))
                        {
                            Console.WriteLine($"    ⚠️ [{label}] Skipping oversized event");
                            continue;
                        }
                        await producer.SendAsync(overflowBatch, ct);
                        sent += overflowBatch.Count;
                        continue;
                    }
                }

                if (batch.Count > 0)
                {
                    await producer.SendAsync(batch, ct);
                    sent += batch.Count;
                }
            }

            return sent;
        }
    }
}
