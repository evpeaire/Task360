using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace LoadTestGenerator
{
    /// <summary>
    /// Generates realistic ServiceNow-style JSON payloads that match
    /// the schema expected by ProcessServiceNowToCosmos functions.
    /// </summary>
    public static class SyntheticDataFactory
    {
        private static readonly Random _random = new Random();

        // Realistic ServiceNow task types
        private static readonly string[] TaskRecordTypes = { "incident", "change_request", "problem", "sc_task" };
        private static readonly string[] RequestRecordTypes = { "sc_request", "sc_req_item" };
        private static readonly string[] ApprovalRecordTypes = { "sysapproval_approver" };

        // Realistic field values
        private static readonly string[] ShortDescriptions = new[]
        {
            "Unable to access email on mobile device",
            "VPN connection drops intermittently",
            "Laptop screen flickering after update",
            "Request for new software license",
            "Password reset for AD account",
            "Printer not responding on 3rd floor",
            "Network drive mapping issue",
            "Application crashing on startup",
            "New hire laptop provisioning",
            "Upgrade RAM on workstation",
            "Security certificate renewal",
            "Database performance degradation",
            "Firewall rule change request",
            "Server disk space running low",
            "Automated backup job failure",
            "Deployment approval for release 4.2",
            "Access request for SharePoint site",
            "MFA enrollment assistance needed",
            "Conference room AV equipment malfunction",
            "SAP transport request approval",
            "Cloud resource scaling request",
            "SSL certificate expiration warning",
            "Citrix session disconnection issue",
            "New team onboarding setup",
            "Data center maintenance window approval",
            "API gateway timeout errors",
            "Office 365 license assignment",
            "JIRA project creation request",
            "Network switch replacement in building B",
            "Endpoint detection alert investigation"
        };

        private static readonly string[] FirstNames = { "James", "Sarah", "Michael", "Emily", "David", "Jessica", "Robert", "Amanda", "William", "Jennifer", "Thomas", "Lisa", "Christopher", "Michelle", "Daniel", "Ashley", "Andrew", "Stephanie", "Matthew", "Nicole" };
        private static readonly string[] LastNames = { "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Anderson", "Taylor", "Wilson", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White" };
        private static readonly string[] AssignmentGroups = { "Service Desk", "Network Operations", "Database Admin", "Security Team", "Cloud Infrastructure", "Application Support", "Desktop Support", "Identity Management" };
        private static readonly string[] Categories = { "Hardware", "Software", "Network", "Security", "Access", "Cloud", "Database", "General" };

        /// <summary>
        /// Generate a batch of synthetic task events for load testing.
        /// </summary>
        public static List<(string json, string recordType, string category)> GenerateBatch(int totalCount)
        {
            // Split roughly: 60% tasks, 25% requests, 15% approvals
            int taskCount = (int)(totalCount * 0.60);
            int requestCount = (int)(totalCount * 0.25);
            int approvalCount = totalCount - taskCount - requestCount;

            var events = new List<(string json, string recordType, string category)>();

            for (int i = 0; i < taskCount; i++)
                events.Add(GenerateTaskEvent(i));

            for (int i = 0; i < requestCount; i++)
                events.Add(GenerateRequestEvent(i));

            for (int i = 0; i < approvalCount; i++)
                events.Add(GenerateApprovalEvent(i));

            // Shuffle so they arrive in mixed order, like real traffic
            Shuffle(events);
            return events;
        }

        private static (string json, string recordType, string category) GenerateTaskEvent(int index)
        {
            string recordType = TaskRecordTypes[_random.Next(TaskRecordTypes.Length)];
            string prefix = recordType switch
            {
                "incident" => "INC",
                "change_request" => "CHG",
                "problem" => "PRB",
                "sc_task" => "SCTASK",
                _ => "TASK"
            };

            var data = BuildBasePayload(prefix, recordType);
            data["record_type"] = recordType;
            data["assigned_to_email"] = GenerateEmail();
            data["assigned_to"] = GenerateFullName();
            data["assignment_group"] = AssignmentGroups[_random.Next(AssignmentGroups.Length)];
            data["category"] = Categories[_random.Next(Categories.Length)];

            return (data.ToString(Newtonsoft.Json.Formatting.None), recordType, "Task");
        }

        private static (string json, string recordType, string category) GenerateRequestEvent(int index)
        {
            string recordType = RequestRecordTypes[_random.Next(RequestRecordTypes.Length)];
            string prefix = recordType == "sc_request" ? "REQ" : "RITM";

            var data = BuildBasePayload(prefix, recordType);
            data["record_type"] = recordType;
            data["assigned_to"] = GenerateFullName();
            data["requested_for_email"] = GenerateEmail();
            data["requested_for"] = GenerateFullName();

            return (data.ToString(Newtonsoft.Json.Formatting.None), recordType, "Request");
        }

        private static (string json, string recordType, string category) GenerateApprovalEvent(int index)
        {
            var data = BuildBasePayload("APPR", "sysapproval_approver");
            data["record_type"] = "sysapproval_approver";
            data["approver_email"] = GenerateEmail();
            data["assigned_to"] = GenerateFullName();
            data["requested_for_email"] = GenerateEmail();
            data["requested_for"] = GenerateFullName();
            // Approvals use sys_id as primary key, may not have a number
            data.Remove("number");

            return (data.ToString(Newtonsoft.Json.Formatting.None), "sysapproval_approver", "Approval");
        }

        private static JObject BuildBasePayload(string prefix, string recordType)
        {
            string sysId = Guid.NewGuid().ToString("N"); // 32-char hex, matches ServiceNow sys_id format
            string number = $"{prefix}{_random.Next(1000000, 9999999):D7}";
            int priority = _random.Next(1, 6);   // 1-5
            int state = PickWeightedState();
            DateTime openedAt = DateTime.UtcNow.AddMinutes(-_random.Next(0, 60 * 24 * 30)); // up to 30 days ago
            DateTime updatedOn = DateTime.UtcNow.AddMinutes(-_random.Next(0, 300));          // updated recently

            var data = new JObject
            {
                ["sys_id"] = sysId,
                ["number"] = number,
                ["short_description"] = ShortDescriptions[_random.Next(ShortDescriptions.Length)],
                ["priority"] = priority.ToString(),
                ["state"] = state.ToString(),
                ["opened_at"] = openedAt.ToString("yyyy-MM-dd HH:mm:ss"),
                ["sys_updated_on"] = updatedOn.ToString("yyyy-MM-dd HH:mm:ss"),
                ["work_notes"] = $"[Load Test] Synthetic record generated at {DateTime.UtcNow:O}",
                ["sys_class_name"] = recordType
            };

            // ~40% of tasks have a due date
            if (_random.NextDouble() < 0.4)
            {
                data["due_date"] = DateTime.UtcNow.AddDays(_random.Next(1, 30)).ToString("yyyy-MM-dd HH:mm:ss");
            }

            return data;
        }

        /// <summary>
        /// Weighted state distribution to match realistic ServiceNow patterns:
        /// ~30% New (1), ~35% In Progress (2), ~20% Resolved (3), ~10% Closed (7), ~5% Cancelled (4)
        /// </summary>
        private static int PickWeightedState()
        {
            double roll = _random.NextDouble();
            if (roll < 0.30) return 1;
            if (roll < 0.65) return 2;
            if (roll < 0.85) return 3;
            if (roll < 0.95) return 7;
            return 4;
        }

        private static string GenerateEmail()
        {
            string first = FirstNames[_random.Next(FirstNames.Length)].ToLower();
            string last = LastNames[_random.Next(LastNames.Length)].ToLower();
            return $"{first}.{last}@barclays.com";
        }

        private static string GenerateFullName()
        {
            return $"{FirstNames[_random.Next(FirstNames.Length)]} {LastNames[_random.Next(LastNames.Length)]}";
        }

        /// <summary>
        /// Generate a batch where a specific number of events are assigned to a given email address.
        /// The assigned events are distributed across task types (tasks, requests, approvals).
        /// </summary>
        public static List<(string json, string recordType, string category)> GenerateBatchWithAssignment(
            int totalCount, int assignedCount, string assignedEmail, string assignedName = null)
        {
            var events = GenerateBatch(totalCount);

            if (assignedCount <= 0 || string.IsNullOrEmpty(assignedEmail))
                return events;

            // Pick the first N events and override their email fields
            int toAssign = Math.Min(assignedCount, events.Count);
            string name = assignedName ?? assignedEmail.Split('@')[0].Replace(".", " ");

            for (int i = 0; i < toAssign; i++)
            {
                var (json, recordType, category) = events[i];
                var data = JObject.Parse(json);

                // Override email fields based on record type
                if (recordType == "sysapproval_approver")
                {
                    data["approver_email"] = assignedEmail;
                    data["assigned_to"] = name;
                }
                else if (recordType == "sc_request" || recordType == "sc_req_item")
                {
                    data["requested_for_email"] = assignedEmail;
                    data["requested_for"] = name;
                }
                else
                {
                    data["assigned_to_email"] = assignedEmail;
                    data["assigned_to"] = name;
                }

                events[i] = (data.ToString(Newtonsoft.Json.Formatting.None), recordType, category);
            }

            // Shuffle again so the assigned ones are mixed in
            Shuffle(events);
            return events;
        }

        private static void Shuffle<T>(List<T> list)
        {
            for (int i = list.Count - 1; i > 0; i--)
            {
                int j = _random.Next(i + 1);
                (list[i], list[j]) = (list[j], list[i]);
            }
        }
    }
}
