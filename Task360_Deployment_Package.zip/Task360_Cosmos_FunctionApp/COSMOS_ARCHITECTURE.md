# Task360 Cosmos DB Architecture

## Overview
The Task360 Cosmos DB implementation provides an alternative data persistence layer to the existing Dataverse solution. It consumes the same ServiceNow events from Azure Event Hubs and stores them in Azure Cosmos DB instead of Microsoft Dataverse.

## Architecture Components

### 1. Data Flow Architecture

```
ServiceNow
    ↓ (HTTP POST)
Azure API Management (task360-apim)
    ↓ (Routes to Event Hub)
Azure Event Hubs (task360eventhubs)
    ├─→ task360-events (Tasks)
    ├─→ task360-requests (Requests) 
    └─→ task360-approvals (Approvals)
        ↓
    Consumer Group: task360-workers
        ↓
Azure Function (Task360CosmosFunction)
    ├─→ ProcessServiceNowTask
    ├─→ ProcessServiceNowRequest
    └─→ ProcessServiceNowApproval
        ↓ (Upsert operations)
Azure Cosmos DB (task360cosmosdb)
    └─→ Database: Task360DB
        └─→ Container: Tasks
```

### 2. Event Hub Triggers

**Three EventHub-triggered functions** process events in parallel:

| Function | Event Hub | Consumer Group | Record Types |
|----------|-----------|----------------|--------------|
| ProcessServiceNowTask | task360-events | task360-workers | task |
| ProcessServiceNowRequest | task360-requests | task360-workers | sc_req_item, sc_request |
| ProcessServiceNowApproval | task360-approvals | task360-workers | sysapproval_approver |

**Batch Processing Configuration:**
- **maxBatchSize**: 100 events per batch
- **prefetchCount**: 300 events prefetched for performance
- **batchCheckpointFrequency**: 1 (checkpoint after each batch)

### 3. Cosmos DB Data Model

**Database**: `Task360DB`
**Container**: `Tasks`
**Partition Key**: `/sourceTaskId` (sys_id field from ServiceNow)

**Document Schema** (22 fields):

```json
{
  "id": "{sys_id}",
  "sourceTaskId": "{sys_id}",
  "recordType": "task|sc_req_item|sysapproval_approver",
  "category": "Task|Request|Approval",
  "number": "TASK0010001",
  "shortDescription": "Install new software",
  "description": "Full description text...",
  "state": "Open|In Progress|Closed",
  "priority": "1|2|3|4|5",
  "assignedTo": "user@company.com",
  "assignmentGroup": "IT Support",
  "requestedFor": "user@company.com",
  "openedBy": "user@company.com",
  "openedAt": "2026-02-05T10:30:00Z",
  "closedAt": "2026-02-05T15:45:00Z",
  "sysCreatedOn": "2026-02-05T10:00:00Z",
  "sysUpdatedOn": "2026-02-05T15:00:00Z",
  "approver": "approver@company.com",
  "approvalState": "Pending|Approved|Rejected",
  "comments": "Additional comments...",
  "workNotes": "Internal work notes...",
  "lastSyncedAt": "2026-02-05T16:00:00Z"
}
```

**Key Design Decisions:**

1. **Unified Container**: All record types (Tasks, Requests, Approvals) stored in single container
   - Simplifies queries and management
   - `recordType` field discriminates between types
   - `category` field provides high-level grouping

2. **Partition Key Strategy**: Using `sourceTaskId` (ServiceNow sys_id)
   - Each task/request/approval is a unique logical partition
   - Optimal for single-document lookups by ID
   - Enables efficient upsert operations (update or insert)

3. **Serverless Tier**: Using Cosmos DB serverless capacity mode
   - Pay-per-request pricing model
   - No reserved throughput (RU/s) to manage
   - Ideal for variable/unpredictable workloads

### 4. Authentication & Security

**Identity-Based Authentication** (no connection strings or keys):

```
DefaultAzureCredential Chain:
  Local Development → Azure CLI credential
  Azure Deployment → Managed Identity credential
```

**RBAC Roles Required:**

| Service | Role | Principal | Purpose |
|---------|------|-----------|---------|
| Cosmos DB (task360cosmosdb) | Cosmos DB Data Contributor | Function Managed Identity / User | Read/write documents |
| Event Hubs (task360eventhubs) | Azure Event Hubs Data Receiver | Function Managed Identity / User | Consume events |
| Key Vault (task360-kv-2418) | Key Vault Secrets Get/List | Function Managed Identity / User | Access secrets |
| Storage Account (task360storage2) | Storage Blob Data Contributor | Function Managed Identity / User | EventHub checkpointing |

**Network Security:**

- **Cosmos DB**: Public network access enabled, IP firewall configured
  - Allowed IP: 136.57.50.25 (developer local IP)
  - Production: Restrict to Azure Function public IPs or use Private Endpoints

- **Key Vault**: Public network access enabled for local development
  - Production: Consider Private Link or VNet integration

### 5. Configuration

**Local Development (local.settings.json):**
```json
{
  "AzureWebJobsStorage": "UseDevelopmentStorage=true",
  "EventHubConnectionString__fullyQualifiedNamespace": "task360eventhubs.servicebus.windows.net",
  "CosmosDbEndpoint": "https://task360cosmosdb.documents.azure.com:443/",
  "CosmosDbDatabaseName": "Task360DB",
  "CosmosDbContainerName": "Tasks",
  "KeyVaultUrl": "https://task360-kv-2418.vault.azure.net/"
}
```

**Azure Deployment:**
- Managed Identity enabled on Function App
- All settings configured as Application Settings
- Connection strings use identity-based format (`__fullyQualifiedNamespace` suffix)

### 6. Operational Characteristics

**Checkpointing & State Management:**
- EventHub consumer positions stored in Azure Blob Storage
- Checkpoint blobs created per partition: `azure-webjobs-eventhub/{hub-name}/{consumer-group}/{partition-id}`
- Local development: Azurite emulator provides blob storage
- Production: Azure Storage Account (task360storage2)

**Error Handling:**
- Per-event try-catch blocks prevent batch failures
- Failed events logged with details (SequenceNumber, SourceID, error)
- Batch processing continues even if individual events fail
- Metrics logged: Success count, Failure count, Total count

**Scalability:**
- Event Hub partitions: 8 partitions across task360-events, task360-requests, task360-approvals
- Function scales out: One instance per partition (max 8 concurrent instances per function)
- Cosmos DB: Serverless auto-scales based on request load
- No manual throughput provisioning required

### 7. Comparison to Dataverse Implementation

| Aspect | Dataverse (Original) | Cosmos DB (New) |
|--------|---------------------|-----------------|
| **Trigger** | Timer (1 min poll) | EventHub (real-time) |
| **Data Source** | ServiceNow API | Event Hubs |
| **Latency** | Up to 1 minute delay | Near real-time (seconds) |
| **Authentication** | OAuth Client ID/Secret | Managed Identity (RBAC) |
| **Schema** | Dataverse entity definitions | Flexible JSON schema |
| **Partition Strategy** | Dataverse managed | Custom (by sys_id) |
| **Pricing Model** | Per-user licensing | Serverless pay-per-request |
| **Query Language** | OData/FetchXML | SQL (Cosmos DB SQL API) |

### 8. Deployment Resources

**Azure Resources (West US 2 region):**

- **Resource Group**: Task360-RG
- **Cosmos DB Account**: task360cosmosdb (Serverless, West US 2)
- **Event Hubs Namespace**: task360eventhubs
- **Storage Account**: task360storage2 (Standard LRS)
- **Key Vault**: task360-kv-2418 (East US)
- **Function App**: TBD (planned for Azure deployment)

**Infrastructure as Code:**
- Deployment script: `Deploy.ps1` (PowerShell)
- Provisions Function App with System Managed Identity
- Grants all required RBAC roles automatically
- Configures application settings

### 9. Monitoring & Observability

**Logging:**
- Application Insights integration (configured via `APPINSIGHTS_INSTRUMENTATIONKEY`)
- Structured logging with emojis for easy parsing:
  - 🚀 Function start
  - 📨 Event received
  - ✓ Parse success
  - ✅ Upsert success
  - ❌ Errors
  - ⚠️ Warnings

**Metrics Tracked:**
- Events processed per batch
- Success/failure counts
- Processing duration
- Cosmos DB RU consumption
- EventHub consumer lag

**Diagnostic Queries:**
- Filter by Category: `category = "Task"`
- Filter by RecordType: `recordType = "task"`
- Time range queries: `lastSyncedAt >= "2026-02-05T00:00:00Z"`

### 10. Future Enhancements

**Potential Improvements:**

1. **Change Feed Integration**: Enable Cosmos DB change feed for downstream processing
2. **Time-to-Live (TTL)**: Auto-expire old documents after retention period
3. **Analytics Store**: Enable analytical storage for BI/reporting without affecting transactional workload
4. **Private Endpoints**: Replace public network access with Azure Private Link
5. **Multi-region Replication**: Add read replicas in additional regions for global access
6. **Hierarchical Partition Keys**: Upgrade to HPK for better scalability (recordType + sourceTaskId)

---

## Summary

The Cosmos DB architecture provides a **modern, cloud-native alternative** to the Dataverse implementation with:
- ✅ Real-time event processing (vs. 1-minute polling)
- ✅ Identity-based security (no secrets management)
- ✅ Serverless cost model (pay only for usage)
- ✅ Flexible schema (easy to extend with new fields)
- ✅ Horizontal scalability (auto-scales with event volume)

Both implementations can run **side-by-side**, consuming from the same Event Hubs using different consumer groups, enabling gradual migration or A/B testing strategies.
