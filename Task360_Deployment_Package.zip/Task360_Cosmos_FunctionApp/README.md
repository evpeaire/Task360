# Task360 Cosmos DB Function - ServiceNow to Cosmos DB Integration

## Overview

This Azure Function is an **exact replica** of the Task360 Dataverse function, but writes to **Cosmos DB** instead of Dataverse. It captures ServiceNow task changes from Event Hub and stores them in a Cosmos DB database with the same structure as the Dataverse table.

### Architecture Flow

```
ServiceNow Task Update
    ↓
Business Rule (triggers on task changes)
    ↓
REST Message (HTTPS POST)
    ↓
Azure API Management
    ↓ (Managed Identity authentication)
Event Hub (message queue)
    ↓
Azure Function (this function)
    ↓
Cosmos DB (NoSQL database)
```

---

## Azure Resources Created

### Cosmos DB Account
- **Name**: `task360cosmosdb`
- **Resource Group**: `Task360-RG`
- **Subscription**: `3b2b9c8d-4c89-4560-96e0-4b9972520ff2`
- **Location**: `westus2`
- **API**: NoSQL (Core SQL API)
- **Capacity Mode**: Serverless (pay-per-use, cost-effective for development)
- **Endpoint**: `https://task360cosmosdb.documents.azure.com:443/`

### Database Structure
- **Database**: `Task360DB`
- **Container**: `Tasks`
- **Partition Key**: `/sourceTaskId` 
  - Uses sys_id from ServiceNow as partition key (unique per task)
  - Ensures efficient data distribution and fast lookups

### Document Schema (Matches Dataverse Table)

Each document in Cosmos DB has the same fields as the Dataverse `new_task` table:

```json
{
  "id": "guid",                          // Cosmos DB document ID (auto-generated)
  "sourceSystem": "ServiceNow",          
  "sourceTaskId": "sys_id_value",        // Partition key field
  "title": "Task title",
  "sourceRecordType": "task|sc_request|sysapproval_approver",
  "priority": 65,                        // Normalized 0-100
  "sourcePriority": "3",                 // Original ServiceNow priority
  "status": "in_progress",               // Normalized status
  "sourceStatus": "2",                   // Original ServiceNow state
  "category": "Task|Request|Approval",
  "assignedToEmail": "user@example.com",
  "assignedToName": "User Name",
  "approverEmail": "approver@example.com",  // For approvals
  "requesterEmail": "requester@example.com",
  "createdDate": "2026-01-29T10:00:00Z",
  "lastModifiedDate": "2026-01-29T14:30:00Z",
  "dueDate": "2026-02-05T17:00:00Z",
  "description": "Task description and work notes",
  "deepLink": "https://dev186866.service-now.com/task.do?sys_id=xxx",
  "metadataJson": "{...}",               // Full ServiceNow JSON
  "_ts": 1706537400                      // Cosmos DB timestamp
}
```

---

## Project Files

### Core Files
- **`Task360CosmosFunction.csproj`** - Project file with NuGet dependencies
  - `Microsoft.Azure.Cosmos` - Cosmos DB SDK
  - `Azure.Identity` - For Managed Identity authentication
  - `Azure.Security.KeyVault.Secrets` - For Key Vault access
  - `Microsoft.Azure.WebJobs.Extensions.EventHubs` - Event Hub trigger
  
- **`host.json`** - Function app configuration
  - Event Hub batch processing settings
  - Application Insights logging

- **`local.settings.json`** - Local development configuration
  - Event Hub connection
  - Cosmos DB endpoint
  - Key Vault URL

### Function Code
- **`ProcessServiceNowToCosmos.cs`** - Main function logic
  - 3 functions for different event sources:
    - `ProcessServiceNowTask` - Handles task360-events
    - `ProcessServiceNowRequest` - Handles task360-requests
    - `ProcessServiceNowApproval` - Handles task360-approvals
  - Processes events in batches
  - Upserts documents to Cosmos DB using hierarchical partition key

- **`CosmosDbHelper.cs`** - Cosmos DB connection helper
  - Initializes Cosmos Client with Managed Identity
  - Creates database and container if they don't exist
  - Provides container access to functions

- **`KeyVaultHelper.cs`** - Key Vault access helper
  - Retrieves secrets using Managed Identity
  - Used for any sensitive configuration

---

## Cosmos DB Setup

The Cosmos DB resources are created automatically on first function execution through the `CosmosDbHelper` class. However, you can also create them manually:

### Option 1: Automatic Creation (Recommended)
The function will automatically create the database and container on first run using these settings:
- Database: `Task360DB`
- Container: `Tasks`
- Partition Key: `/sourceSystem` and `/sourceTaskId` (hierarchical)

### Option 2: Manual Creation via Azure Portal
1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to your Cosmos DB account: `task360cosmosdb`
3. Click "Data Explorer"
4. Create new database:
   - Database id: `Task360DB`
   - Throughput: Serverless
5. Create new container:
   - Database: `Task360DB`
   - Container id: `Tasks`
   - Partition key: `/sourceTaskId`

### Option 3: Manual Creation via Azure CLI
```bash
# Create database
az cosmosdb sql database create \
  --account-name task360cosmosdb \
  --resource-group Task360-RG \
  --name Task360DB

# Create container with partition key
az cosmosdb sql container create \
  --account-name task360cosmosdb \
  --resource-group Task360-RG \
  --database-name Task360DB \
  --name Tasks \
  --partition-key-path "/sourceTaskId"
```

---

## Configuration

### Environment Variables (local.settings.json for local dev)

```json
{
  "EventHubConnectionString__fullyQualifiedNamespace": "task360eventhubs.servicebus.windows.net",
  "CosmosDbEndpoint": "https://task360cosmosdb.documents.azure.com:443/",
  "CosmosDbDatabaseName": "Task360DB",
  "CosmosDbContainerName": "Tasks",
  "KeyVaultUrl": "https://task360-kv-2418.vault.azure.net/"
}
```

### Required Azure Resources
All these resources are already set up from the original Task360 project:
- ✅ Event Hub: `task360eventhubs.servicebus.windows.net`
- ✅ Event Hubs: `task360-events`, `task360-requests`, `task360-approvals`
- ✅ Key Vault: `task360-kv-2418`
- ✅ APIM: `task360-apim`
- ✅ ServiceNow integration configured

New resource needed:
- ✅ Cosmos DB: `task360cosmosdb` (created)

---

## Local Development & Testing

### Prerequisites
- .NET 6.0 SDK
- Azure Functions Core Tools v4
- Azure CLI (logged in)
- Access to Azure subscription `3b2b9c8d-4c89-4560-96e0-4b9972520ff2`

### Setup Steps

1. **Restore NuGet packages:**
   ```powershell
   dotnet restore
   ```

2. **Build the project:**
   ```powershell
   dotnet build
   ```

3. **Configure local settings** (already done in `local.settings.json`)

4. **Authenticate with Azure CLI:**
   ```powershell
   az login
   az account set --subscription 3b2b9c8d-4c89-4560-96e0-4b9972520ff2
   ```

5. **Run locally:**
   ```powershell
   func start
   ```

### Test the Function

To test, you can either:
1. **Use the ServiceNow UI** - Create or update a task in ServiceNow
2. **Send a test event to Event Hub** using the EventHub SDK or Azure Portal
3. **Use the test script** from the original Task360Function project

The function will:
- Connect to Event Hub using Managed Identity
- Process the event
- Connect to Cosmos DB using Managed Identity
- Upsert the document with hierarchical partition key

---

## Deployment to Azure

### Step 1: Create Function App in Azure

```powershell
# Create Function App with same configuration as the Dataverse function
az functionapp create \
  --name task360-cosmos-function \
  --resource-group Task360-RG \
  --subscription 3b2b9c8d-4c89-4560-96e0-4b9972520ff2 \
  --storage-account task360rgaa0d \
  --consumption-plan-location westus2 \
  --runtime dotnet \
  --runtime-version 6 \
  --functions-version 4 \
  --assign-identity
```

### Step 2: Configure Application Settings

```powershell
az functionapp config appsettings set \
  --name task360-cosmos-function \
  --resource-group Task360-RG \
  --subscription 3b2b9c8d-4c89-4560-96e0-4b9972520ff2 \
  --settings \
    EventHubConnectionString__fullyQualifiedNamespace=task360eventhubs.servicebus.windows.net \
    CosmosDbEndpoint=https://task360cosmosdb.documents.azure.com:443/ \
    CosmosDbDatabaseName=Task360DB \
    CosmosDbContainerName=Tasks \
    KeyVaultUrl=https://task360-kv-2418.vault.azure.net/ \
    FUNCTIONS_WORKER_RUNTIME=dotnet \
    AzureWebJobsDisableHomepage=true
```

### Step 3: Grant Managed Identity Permissions

```powershell
# Get Function App's Managed Identity
$functionIdentity = az functionapp identity show \
  --name task360-cosmos-function \
  --resource-group Task360-RG \
  --subscription 3b2b9c8d-4c89-4560-96e0-4b9972520ff2 \
  --query principalId -o tsv

# Grant Event Hub Data Receiver role
az role assignment create \
  --assignee $functionIdentity \
  --role "Azure Event Hubs Data Receiver" \
  --scope /subscriptions/3b2b9c8d-4c89-4560-96e0-4b9972520ff2/resourceGroups/Task360-RG/providers/Microsoft.EventHub/namespaces/task360eventhubs

# Grant Cosmos DB Built-in Data Contributor role
az cosmosdb sql role assignment create \
  --account-name task360cosmosdb \
  --resource-group Task360-RG \
  --subscription 3b2b9c8d-4c89-4560-96e0-4b9972520ff2 \
  --scope "/dbs/Task360DB/colls/Tasks" \
  --principal-id $functionIdentity \
  --role-definition-id 00000000-0000-0000-0000-000000000002

# Grant Key Vault Secrets User role
az role assignment create \
  --assignee $functionIdentity \
  --role "Key Vault Secrets User" \
  --scope /subscriptions/3b2b9c8d-4c89-4560-96e0-4b9972520ff2/resourceGroups/Task360-RG/providers/Microsoft.KeyVault/vaults/task360-kv-2418
```

### Step 4: Deploy Function Code

```powershell
# Publish to local folder
dotnet publish --configuration Release --output ./publish

# Create deployment package
Compress-Archive -Path ./publish/* -DestinationPath task360-cosmos-function.zip -Force

# Deploy to Azure (may require policy exemption like the original function)
az functionapp deployment source config-zip \
  --resource-group Task360-RG \
  --name task360-cosmos-function \
  --src task360-cosmos-function.zip \
  --subscription 3b2b9c8d-4c89-4560-96e0-4b9972520ff2
```

**Note**: If deployment fails due to policy restrictions (same issue as the original Task360Function), you'll need to request a temporary policy exemption. See the original `DEPLOYMENT_REQUEST.md` for reference.

---

## Differences from Dataverse Function

### What's the Same
- ✅ Reads from same Event Hubs
- ✅ Processes same event types (Tasks, Requests, Approvals)
- ✅ Same data mapping logic
- ✅ Same authentication pattern (Managed Identity)
- ✅ Same field names and structure
- ✅ Same priority and status normalization
- ✅ Same logging and error handling

### What's Different
- ❌ **Storage**: Cosmos DB instead of Dataverse
- ❌ **SDK**: `Microsoft.Azure.Cosmos` instead of `Microsoft.PowerPlatform.Dataverse.Client`
- ❌ **Query Language**: SQL queries instead of QueryExpression
- ❌ **Partition Key**: Uses single partition key (`/sourceTaskId`)
- ❌ **Document ID**: Uses GUIDs instead of Dataverse entity IDs
- ❌ **No OptionSet values**: Cosmos DB uses strings/numbers directly

---

## Monitoring & Troubleshooting

### View Function Logs
```powershell
# Stream logs from Azure
az functionapp log tail \
  --name task360-cosmos-function \
  --resource-group Task360-RG \
  --subscription 3b2b9c8d-4c89-4560-96e0-4b9972520ff2
```

### Query Cosmos DB Data
Using Azure Portal Data Explorer or Azure CLI:
```bash
# Query all tasks
az cosmosdb sql query \
  --account-name task360cosmosdb \
  --resource-group Task360-RG \
  --database-name Task360DB \
  --container-name Tasks \
  --query-text "SELECT * FROM c"

# Query specific task by sourceTaskId
az cosmosdb sql query \
  --account-name task360cosmosdb \
  --resource-group Task360-RG \
  --database-name Task360DB \
  --container-name Tasks \
  --query-text "SELECT * FROM c WHERE c.sourceSystem = 'ServiceNow' AND c.sourceTaskId = 'your-sys-id'"
```

### Common Issues

1. **"Failed to initialize Cosmos DB client"**
   - Check that Managed Identity has been granted Cosmos DB Data Contributor role
   - Verify CosmosDbEndpoint is correct

2. **"EventHub connection failed"**
   - Check that Managed Identity has Event Hubs Data Receiver role
   - Verify EventHubConnectionString__fullyQualifiedNamespace is correct

3. **"Partition key mismatch"**
   - Ensure container was created with partition key: `/sourceTaskId`

---

## Cost Considerations

### Cosmos DB Serverless Pricing
- **No minimum cost** - Pay only for what you use
- **Request Units (RUs)**: ~$0.25 per million RU/s consumed
- **Storage**: ~$0.25 per GB per month

### Estimated Costs (for typical workload)
- **1,000 events/day**: ~$0.50-$1.00/month
- **10,000 events/day**: ~$5-$10/month
- **100,000 events/day**: ~$50-$100/month

**Much cheaper than provisioned throughput for development/testing!**

---

## Next Steps

1. ✅ Cosmos DB account created
2. ✅ Function code completed
3. ⏳ Wait for Cosmos DB provisioning to complete
4. ⏳ Deploy function to Azure
5. ⏳ Grant Managed Identity permissions
6. ⏳ Test end-to-end flow

---

## Support & Documentation

- **Cosmos DB Documentation**: https://docs.microsoft.com/azure/cosmos-db/
- **Azure Functions**: https://docs.microsoft.com/azure/azure-functions/
- **Original Task360Function**: See `../Task360/Task360Function/README.md`
- **ServiceNow Integration**: See `../Task360/README.md`

---

## Author
Created as part of the Task360 ServiceNow integration project  
Date: February 4, 2026
