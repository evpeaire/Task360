using System;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;

namespace Task360CosmosFunction
{
    /// <summary>
    /// HTTP-triggered Azure Functions for Copilot Studio to query Cosmos DB tasks.
    /// These endpoints act as a bridge so Copilot Studio (in the Microsoft tenant) 
    /// can access Cosmos DB (in the Non-Production tenant) via simple HTTP calls.
    /// </summary>
    public class TaskApi
    {
        /// <summary>
        /// GET /api/tasks - List all tasks, optionally filtered by status, category, or assignee.
        /// Query params: status, category, assignedToEmail, top (default 50)
        /// </summary>
        [FunctionName("GetTasks")]
        public async Task<IActionResult> GetTasks(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "tasks")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("📋 GetTasks API called");

            try
            {
                await CosmosDbHelper.InitializeAsync();
                var container = CosmosDbHelper.GetContainer();

                // Build query from optional filters
                var conditions = new List<string>();
                var queryDef = new QueryDefinition("SELECT * FROM c");

                string status = req.Query["status"];
                string category = req.Query["category"];
                string assignedToEmail = req.Query["assignedToEmail"];
                string search = req.Query["search"];
                int top = int.TryParse(req.Query["top"], out int t) ? t : 50;

                string query = "SELECT TOP @top * FROM c";
                var parameters = new Dictionary<string, object> { { "@top", top } };

                if (!string.IsNullOrEmpty(status))
                {
                    conditions.Add("c.status = @status");
                    parameters["@status"] = status;
                }

                if (!string.IsNullOrEmpty(category))
                {
                    conditions.Add("c.category = @category");
                    parameters["@category"] = category;
                }

                if (!string.IsNullOrEmpty(assignedToEmail))
                {
                    conditions.Add("c.assignedToEmail = @assignedToEmail");
                    parameters["@assignedToEmail"] = assignedToEmail;
                }

                if (!string.IsNullOrEmpty(search))
                {
                    conditions.Add("CONTAINS(LOWER(c.title), LOWER(@search))");
                    parameters["@search"] = search;
                }

                if (conditions.Count > 0)
                {
                    query += " WHERE " + string.Join(" AND ", conditions);
                }

                query += " ORDER BY c.lastModifiedDate DESC";

                var qd = new QueryDefinition(query);
                foreach (var param in parameters)
                {
                    qd.WithParameter(param.Key, param.Value);
                }

                var results = new List<JObject>();
                var iterator = container.GetItemQueryIterator<JObject>(qd);

                while (iterator.HasMoreResults)
                {
                    var response = await iterator.ReadNextAsync();
                    results.AddRange(response);
                }

                log.LogInformation($"✅ GetTasks returned {results.Count} results");

                return new OkObjectResult(new
                {
                    count = results.Count,
                    tasks = results
                });
            }
            catch (Exception ex)
            {
                log.LogError(ex, "❌ Error in GetTasks");
                return new StatusCodeResult(500);
            }
        }

        /// <summary>
        /// GET /api/tasks/{id} - Get a specific task by its Cosmos DB id.
        /// </summary>
        [FunctionName("GetTaskById")]
        public async Task<IActionResult> GetTaskById(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "tasks/item/{id}")] HttpRequest req,
            string id,
            ILogger log)
        {
            log.LogInformation($"🔍 GetTaskById API called | ID: {id}");

            try
            {
                await CosmosDbHelper.InitializeAsync();
                var container = CosmosDbHelper.GetContainer();

                // Query by id (since we don't know the partition key value)
                var queryDef = new QueryDefinition("SELECT * FROM c WHERE c.id = @id")
                    .WithParameter("@id", id);

                var iterator = container.GetItemQueryIterator<JObject>(queryDef);

                if (iterator.HasMoreResults)
                {
                    var response = await iterator.ReadNextAsync();
                    var task = response.FirstOrDefault();

                    if (task != null)
                    {
                        log.LogInformation($"✅ Found task | ID: {id}");
                        return new OkObjectResult(task);
                    }
                }

                log.LogWarning($"⚠️ Task not found | ID: {id}");
                return new NotFoundObjectResult(new { message = $"Task with id '{id}' not found" });
            }
            catch (Exception ex)
            {
                log.LogError(ex, $"❌ Error in GetTaskById | ID: {id}");
                return new StatusCodeResult(500);
            }
        }

        /// <summary>
        /// POST /api/tasks/search - Search tasks with a JSON body.
        /// Body: { "query": "search text", "status": "pending", "category": "Task", "assignedToEmail": "user@example.com", "top": 20 }
        /// </summary>
        [FunctionName("SearchTasks")]
        public async Task<IActionResult> SearchTasks(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "tasks/search")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("🔎 SearchTasks API called");

            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var searchRequest = JObject.Parse(requestBody);

                await CosmosDbHelper.InitializeAsync();
                var container = CosmosDbHelper.GetContainer();

                var conditions = new List<string>();
                var parameters = new Dictionary<string, object>();

                int top = searchRequest["top"]?.Value<int>() ?? 50;
                parameters["@top"] = top;

                string searchText = searchRequest["query"]?.ToString();
                if (!string.IsNullOrEmpty(searchText))
                {
                    conditions.Add("(CONTAINS(LOWER(c.title), LOWER(@search)) OR CONTAINS(LOWER(c.description), LOWER(@search)) OR CONTAINS(LOWER(c.sourceTaskId), LOWER(@search)))");
                    parameters["@search"] = searchText;
                }

                string status = searchRequest["status"]?.ToString();
                if (!string.IsNullOrEmpty(status))
                {
                    conditions.Add("c.status = @status");
                    parameters["@status"] = status;
                }

                string category = searchRequest["category"]?.ToString();
                if (!string.IsNullOrEmpty(category))
                {
                    conditions.Add("c.category = @category");
                    parameters["@category"] = category;
                }

                string assignedToEmail = searchRequest["assignedToEmail"]?.ToString();
                if (!string.IsNullOrEmpty(assignedToEmail))
                {
                    conditions.Add("c.assignedToEmail = @assignedToEmail");
                    parameters["@assignedToEmail"] = assignedToEmail;
                }

                string query = "SELECT TOP @top * FROM c";
                if (conditions.Count > 0)
                {
                    query += " WHERE " + string.Join(" AND ", conditions);
                }
                query += " ORDER BY c.lastModifiedDate DESC";

                var qd = new QueryDefinition(query);
                foreach (var param in parameters)
                {
                    qd.WithParameter(param.Key, param.Value);
                }

                var results = new List<JObject>();
                var iterator = container.GetItemQueryIterator<JObject>(qd);

                while (iterator.HasMoreResults)
                {
                    var response = await iterator.ReadNextAsync();
                    results.AddRange(response);
                }

                log.LogInformation($"✅ SearchTasks returned {results.Count} results");

                return new OkObjectResult(new
                {
                    count = results.Count,
                    tasks = results
                });
            }
            catch (Exception ex)
            {
                log.LogError(ex, "❌ Error in SearchTasks");
                return new StatusCodeResult(500);
            }
        }

        /// <summary>
        /// GET /api/tasks/summary - Get a summary of tasks by status and category.
        /// Useful for Copilot Studio to give users an overview.
        /// </summary>
        [FunctionName("GetTaskSummary")]
        public async Task<IActionResult> GetTaskSummary(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "tasks/summary")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("📊 GetTaskSummary API called");

            try
            {
                await CosmosDbHelper.InitializeAsync();
                var container = CosmosDbHelper.GetContainer();

                // Get counts by status
                var statusQuery = new QueryDefinition(
                    "SELECT c.status, COUNT(1) as count FROM c GROUP BY c.status");

                var statusResults = new List<JObject>();
                var statusIterator = container.GetItemQueryIterator<JObject>(statusQuery);
                while (statusIterator.HasMoreResults)
                {
                    var response = await statusIterator.ReadNextAsync();
                    statusResults.AddRange(response);
                }

                // Get counts by category
                var categoryQuery = new QueryDefinition(
                    "SELECT c.category, COUNT(1) as count FROM c GROUP BY c.category");

                var categoryResults = new List<JObject>();
                var categoryIterator = container.GetItemQueryIterator<JObject>(categoryQuery);
                while (categoryIterator.HasMoreResults)
                {
                    var response = await categoryIterator.ReadNextAsync();
                    categoryResults.AddRange(response);
                }

                // Get total count
                var totalQuery = new QueryDefinition("SELECT VALUE COUNT(1) FROM c");
                var totalIterator = container.GetItemQueryIterator<int>(totalQuery);
                int totalCount = 0;
                if (totalIterator.HasMoreResults)
                {
                    var response = await totalIterator.ReadNextAsync();
                    totalCount = response.FirstOrDefault();
                }

                log.LogInformation($"✅ GetTaskSummary complete | Total: {totalCount}");

                return new OkObjectResult(new
                {
                    totalTasks = totalCount,
                    byStatus = statusResults,
                    byCategory = categoryResults
                });
            }
            catch (Exception ex)
            {
                log.LogError(ex, "❌ Error in GetTaskSummary");
                return new StatusCodeResult(500);
            }
        }
    }
}
