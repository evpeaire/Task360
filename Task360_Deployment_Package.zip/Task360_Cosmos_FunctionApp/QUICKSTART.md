# Quick Start Guide - Task360 Cosmos DB Function

## ✅ What Has Been Created

### Azure Resources
- **Cosmos DB Account**: `task360cosmosdb`
  - Location: West US 2
  - Capacity: Serverless (pay-per-use)
  - Endpoint: `https://task360cosmosdb.documents.azure.com:443/`
  
- **Database**: `Task360DB`
  - Created and ready to use
  
- **Container**: `Tasks`
  - Partition Key: `/sourceTaskId`
  - Ready to store task documents

### Function Code
All function code has been created in the `Task360_Cosmos` folder:
- ✅ `Task360CosmosFunction.csproj` - Project file
- ✅ `ProcessServiceNowToCosmos.cs` - Main function (3 functions for Tasks, Requests, Approvals)
- ✅ `CosmosDbHelper.cs` - Cosmos DB connection helper
- ✅ `KeyVaultHelper.cs` - Key Vault helper
- ✅ `host.json` - Function configuration
- ✅ `local.settings.json` - Local settings
- ✅ `Deploy.ps1` - Deployment script
- ✅ `README.md` - Comprehensive documentation

### Build Status
✅ Project builds successfully with no errors!

---

## 🚀 Next Steps to Deploy

### Option 1: Automated Deployment (Recommended)

Run the deployment script which will:
1. Create the Function App in Azure
2. Configure all application settings
3. Grant Managed Identity permissions
4. Build and package the function
5. Deploy to Azure

```powershell
cd 'c:\Users\evpeaire\OneDrive - Microsoft\Documents 1\Barclays\Task360_Cosmos'
.\Deploy.ps1
```

### Option 2: Manual Deployment

See the detailed steps in [README.md](README.md) under "Deployment to Azure" section.

---

## 📊 What This Function Does

This function is an **exact replica** of the Task360Function that writes to Dataverse, but instead writes to Cosmos DB:

1. **Listens to Event Hubs**:
   - `task360-events` → Tasks
   - `task360-requests` → Service Catalog Requests
   - `task360-approvals` → Approvals

2. **Processes ServiceNow Events**:
   - Maps ServiceNow fields to unified schema
   - Normalizes priority (1-5 → 0-100)
   - Normalizes status (state → pending/in_progress/completed/cancelled)

3. **Writes to Cosmos DB**:
   - Upserts documents using `sourceTaskId` as partition key
   - Stores all the same fields as Dataverse table
   - Includes full ServiceNow JSON in `metadataJson` field

---

## 🔍 Verifying the Setup

### Check Cosmos DB Resources
```powershell
# List databases
az cosmosdb sql database list --account-name task360cosmosdb --resource-group Task360-RG

# List containers
az cosmosdb sql container list --account-name task360cosmosdb --database-name Task360DB --resource-group Task360-RG
```

### Query Cosmos DB After Function Runs
```powershell
# Query all tasks
az cosmosdb sql query `
  --account-name task360cosmosdb `
  --resource-group Task360-RG `
  --database-name Task360DB `
  --container-name Tasks `
  --query-text "SELECT * FROM c"
```

---

## 💰 Cost Estimate

With **Serverless** capacity mode:
- **No minimum cost** when not in use
- Typical usage: **$5-10/month** for moderate workload
- **Much cheaper** than provisioned throughput for dev/test

---

## 🔄 Data Structure Comparison

### Cosmos DB Document (what we store)
```json
{
  "id": "abc123-guid",
  "sourceSystem": "ServiceNow",
  "sourceTaskId": "sys_id_from_servicenow",
  "title": "Fix production bug",
  "status": "in_progress",
  "priority": 85,
  "category": "Task",
  "assignedToEmail": "user@example.com",
  ...
}
```

### Dataverse Entity (original)
```
new_task:
- new_title: "Fix production bug"
- new_status: OptionSet(2)
- new_priority: 85
- new_sourcesystem: "ServiceNow"
- new_sourcetaskid: "sys_id_from_servicenow"
```

**Same data, different storage!**

---

## 📝 Important Notes

1. **Managed Identity Required**: The function uses Managed Identity to connect to:
   - Event Hubs
   - Cosmos DB
   - Key Vault

2. **Same Event Hubs**: Uses the existing Event Hubs from the Dataverse function

3. **No Code Changes in ServiceNow**: ServiceNow still sends to APIM → Event Hub (no changes needed)

4. **Can Run Alongside Dataverse Function**: Both functions can run at the same time!

---

## ❓ Troubleshooting

### Build Failed?
```powershell
cd 'c:\Users\evpeaire\OneDrive - Microsoft\Documents 1\Barclays\Task360_Cosmos'
dotnet restore
dotnet build
```

### Deployment Failed?
If you get a storage policy error, you'll need to request a policy exemption (same as the original Task360Function). See [README.md](README.md) for details.

### Function Not Receiving Events?
Check that Managed Identity has "Azure Event Hubs Data Receiver" role on the Event Hub namespace.

### Can't Write to Cosmos DB?
Check that Managed Identity has "Cosmos DB Built-in Data Contributor" role on the Cosmos DB account.

---

## 📖 Full Documentation

For complete details, see [README.md](README.md)

---

## ✨ Summary

You now have:
- ✅ Cosmos DB account, database, and container
- ✅ Azure Function code that mirrors the Dataverse function
- ✅ Same data structure as Dataverse table
- ✅ Ready to deploy and test
- ✅ Comprehensive documentation

**Next step**: Run `.\Deploy.ps1` to deploy to Azure!
