# Task360 Cosmos DB Function - Deployment Script
# This script deploys the Azure Function to Azure

param(
    [Parameter(Mandatory=$false)]
    [string]$ResourceGroup = "Task360-RG",
    
    [Parameter(Mandatory=$false)]
    [string]$FunctionAppName = "task360-cosmos-function",
    
    [Parameter(Mandatory=$false)]
    [string]$Subscription = "3b2b9c8d-4c89-4560-96e0-4b9972520ff2",
    
    [Parameter(Mandatory=$false)]
    [string]$Location = "westus2",
    
    [Parameter(Mandatory=$false)]
    [string]$StorageAccount = "task360rgaa0d",
    
    [Parameter(Mandatory=$false)]
    [string]$CosmosAccount = "task360cosmosdb"
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Task360 Cosmos DB Function Deployment" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Set subscription
Write-Host "Setting subscription..." -ForegroundColor Yellow
az account set --subscription $Subscription

# Check if Function App exists
Write-Host "Checking if Function App exists..." -ForegroundColor Yellow
$existingApp = az functionapp show --name $FunctionAppName --resource-group $ResourceGroup --subscription $Subscription 2>$null

if (-not $existingApp) {
    Write-Host "Creating Function App..." -ForegroundColor Green
    az functionapp create `
        --name $FunctionAppName `
        --resource-group $ResourceGroup `
        --subscription $Subscription `
        --storage-account $StorageAccount `
        --consumption-plan-location $Location `
        --runtime dotnet `
        --runtime-version 6 `
        --functions-version 4 `
        --assign-identity
    
    Write-Host "Function App created successfully!" -ForegroundColor Green
} else {
    Write-Host "Function App already exists, skipping creation." -ForegroundColor Yellow
}

# Configure Application Settings
Write-Host "Configuring application settings..." -ForegroundColor Yellow
az functionapp config appsettings set `
    --name $FunctionAppName `
    --resource-group $ResourceGroup `
    --subscription $Subscription `
    --settings `
        EventHubConnectionString__fullyQualifiedNamespace=task360eventhubs.servicebus.windows.net `
        CosmosDbEndpoint=https://$CosmosAccount.documents.azure.com:443/ `
        CosmosDbDatabaseName=Task360DB `
        CosmosDbContainerName=Tasks `
        KeyVaultUrl=https://task360-kv-2418.vault.azure.net/ `
        FUNCTIONS_WORKER_RUNTIME=dotnet `
        AzureWebJobsDisableHomepage=true

Write-Host "Application settings configured!" -ForegroundColor Green

# Get Function App's Managed Identity
Write-Host "Getting Function App Managed Identity..." -ForegroundColor Yellow
$functionIdentity = az functionapp identity show `
    --name $FunctionAppName `
    --resource-group $ResourceGroup `
    --subscription $Subscription `
    --query principalId -o tsv

Write-Host "Managed Identity: $functionIdentity" -ForegroundColor Cyan

# Grant Event Hub Data Receiver role
Write-Host "Granting Event Hub Data Receiver role..." -ForegroundColor Yellow
az role assignment create `
    --assignee $functionIdentity `
    --role "Azure Event Hubs Data Receiver" `
    --scope "/subscriptions/$Subscription/resourceGroups/$ResourceGroup/providers/Microsoft.EventHub/namespaces/task360eventhubs"

# Grant Cosmos DB Built-in Data Contributor role
Write-Host "Granting Cosmos DB Data Contributor role..." -ForegroundColor Yellow
az cosmosdb sql role assignment create `
    --account-name $CosmosAccount `
    --resource-group $ResourceGroup `
    --subscription $Subscription `
    --scope "/" `
    --principal-id $functionIdentity `
    --role-definition-id "00000000-0000-0000-0000-000000000002"

# Grant Key Vault Secrets User role
Write-Host "Granting Key Vault Secrets User role..." -ForegroundColor Yellow
az role assignment create `
    --assignee $functionIdentity `
    --role "Key Vault Secrets User" `
    --scope "/subscriptions/$Subscription/resourceGroups/$ResourceGroup/providers/Microsoft.KeyVault/vaults/task360-kv-2418"

Write-Host "Permissions granted successfully!" -ForegroundColor Green

# Build and publish
Write-Host "Building project..." -ForegroundColor Yellow
dotnet clean
dotnet build --configuration Release

Write-Host "Publishing project..." -ForegroundColor Yellow
dotnet publish --configuration Release --output ./publish

# Create deployment package
Write-Host "Creating deployment package..." -ForegroundColor Yellow
if (Test-Path "task360-cosmos-function.zip") {
    Remove-Item "task360-cosmos-function.zip" -Force
}
Compress-Archive -Path ./publish/* -DestinationPath task360-cosmos-function.zip -Force

Write-Host "Deployment package created!" -ForegroundColor Green

# Deploy to Azure
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Ready to Deploy!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Deployment package: task360-cosmos-function.zip" -ForegroundColor Yellow
Write-Host ""
Write-Host "To deploy, run:" -ForegroundColor Yellow
Write-Host "az functionapp deployment source config-zip \" -ForegroundColor White
Write-Host "  --resource-group $ResourceGroup \" -ForegroundColor White
Write-Host "  --name $FunctionAppName \" -ForegroundColor White
Write-Host "  --src task360-cosmos-function.zip \" -ForegroundColor White
Write-Host "  --subscription $Subscription" -ForegroundColor White
Write-Host ""
Write-Host "NOTE: If deployment fails due to storage policy restrictions," -ForegroundColor Red
Write-Host "      you may need to request a policy exemption." -ForegroundColor Red
Write-Host "      See DEPLOYMENT_REQUEST.md for reference." -ForegroundColor Red
Write-Host ""

$deploy = Read-Host "Do you want to attempt deployment now? (y/n)"
if ($deploy -eq 'y' -or $deploy -eq 'Y') {
    Write-Host "Attempting deployment..." -ForegroundColor Yellow
    az functionapp deployment source config-zip `
        --resource-group $ResourceGroup `
        --name $FunctionAppName `
        --src task360-cosmos-function.zip `
        --subscription $Subscription
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "========================================" -ForegroundColor Green
        Write-Host "Deployment Successful!" -ForegroundColor Green
        Write-Host "========================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "Function App: $FunctionAppName" -ForegroundColor Cyan
        Write-Host "Resource Group: $ResourceGroup" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "View logs:" -ForegroundColor Yellow
        Write-Host "az functionapp log tail --name $FunctionAppName --resource-group $ResourceGroup" -ForegroundColor White
    } else {
        Write-Host ""
        Write-Host "========================================" -ForegroundColor Red
        Write-Host "Deployment Failed" -ForegroundColor Red
        Write-Host "========================================" -ForegroundColor Red
        Write-Host ""
        Write-Host "This is likely due to storage policy restrictions." -ForegroundColor Yellow
        Write-Host "Please request a policy exemption and try again." -ForegroundColor Yellow
    }
} else {
    Write-Host ""
    Write-Host "Deployment skipped. You can deploy manually later." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Script completed!" -ForegroundColor Green
