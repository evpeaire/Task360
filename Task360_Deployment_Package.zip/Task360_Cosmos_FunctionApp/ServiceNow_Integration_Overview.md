# Task360: ServiceNow Integration Architecture

## How Updated Tasks Flow from ServiceNow to Azure Cosmos DB

### Executive Summary

The Task360 platform captures task, request, and approval updates from ServiceNow in **near real-time** using an event-driven architecture. Rather than polling the ServiceNow API on a schedule, the system receives change events as they occur and persists them into Azure Cosmos DB within seconds. This document describes the end-to-end data flow, the transformation logic, and the key design decisions behind the integration.

---

### Architecture Overview

```
ServiceNow Instance
        │
        │  HTTP POST (on record change)
        ▼
Azure API Management (task360-apim)
        │
        │  Routes by record type
        ▼
Azure Event Hubs (task360eventhubs)
  ┌─────┼─────────────────────┐
  │     │                     │
  ▼     ▼                     ▼
 Tasks  Requests          Approvals
  │     │                     │
  └─────┼─────────────────────┘
        │  Consumer Group: task360-workers
        ▼
Azure Functions (Task360CosmosFunction)
  ┌─────┼─────────────────────┐
  │     │                     │
  ▼     ▼                     ▼
 ProcessServiceNowTask        │
        ProcessServiceNowRequest
              ProcessServiceNowApproval
        │
        │  Upsert (insert or update)
        ▼
Azure Cosmos DB (task360cosmosdb)
  └─ Database: Task360DB
       └─ Container: Tasks
```

---

### How It Works

#### 1. ServiceNow Pushes Events

When a task, request, or approval is created or updated in ServiceNow, a business rule sends the record as a JSON payload via HTTP POST to Azure API Management. APIM routes the event to the appropriate Event Hub topic based on record type:

| Record Type | Event Hub Topic |
|---|---|
| Tasks | `task360-events` |
| Requests (`sc_request`, `sc_req_item`) | `task360-requests` |
| Approvals (`sysapproval_approver`) | `task360-approvals` |

#### 2. Azure Functions Consume Events

Three Azure Functions are triggered automatically when events arrive on their respective Event Hub topics. Events are delivered in **batches** (up to 100 per batch) and processed in **parallel** (up to 50 concurrent writes) for throughput efficiency.

| Function | Trigger | What It Processes |
|---|---|---|
| `ProcessServiceNowTask` | `task360-events` | Task records |
| `ProcessServiceNowRequest` | `task360-requests` | Service catalog requests and request items |
| `ProcessServiceNowApproval` | `task360-approvals` | Approval records |

Each function shares the same consumer group (`task360-workers`) and applies identical transformation logic.

#### 3. Data Transformation

Each incoming ServiceNow event is transformed into a **unified document schema** before being written to Cosmos DB. Key transformations include:

**Priority Normalization** — ServiceNow's 1–5 priority scale is mapped to a 0–100 normalized scale:

| ServiceNow Priority | Normalized Value | Label |
|---|---|---|
| 1 | 100 | Critical |
| 2 | 85 | High |
| 3 | 65 | Moderate |
| 4 | 40 | Low |
| 5 | 20 | Planning |

**Status Normalization** — ServiceNow state codes are mapped to human-readable statuses:

| ServiceNow State | Normalized Status |
|---|---|
| 1 (New) | Pending |
| 2 (In Progress) | In Progress |
| 3 (Resolved) | Completed |
| 7 (Closed) | Completed |
| 4 (Cancelled) | Cancelled |

**User Field Mapping** — Assignments, approvers, and requesters are mapped differently depending on record type (task, request, or approval) to ensure consistent downstream consumption.

**Date Mapping** — ServiceNow date fields (`opened_at`, `sys_updated_on`, `due_date`) are parsed and stored as typed date values.

**Deep Link Generation** — A direct URL back to the source record in ServiceNow is generated and stored on each document for easy cross-reference.

#### 4. Upsert to Cosmos DB

Each document is written using an **upsert** operation — if the record already exists (matched by `sys_id`), it is updated in place; if it is new, it is inserted. This makes the process fully **idempotent**: re-processing the same event produces the same result with no duplicates.

All record types are stored in a **single unified container** (`Tasks`), differentiated by `category` (Task, Request, or Approval) and `sourceRecordType` fields.

---

### Key Design Decisions

| Decision | Rationale |
|---|---|
| **Event-driven (push) over polling** | Near real-time data freshness (seconds vs. up to 1 minute with polling). Eliminates unnecessary API calls when nothing has changed. |
| **Single unified container** | Simplifies queries, reduces management overhead, and allows cross-type queries (e.g., "show all work for user X"). |
| **`sys_id` as partition key** | High cardinality ensures even data distribution. Optimized for single-document lookups, which is the most common access pattern. |
| **Idempotent upserts** | Deterministic document IDs (based on `sys_id`) ensure safe reprocessing without duplicates. |
| **Parallel batch processing** | Up to 50 concurrent writes per batch maximizes throughput while preventing Cosmos DB throttling. |
| **Cosmos DB Serverless tier** | Pay-per-request pricing eliminates the need to provision or manage throughput (RU/s). Cost-effective for variable workloads. |

---

### Security & Authentication

The integration uses **identity-based authentication** throughout — no connection strings or secrets are stored in code or configuration.

- **Cosmos DB**: Accessed via Managed Identity with the `Cosmos DB Data Contributor` RBAC role.
- **Event Hubs**: Consumed via Managed Identity with the `Azure Event Hubs Data Receiver` role.
- **Key Vault**: Accessed via Managed Identity for any additional secrets.
- **Network**: Cosmos DB is IP-restricted; production deployment will use Private Endpoints for full network isolation.

---

### Error Handling & Resilience

- Each event is processed independently within a batch. A failure on one event does **not** block the rest of the batch.
- Failed events are logged with full diagnostic detail (sequence number, source ID, error message).
- Batch completion metrics (success count, failure count, total) are logged for every invocation.
- Event Hub **checkpointing** ensures that if the function restarts, processing resumes from the last successfully committed position — no events are lost.

---

### Monitoring

- **Application Insights** is integrated for distributed tracing, performance metrics, and alerting.
- Structured logging provides clear visibility into each processing step.
- Key metrics tracked: events received, successful upserts, failures, and processing duration.

---

### Summary

The ServiceNow-to-Cosmos DB integration delivers a reliable, near real-time sync of task, request, and approval data. By using an event-driven architecture with Azure Event Hubs and Azure Functions, the system reacts to changes as they happen in ServiceNow, transforms them into a unified schema, and persists them in Cosmos DB — ready for downstream consumption by the Task360 platform.
