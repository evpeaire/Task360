using System;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;
using Azure.Identity;

namespace Task360CosmosFunction
{
    public static class CosmosDbHelper
    {
        private static CosmosClient _cosmosClient;
        private static Database _database;
        private static Container _container;
        private static bool _initialized = false;

        public static async Task InitializeAsync()
        {
            if (_initialized)
                return;

            try
            {
                var endpoint = Environment.GetEnvironmentVariable("CosmosDbEndpoint");
                var databaseName = Environment.GetEnvironmentVariable("CosmosDbDatabaseName");
                var containerName = Environment.GetEnvironmentVariable("CosmosDbContainerName");

                // Use DefaultAzureCredential for authentication (Managed Identity in Azure, Azure CLI locally)
                var credential = new DefaultAzureCredential(new DefaultAzureCredentialOptions
                {
                    ExcludeManagedIdentityCredential = false
                });

                _cosmosClient = new CosmosClient(endpoint, credential, new CosmosClientOptions
                {
                    AllowBulkExecution = true
                });

                // Create database if it doesn't exist
                DatabaseResponse databaseResponse = await _cosmosClient.CreateDatabaseIfNotExistsAsync(databaseName);
                _database = databaseResponse.Database;

                // Create container if it doesn't exist
                // Using /sourceTaskId as partition key (sys_id is unique per task)
                ContainerProperties containerProperties = new ContainerProperties
                {
                    Id = containerName,
                    PartitionKeyPath = "/sourceTaskId"
                };

                ContainerResponse containerResponse = await _database.CreateContainerIfNotExistsAsync(containerProperties);
                _container = containerResponse.Container;

                _initialized = true;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to initialize Cosmos DB client: {ex.Message}", ex);
            }
        }

        public static Container GetContainer()
        {
            if (!_initialized)
                throw new InvalidOperationException("CosmosDbHelper not initialized. Call InitializeAsync first.");

            return _container;
        }

        public static CosmosClient GetClient()
        {
            if (!_initialized)
                throw new InvalidOperationException("CosmosDbHelper not initialized. Call InitializeAsync first.");

            return _cosmosClient;
        }
    }
}
