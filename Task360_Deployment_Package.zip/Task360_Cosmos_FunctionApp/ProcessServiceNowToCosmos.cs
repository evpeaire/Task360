using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Azure.Messaging.EventHubs;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json.Linq;
using System.Linq;

namespace Task360CosmosFunction
{
    public class ProcessServiceNowToCosmos
    {
        // Processes all ServiceNow events (tasks, requests, approvals) into unified Cosmos DB container
        [FunctionName("ProcessServiceNowTask")]
        public async Task ProcessTask(
            [EventHubTrigger("task360-events", Connection = "EventHubConnectionString", ConsumerGroup = "task360-workers")] EventData[] events,
            ILogger log)
        {
            await ProcessEvents(events, log, "task", "Task");
        }

        [FunctionName("ProcessServiceNowRequest")]
        public async Task ProcessRequest(
            [EventHubTrigger("task360-requests", Connection = "EventHubConnectionString", ConsumerGroup = "task360-workers")] EventData[] events,
            ILogger log)
        {
            await ProcessEvents(events, log, null, "Request");
        }

        [FunctionName("ProcessServiceNowApproval")]
        public async Task ProcessApproval(
            [EventHubTrigger("task360-approvals", Connection = "EventHubConnectionString", ConsumerGroup = "task360-workers")] EventData[] events,
            ILogger log)
        {
            await ProcessEvents(events, log, "sysapproval_approver", "Approval");
        }

        private static readonly int MaxParallelism = 50;

        private async Task ProcessEvents(EventData[] events, ILogger log, string expectedRecordType, string category)
        {
            log.LogInformation($"🚀 Function started processing {events.Length} {category} events from Event Hub (parallelism: {MaxParallelism})");
            
            // Initialize Cosmos DB if not already done
            await CosmosDbHelper.InitializeAsync();
            
            int successCount = 0;
            int failureCount = 0;

            // Use SemaphoreSlim to limit concurrent Cosmos DB writes
            var semaphore = new SemaphoreSlim(MaxParallelism, MaxParallelism);
            var tasks = new List<Task>(events.Length);

            foreach (EventData eventData in events)
            {
                tasks.Add(Task.Run(async () =>
                {
                    await semaphore.WaitAsync();
                    string sourceTaskId = "unknown";
                    try
                    {
                        string messageBody = Encoding.UTF8.GetString(eventData.EventBody.ToArray());
                        log.LogTrace($"📨 Received {category} event | SequenceNumber: {eventData.SequenceNumber}");

                        var data = JObject.Parse(messageBody);
                        
                        // Get record type from the event
                        string recordType = data["record_type"]?.ToString() ?? expectedRecordType;
                        if (recordType == null)
                        {
                            log.LogWarning($"⚠️ No record_type found in event, skipping | SequenceNumber: {eventData.SequenceNumber}");
                            Interlocked.Increment(ref failureCount);
                            return;
                        }
                        
                        sourceTaskId = recordType == "sysapproval_approver" 
                            ? data["sys_id"]?.ToString() ?? "unknown"
                            : data["number"]?.ToString() ?? "unknown";
                        
                        log.LogTrace($"✓ Parsed {category} event | RecordType: {recordType} | SourceID: {sourceTaskId}");

                        await UpsertToCosmosDb(data, recordType, category, log);
                        Interlocked.Increment(ref successCount);
                    }
                    catch (Newtonsoft.Json.JsonException jsonEx)
                    {
                        Interlocked.Increment(ref failureCount);
                        log.LogError(jsonEx, $"❌ JSON parse error for {category} event | SequenceNumber: {eventData.SequenceNumber}");
                    }
                    catch (Exception ex)
                    {
                        Interlocked.Increment(ref failureCount);
                        log.LogError(ex, $"❌ Error processing {category} event | SourceID: {sourceTaskId} | SequenceNumber: {eventData.SequenceNumber}");
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                }));
            }

            await Task.WhenAll(tasks);
            
            log.LogInformation($"✅ Batch complete | Category: {category} | Success: {successCount} | Failed: {failureCount} | Total: {events.Length}");
        }

        private async Task UpsertToCosmosDb(JObject data, string recordType, string category, ILogger log)
        {
            // Use sys_id as the primary unique identifier for all record types
            string sourceTaskId = data["sys_id"]?.ToString();
            
            if (string.IsNullOrEmpty(sourceTaskId) || sourceTaskId == "unknown")
            {
                log.LogWarning($"⚠️ No valid sys_id found, skipping record | RecordType: {recordType}");
                return;
            }

            var container = CosmosDbHelper.GetContainer();

            try
            {
                // Build document directly — no query needed, upsert handles insert or update
                var document = new JObject();
                
                // Deterministic ID based on sourceTaskId — ensures idempotent upserts
                document["id"] = sourceTaskId;
                
                // Partition key fields
                document["sourceSystem"] = "ServiceNow";
                document["sourceTaskId"] = sourceTaskId;
                
                // Map to unified schema (same as Dataverse)
                document["title"] = data["short_description"]?.ToString() ?? "";
                document["sourceRecordType"] = recordType;
                
                // Map priority (ServiceNow 1-5 to 0-100 scale)
                if (data["priority"] != null && int.TryParse(data["priority"].ToString(), out int snPriority))
                {
                    int normalizedPriority = snPriority switch
                    {
                        1 => 100, // Critical
                        2 => 85,  // High
                        3 => 65,  // Moderate
                        4 => 40,  // Low
                        5 => 20,  // Planning
                        _ => 50
                    };
                    document["priority"] = normalizedPriority;
                    document["sourcePriority"] = snPriority.ToString();
                }
                
                // Map status (ServiceNow state to normalized status)
                if (data["state"] != null)
                {
                    string snState = data["state"].ToString();
                    string normalizedStatus = snState switch
                    {
                        "1" => "pending",     // New
                        "2" => "in_progress", // In Progress  
                        "3" => "completed",   // Resolved
                        "7" => "completed",   // Closed
                        "4" => "cancelled",   // Cancelled
                        "6" => "completed",   // Resolved (for approvals)
                        _ => "pending"
                    };
                    document["status"] = normalizedStatus;
                    document["sourceStatus"] = snState;
                }
                
                // Set category
                document["category"] = category;
                
                // Map user fields based on record type
                if (recordType == "sysapproval_approver")
                {
                    // For approvals
                    document["assignedToEmail"] = data["approver_email"]?.ToString() ?? "";
                    document["assignedToName"] = data["assigned_to"]?.ToString() ?? "";
                    document["approverEmail"] = data["approver_email"]?.ToString() ?? "";
                    document["requesterEmail"] = data["requested_for_email"]?.ToString() ?? "";
                }
                else if (recordType == "sc_request" || recordType == "sc_req_item")
                {
                    // For requests
                    document["assignedToEmail"] = data["assigned_to"]?.ToString() ?? "";
                    document["assignedToName"] = data["assigned_to"]?.ToString() ?? "";
                    document["requesterEmail"] = data["requested_for_email"]?.ToString() ?? "";
                }
                else
                {
                    // For tasks
                    document["assignedToEmail"] = data["assigned_to_email"]?.ToString() ?? "";
                    document["assignedToName"] = data["assigned_to"]?.ToString() ?? "";
                }
                
                // Map dates
                if (data["opened_at"] != null && DateTime.TryParse(data["opened_at"].ToString(), out DateTime createdDate))
                {
                    document["createdDate"] = createdDate;
                }
                
                if (data["sys_updated_on"] != null && DateTime.TryParse(data["sys_updated_on"].ToString(), out DateTime modifiedDate))
                {
                    document["lastModifiedDate"] = modifiedDate;
                }
                
                if (data["due_date"] != null && DateTime.TryParse(data["due_date"].ToString(), out DateTime dueDate))
                {
                    document["dueDate"] = dueDate;
                }
                
                // Set description
                document["description"] = data["work_notes"]?.ToString() ?? data["short_description"]?.ToString() ?? "";
                
                // Create deep link to ServiceNow
                if (data["sys_id"] != null)
                {
                    string sysId = data["sys_id"].ToString();
                    string tableName = recordType == "sysapproval_approver" ? "sysapproval_approver" 
                                     : recordType == "sc_request" ? "sc_request"
                                     : recordType == "sc_req_item" ? "sc_req_item"
                                     : "task";
                    document["deepLink"] = $"https://dev186866.service-now.com/{tableName}.do?sys_id={sysId}";
                }
                
                // Store raw JSON in metadata
                document["metadataJson"] = data.ToString();
                
                // Add timestamp
                document["_ts"] = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                
                // Single upsert — no query needed, handles both insert and update
                var partitionKey = new PartitionKey(sourceTaskId);
                await container.UpsertItemAsync(document, partitionKey);
                log.LogTrace($"✅ Upserted {category} | SourceID: {sourceTaskId}");
            }
            catch (CosmosException cosmosEx)
            {
                log.LogError(cosmosEx, $"❌ Cosmos DB operation failed | SourceID: {sourceTaskId} | Status: {cosmosEx.StatusCode} | Message: {cosmosEx.Message}");
                throw;
            }
            catch (Exception ex)
            {
                log.LogError(ex, $"❌ Error upserting to Cosmos DB | SourceID: {sourceTaskId}");
                throw;
            }
        }
    }
}
