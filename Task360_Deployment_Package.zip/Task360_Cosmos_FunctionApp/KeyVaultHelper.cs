using System;
using Azure.Security.KeyVault.Secrets;
using Azure.Identity;

namespace Task360CosmosFunction
{
    public static class KeyVaultHelper
    {
        private static SecretClient _secretClient;

        static KeyVaultHelper()
        {
            var keyVaultUrl = Environment.GetEnvironmentVariable("KeyVaultUrl");
            var credential = new DefaultAzureCredential(new DefaultAzureCredentialOptions
            {
                ExcludeManagedIdentityCredential = false // Use managed identity in Azure, fall back to Azure CLI locally
            });
            _secretClient = new SecretClient(new Uri(keyVaultUrl), credential);
        }

        public static string GetSecret(string secretName)
        {
            try
            {
                KeyVaultSecret secret = _secretClient.GetSecret(secretName);
                return secret.Value;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to retrieve secret '{secretName}' from Key Vault: {ex.Message}", ex);
            }
        }
    }
}
