import azure.functions as func
import logging
import requests
import os
import json
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from azure.eventhub import EventHubProducerClient, EventData
from azure.identity import DefaultAzureCredential
from keyvault_helper import KeyVaultHelper

# Configure Application Insights with OpenTelemetry
from azure.monitor.opentelemetry import configure_azure_monitor

# Configure Azure Monitor (Application Insights) if connection string is available
app_insights_conn_str = os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING")
if app_insights_conn_str:
    configure_azure_monitor(connection_string=app_insights_conn_str)
    logging.info("✓ Application Insights configured successfully")
else:
    logging.warning("⚠️ APPLICATIONINSIGHTS_CONNECTION_STRING not set - telemetry disabled")

# Suppress verbose Azure SDK logging
logging.getLogger('azure').setLevel(logging.WARNING)
logging.getLogger('azure.eventhub').setLevel(logging.WARNING)
logging.getLogger('azure.identity').setLevel(logging.WARNING)
logging.getLogger('uamqp').setLevel(logging.WARNING)

app = func.FunctionApp()


class EventHubSender:
    """Client for sending events to Azure Event Hubs using Azure AD authentication"""
    
    # Event Hub routing based on record type
    EVENT_HUB_ROUTES = {
        'task': 'task360-events',
        'sc_request': 'task360-requests',
        'sc_req_item': 'task360-requests',
        'sysapproval_approver': 'task360-approvals'
    }
    
    # Task subtypes that should be routed to task360-events
    TASK_SUBTYPES = [
        'incident', 'problem', 'change_request', 'change_task',
        'sc_task', 'catalog_task', 'follow_on_task', 'sc_req_item',
        'demand', 'enhancement', 'defect', 'incident_task'
    ]
    
    def __init__(self):
        # Get Event Hub namespace from environment (don't need full connection string)
        self.eventhub_namespace = os.environ.get("EVENTHUB_NAMESPACE", "task360eventhubs.servicebus.windows.net")
        
        # Create Azure AD credential
        self.credential = DefaultAzureCredential()
        
        # Cache producer clients for each Event Hub
        self.producers = {}
    
    def _get_client(self, event_hub_name: str) -> EventHubProducerClient:
        """Get or create an Event Hub producer client with Azure AD authentication"""
        if event_hub_name not in self.producers:
            try:
                self.producers[event_hub_name] = EventHubProducerClient(
                    fully_qualified_namespace=self.eventhub_namespace,
                    eventhub_name=event_hub_name,
                    credential=self.credential
                )
                logging.info(f"Created Event Hub producer client for {event_hub_name}")
            except Exception as e:
                logging.error(f"Failed to create producer for {event_hub_name}: {e}")
                raise
        
        return self.producers[event_hub_name]
    
    def _route_payload(self, payload: Dict[str, Any]) -> Optional[str]:
        """
        Determine which Event Hub a payload should be routed to.
        
        Returns:
            Event Hub name, or None if the payload cannot be routed.
        """
        record_type = payload.get('record_type', 'unknown').lower().replace(' ', '_')
        source_id = payload.get('sys_id', 'unknown')
        
        event_hub_name = self.EVENT_HUB_ROUTES.get(record_type)
        
        if not event_hub_name and record_type in self.TASK_SUBTYPES:
            event_hub_name = 'task360-events'
            logging.info(f"📍 Routing task subtype '{record_type}' to task360-events | SourceID: {source_id}")
        
        if not event_hub_name and record_type not in ['sysapproval_approver']:
            event_hub_name = 'task360-events'
            logging.warning(f"⚠️ Unknown record_type '{record_type}' - defaulting to task360-events | SourceID: {source_id}")
        
        if not event_hub_name:
            logging.error(f"❌ Cannot route record_type: {record_type} | SourceID: {source_id}")
        
        return event_hub_name

    def send_event(self, payload: Dict[str, Any]) -> bool:
        """
        Send a single event to the appropriate Event Hub.
        For better performance, use send_events_batch() instead.
        """
        event_hub_name = self._route_payload(payload)
        if not event_hub_name:
            return False
        
        source_id = payload.get('sys_id', 'unknown')
        record_type = payload.get('record_type', 'unknown')
        
        try:
            producer = self._get_client(event_hub_name)
            event_data = EventData(json.dumps(payload))
            event_batch = producer.create_batch()
            event_batch.add(event_data)
            producer.send_batch(event_batch)
            
            logging.info(f"✅ Sent event | Hub: {event_hub_name} | RecordType: {record_type} | SourceID: {source_id}")
            return True
        except Exception as e:
            logging.error(f"❌ Event Hub send failed | Hub: {event_hub_name} | SourceID: {source_id} | Error: {str(e)}")
            return False

    def send_events_batch(self, payloads: List[Dict[str, Any]]) -> tuple:
        """
        Send multiple events to Event Hubs in batches, grouped by destination hub.
        Much faster than calling send_event() in a loop — sends all events for each
        hub in one batch instead of one-at-a-time.
        
        Args:
            payloads: List of event data dictionaries
            
        Returns:
            Tuple of (success_count, failure_count)
        """
        if not payloads:
            return (0, 0)
        
        # Group payloads by destination Event Hub
        hub_groups: Dict[str, List[Dict[str, Any]]] = {}
        skipped = 0
        
        for payload in payloads:
            hub_name = self._route_payload(payload)
            if hub_name:
                if hub_name not in hub_groups:
                    hub_groups[hub_name] = []
                hub_groups[hub_name].append(payload)
            else:
                skipped += 1
        
        logging.info(f"📦 Batching {len(payloads)} events across {len(hub_groups)} Event Hubs (skipped {skipped} unroutable)")
        
        success_count = 0
        failure_count = skipped
        
        for hub_name, group in hub_groups.items():
            try:
                producer = self._get_client(hub_name)
                
                # Send in batches (Event Hub has ~1MB batch limit)
                batch = producer.create_batch()
                batches_sent = 0
                
                for payload in group:
                    event_data = EventData(json.dumps(payload))
                    try:
                        batch.add(event_data)
                    except ValueError:
                        # Batch is full — send it and start a new one
                        if len(batch) > 0:
                            producer.send_batch(batch)
                            success_count += len(batch)
                            batches_sent += 1
                        batch = producer.create_batch()
                        batch.add(event_data)
                
                # Send remaining events in the last batch
                if len(batch) > 0:
                    producer.send_batch(batch)
                    success_count += len(batch)
                    batches_sent += 1
                
                logging.info(f"✅ Sent {len(group)} events to {hub_name} in {batches_sent} batch(es)")
                
            except Exception as e:
                failure_count += len(group)
                logging.error(f"❌ Batch send failed | Hub: {hub_name} | Count: {len(group)} | Error: {str(e)}")
        
        return (success_count, failure_count)
    
    def close_all(self):
        """Close all producer clients"""
        for name, producer in self.producers.items():
            try:
                producer.close()
                logging.info(f"Closed producer for {name}")
            except Exception as e:
                logging.error(f"Error closing producer for {name}: {e}")


class ServiceNowClient:
    """Client for interacting with ServiceNow API"""
    
    def __init__(self):
        self.instance = os.environ.get("SERVICENOW_INSTANCE")
        self.username = os.environ.get("SERVICENOW_USERNAME")
        
        # Get sensitive values from Key Vault
        try:
            self.password = KeyVaultHelper.get_secret("servicenow-password")
            logging.info("✓ Retrieved ServiceNow password from Key Vault")
        except Exception as e:
            logging.warning(f"⚠️ Could not get ServiceNow password from Key Vault: {e}")
            self.password = None
            
        self.client_id = os.environ.get("SERVICENOW_CLIENT_ID")
        
        try:
            self.client_secret = KeyVaultHelper.get_secret("servicenow-client-secret")
            logging.info("✓ Retrieved ServiceNow client secret from Key Vault")
        except Exception as e:
            logging.warning(f"⚠️ Could not get ServiceNow client secret from Key Vault: {e}")
            self.client_secret = None
        
        if not self.instance:
            raise ValueError("SERVICENOW_INSTANCE environment variable is not set")
        
        self.base_url = f"https://{self.instance}/api/now"
        self.session = requests.Session()
        
        # Use basic auth or OAuth based on what's provided
        if self.username and self.password:
            logging.info(f"🔐 Using Basic Auth | Username: {self.username} | Password length: {len(self.password)} | First 5 chars: {self.password[:5]}")
            self.session.auth = (self.username, self.password)
        elif self.client_id and self.client_secret:
            self._setup_oauth()
        else:
            raise ValueError("Either username/password or client_id/client_secret must be provided")
    
    def _setup_oauth(self):
        """Set up OAuth authentication"""
        token_url = f"https://{self.instance}/oauth_token.do"
        data = {
            'grant_type': 'client_credentials',
            'client_id': self.client_id,
            'client_secret': self.client_secret
        }
        
        response = requests.post(token_url, data=data)
        response.raise_for_status()
        
        token_data = response.json()
        self.session.headers.update({
            'Authorization': f"Bearer {token_data['access_token']}"
        })
    
    def get_recent_changes(self, table_name: str, minutes_ago: int = 5, start_time: Optional[datetime] = None) -> List[Dict[str, Any]]:
        """
        Fetch records from a ServiceNow table that were created or updated since a specific time or in the last N minutes.
        Includes retry logic: attempts once more on failure before raising exception.
        
        Args:
            table_name: Name of the ServiceNow table (e.g., 'task', 'sysapproval_approver')
            minutes_ago: Number of minutes to look back for changes (used if start_time is None)
            start_time: Specific datetime to query from (overrides minutes_ago if provided)
            
        Returns:
            List of records from the table
            
        Raises:
            requests.exceptions.RequestException: If both attempts fail
        """
        # Calculate the timestamp - use start_time if provided, otherwise calculate from minutes_ago
        if start_time:
            cutoff_time = start_time
            logging.info(f"🕐 Using custom start time: {cutoff_time} | Table: {table_name}")
        else:
            cutoff_time = datetime.utcnow() - timedelta(minutes=minutes_ago)
            logging.info(f"🕐 Querying last {minutes_ago} minutes | Table: {table_name}")
            
        # ServiceNow uses format: YYYY-MM-DD HH:MM:SS
        cutoff_str = cutoff_time.strftime('%Y-%m-%d %H:%M:%S')
        
        # Get current time for upper bound filter (to exclude future dates)
        now_str = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
        
        # Build the query - use relative time if no start_time, otherwise use absolute time
        if start_time:
            # Query for records created or updated since the specified time, but not in the future
            query = f"sys_created_on>={cutoff_str}^sys_created_on<={now_str}^ORsys_updated_on>={cutoff_str}^sys_updated_on<={now_str}"
        else:
            # Use relative time query for the last N minutes
            query = f"sys_created_onONLast {minutes_ago} minutes@javascript:gs.minutesAgoStart({minutes_ago})@javascript:gs.minutesAgoEnd(0)^ORsys_updated_onONLast {minutes_ago} minutes@javascript:gs.minutesAgoStart({minutes_ago})@javascript:gs.minutesAgoEnd(0)"
        
        logging.debug(f"Query: {query}")
        
        url = f"{self.base_url}/table/{table_name}"
        params = {
            'sysparm_query': query,
            'sysparm_display_value': 'true',  # Get display values for reference fields
            'sysparm_exclude_reference_link': 'true',
            'sysparm_limit': 1000,  # Adjust as needed
            'sysparm_fields': self._get_fields_for_table(table_name)
        }
        
        # Retry logic: attempt up to 2 times
        max_attempts = 2
        last_exception = None
        
        for attempt in range(1, max_attempts + 1):
            try:
                if attempt > 1:
                    logging.warning(f"🔄 Retrying ServiceNow API call | Table: {table_name} | Attempt: {attempt}/{max_attempts}")
                
                logging.info(f"🌐 Calling ServiceNow API | Table: {table_name} | Attempt: {attempt}")
                response = self.session.get(url, params=params)
                response.raise_for_status()
                
                data = response.json()
                records = data.get('result', [])
                
                if records:
                    logging.info(f"✅ Retrieved {len(records)} records | Table: {table_name} | TimeWindow: {minutes_ago}min")
                    # Log first and last record timestamps for verification
                    if len(records) > 0:
                        first_rec = records[0]
                        last_rec = records[-1]
                        logging.info(f"  First: {first_rec.get('number', first_rec.get('sys_id'))} | Updated: {first_rec.get('sys_updated_on')}")
                        logging.info(f"  Last: {last_rec.get('number', last_rec.get('sys_id'))} | Updated: {last_rec.get('sys_updated_on')}")
                else:
                    logging.info(f"ℹ️ No records found | Table: {table_name} | TimeWindow: {minutes_ago}min")
                
                # Success - return records
                if attempt > 1:
                    logging.info(f"✓ Retry successful | Table: {table_name} | Attempt: {attempt}")
                return records
                
            except requests.exceptions.RequestException as e:
                last_exception = e
                logging.error(f"❌ ServiceNow API error | Table: {table_name} | Attempt: {attempt}/{max_attempts} | Error: {str(e)}")
                
                # If this was the last attempt, raise the exception
                if attempt >= max_attempts:
                    logging.error(f"❌ All {max_attempts} attempts failed | Table: {table_name}")
                    raise
                # Otherwise continue to retry
        
        # This should never be reached, but included for safety
        if last_exception:
            raise last_exception
        return []
    
    def _get_fields_for_table(self, table_name: str) -> str:
        """Get the comma-separated list of fields to retrieve for each table"""
        if table_name == 'task':
            return 'sys_id,number,short_description,state,priority,assigned_to,assigned_to.email,assignment_group,assignment_group.email,work_notes,sys_updated_on,category,subcategory,opened_at,sys_class_name'
        elif table_name == 'sysapproval_approver':
            return 'sys_id,state,approver,approver.email,document_id,sys_updated_on,sys_created_on,source_table'
        else:
            return ''


class CosmosSyncTracker:
    """Client for tracking ServiceNow sync operations in Cosmos DB SyncTracking container"""

    def __init__(self):
        self.cosmos_endpoint = os.environ.get("CosmosDbEndpoint")
        self.database_name = os.environ.get("CosmosDbDatabaseName", "Task360DB")
        self.sync_container_name = os.environ.get("CosmosDbSyncContainerName", "SyncTracking")

        if not self.cosmos_endpoint:
            raise ValueError("CosmosDbEndpoint environment variable is not set")

        from azure.cosmos import CosmosClient, PartitionKey

        # Use DefaultAzureCredential (Managed Identity in Azure, CLI locally)
        credential = DefaultAzureCredential()
        self.client = CosmosClient(self.cosmos_endpoint, credential=credential)

        # Ensure database and container exist
        self.database = self.client.create_database_if_not_exists(id=self.database_name)
        self.container = self.database.create_container_if_not_exists(
            id=self.sync_container_name,
            partition_key=PartitionKey(path="/sourceSystem")
        )
        logging.info(f"✓ Cosmos DB sync tracker initialized | Endpoint: {self.cosmos_endpoint} | Container: {self.sync_container_name}")

    def get_last_successful_sync(self, source_system: str = "ServiceNow") -> Optional[datetime]:
        """
        Get the timestamp of the last successful sync from the SyncTracking container.

        Args:
            source_system: The source system to filter by (default: ServiceNow)

        Returns:
            Datetime of last successful sync, or None if no previous successful sync exists
        """
        try:
            query = (
                "SELECT TOP 1 c.syncTime FROM c "
                "WHERE c.sourceSystem = @source AND c.success = true "
                "ORDER BY c.syncTime DESC"
            )
            parameters = [{"name": "@source", "value": source_system}]

            items = list(self.container.query_items(
                query=query,
                parameters=parameters,
                enable_cross_partition_query=False,
                partition_key=source_system
            ))

            if items:
                sync_time_str = items[0].get('syncTime')
                if sync_time_str:
                    sync_time = datetime.fromisoformat(sync_time_str.replace('Z', '+00:00'))
                    logging.info(f"Last successful sync was at: {sync_time}")
                    return sync_time

            logging.info("No previous successful sync found")
            return None

        except Exception as e:
            logging.error(f"Error querying last successful sync from Cosmos DB: {str(e)}")
            return None

    def log_sync_attempt(self,
                        source_system: str,
                        success: bool,
                        record_count: int,
                        error_message: Optional[str] = None) -> bool:
        """
        Log a sync attempt to the SyncTracking Cosmos DB container.

        Args:
            source_system: The source system (e.g., "ServiceNow")
            success: Whether the sync was successful
            record_count: Number of records retrieved
            error_message: Error message if sync failed

        Returns:
            True if logging was successful, False otherwise
        """
        try:
            import uuid

            sync_time = datetime.utcnow().isoformat() + 'Z'

            document = {
                'id': str(uuid.uuid4()),
                'sourceSystem': source_system,
                'syncTime': sync_time,
                'success': success,
                'recordCount': record_count,
                'label': f"{source_system} Sync - {sync_time}"
            }

            if error_message:
                document['errorMessage'] = error_message[:500]

            from azure.cosmos import PartitionKey as PK
            self.container.upsert_item(document)

            logging.info(f"Successfully logged sync attempt to Cosmos DB: success={success}, records={record_count}")
            return True

        except Exception as e:
            logging.error(f"Error logging sync attempt to Cosmos DB: {str(e)}")
            return False


def format_task_payload(record: Dict[str, Any]) -> Dict[str, Any]:
    """
    Format a task record according to the ServiceNow business rule structure.
    
    Args:
        record: Raw ServiceNow record
        
    Returns:
        Formatted payload ready for Event Hub
    """
    record_type = record.get('sys_class_name', {}).get('value', 'task') if isinstance(record.get('sys_class_name'), dict) else record.get('sys_class_name', 'task')
    
    # Extract email addresses for assigned_to and assignment_group
    assigned_to_email = ''
    if isinstance(record.get('assigned_to.email'), dict):
        assigned_to_email = record.get('assigned_to.email', {}).get('display_value', '')
    else:
        assigned_to_email = record.get('assigned_to.email', '')
    
    assignment_group_email = ''
    if isinstance(record.get('assignment_group.email'), dict):
        assignment_group_email = record.get('assignment_group.email', {}).get('display_value', '')
    else:
        assignment_group_email = record.get('assignment_group.email', '')
    
    payload = {
        'record_type': record_type,
        'sys_id': record.get('sys_id', ''),
        'number': record.get('number', ''),
        'short_description': record.get('short_description', ''),
        'state': record.get('state', ''),
        'priority': record.get('priority', ''),
        'assigned_to': record.get('assigned_to', {}).get('display_value', '') if isinstance(record.get('assigned_to'), dict) else record.get('assigned_to', ''),
        'assigned_to_email': assigned_to_email,
        'assignment_group': record.get('assignment_group', {}).get('display_value', '') if isinstance(record.get('assignment_group'), dict) else record.get('assignment_group', ''),
        'assignment_group_email': assignment_group_email,
        'work_notes': record.get('work_notes', ''),
        'sys_updated_on': record.get('sys_updated_on', ''),
        'category': record.get('category', ''),
        'subcategory': record.get('subcategory', ''),
        'opened_at': record.get('opened_at', '')
    }
    
    # Add email addresses for requests
    if record_type in ['sc_request', 'sc_req_item']:
        requested_for = record.get('requested_for', {})
        if isinstance(requested_for, dict):
            payload['requested_for_email'] = requested_for.get('email', '')
        else:
            payload['requested_for_email'] = ''
    
    return payload


def format_approval_payload(record: Dict[str, Any], sn_client: ServiceNowClient) -> Dict[str, Any]:
    """
    Format an approval record according to the ServiceNow business rule structure.
    
    Args:
        record: Raw ServiceNow approval record
        sn_client: ServiceNow client for fetching related data
        
    Returns:
        Formatted payload ready for Event Hub
    """
    # Get approver email using dot-walking field
    approver_display = record.get('approver', {}).get('display_value', '') if isinstance(record.get('approver'), dict) else record.get('approver', '')
    
    approver_email = ''
    if isinstance(record.get('approver.email'), dict):
        approver_email = record.get('approver.email', {}).get('display_value', '')
    else:
        approver_email = record.get('approver.email', '')
    
    document_id = record.get('document_id', '')
    source_table = record.get('source_table', '')
    
    # Initialize payload
    payload = {
        'record_type': 'sysapproval_approver',
        'sys_id': record.get('sys_id', ''),
        'state': record.get('state', ''),
        'approver_email': approver_email,
        'assigned_to': approver_display,
        'document_id': document_id,
        'short_description': '',
        'requested_for_email': '',
        'sys_updated_on': record.get('sys_updated_on', ''),
        'opened_at': record.get('sys_created_on', '')
    }
    
    # Get requested_for email from the linked request if source is sc_req_item
    if source_table == 'sc_req_item' and document_id:
        try:
            url = f"{sn_client.base_url}/table/sc_req_item/{document_id}"
            params = {
                'sysparm_display_value': 'true',
                'sysparm_fields': 'short_description,request.requested_for.email'
            }
            response = sn_client.session.get(url, params=params)
            if response.status_code == 200:
                req_item = response.json().get('result', {})
                payload['short_description'] = req_item.get('short_description', '')
                
                # Extract requested_for email from nested structure
                request_data = req_item.get('request.requested_for.email', {})
                if isinstance(request_data, dict):
                    payload['requested_for_email'] = request_data.get('display_value', '')
                else:
                    payload['requested_for_email'] = str(request_data) if request_data else ''
        except Exception as e:
            logging.warning(f"Could not fetch related sc_req_item data: {str(e)}")
    
    return payload


def process_task_records(records: List[Dict[str, Any]], event_hub_sender: EventHubSender) -> None:
    """
    Process and send task table records to Event Hub in batches.
    
    Args:
        records: List of task records from ServiceNow
        event_hub_sender: Event Hub client for sending events
    """
    logging.info(f"🔄 Processing task records | Count: {len(records)}")
    
    # Format all payloads first, then send in one batch
    payloads = []
    format_errors = 0
    
    for record in records:
        source_id = record.get('sys_id', 'unknown')
        try:
            payload = format_task_payload(record)
            payloads.append(payload)
        except Exception as e:
            format_errors += 1
            logging.error(f"❌ Error formatting task record | SourceID: {source_id} | Error: {str(e)}")
    
    # Send all formatted payloads in batched call
    success_count, send_errors = event_hub_sender.send_events_batch(payloads)
    error_count = format_errors + send_errors
    
    logging.info(f"✅ Task processing complete | Success: {success_count} | Failed: {error_count} | Total: {len(records)}")


def process_approval_records(records: List[Dict[str, Any]], event_hub_sender: EventHubSender, sn_client: ServiceNowClient) -> None:
    """
    Process and send approval records to Event Hub in batches.
    
    Args:
        records: List of approval records from ServiceNow
        event_hub_sender: Event Hub client for sending events
        sn_client: ServiceNow client for fetching related data
    """
    logging.info(f"🔄 Processing approval records | Count: {len(records)}")
    
    # Format all payloads first, then send in one batch
    payloads = []
    format_errors = 0
    
    for record in records:
        source_id = record.get('sys_id', 'unknown')
        try:
            payload = format_approval_payload(record, sn_client)
            payloads.append(payload)
        except Exception as e:
            format_errors += 1
            logging.error(f"❌ Error formatting approval record | SourceID: {source_id} | Error: {str(e)}")
    
    # Send all formatted payloads in batched call
    success_count, send_errors = event_hub_sender.send_events_batch(payloads)
    error_count = format_errors + send_errors
    
    logging.info(f"✅ Approval processing complete | Success: {success_count} | Failed: {error_count} | Total: {len(records)}")


@app.timer_trigger(
    schedule="0 * * * * *",  # Every minute (cron: second minute hour day month weekday)
    arg_name="myTimer",
    run_on_startup=False,
    use_monitor=True
)
def servicenow_sync_timer(myTimer: func.TimerRequest) -> None:
    """
    Timer-triggered function that runs every minute to sync data from ServiceNow
    and send it to Azure Event Hubs. Tracks sync history in Cosmos DB SyncTracking container.
    """
    utc_timestamp = datetime.now().isoformat()
    
    if myTimer.past_due:
        logging.warning('⚠️ The timer is past due!')
    
    logging.info(f'🚀 ServiceNow sync function started | Timestamp: {utc_timestamp}')
    
    event_hub_sender = None
    sync_tracker = None
    total_records = 0
    sync_successful = False
    error_message = None
    
    try:
        # Initialize clients
        logging.info("🔧 Initializing clients...")
        sn_client = ServiceNowClient()
        logging.info("✓ ServiceNow client initialized")
        
        event_hub_sender = EventHubSender()
        logging.info("✓ Event Hub sender initialized")
        
        # Initialize Cosmos DB sync tracker
        try:
            sync_tracker = CosmosSyncTracker()
            logging.info("✓ Cosmos DB sync tracker initialized")
        except Exception as e:
            logging.warning(f"⚠️ Could not initialize sync tracker: {str(e)}. Proceeding without sync tracking.")
            sync_tracker = None
        
        # Get the last successful sync time from Cosmos DB
        last_sync_time = None
        if sync_tracker:
            logging.info("🔍 Checking for last successful sync time...")
            last_sync_time = sync_tracker.get_last_successful_sync("ServiceNow")
        
        # Determine the time window for querying ServiceNow
        # Note: get_recent_changes now includes retry logic (2 attempts)
        if last_sync_time:
            # Query from last successful sync to now
            logging.info(f"📅 Using last successful sync time: {last_sync_time}")
            # Fetch changes from task table since last successful sync
            logging.info("📊 Fetching changes from task table since last sync...")
            task_records = sn_client.get_recent_changes('task', start_time=last_sync_time)
            
            # Fetch changes from sysapproval_approver table since last successful sync
            logging.info("📊 Fetching changes from sysapproval_approver table since last sync...")
            approval_records = sn_client.get_recent_changes('sysapproval_approver', start_time=last_sync_time)
        else:
            # No previous sync found - use default 5 minute window
            logging.info("📅 No previous successful sync found - using default 5 minute window")
            # Fetch changes from task table
            logging.info("📊 Fetching changes from task table...")
            task_records = sn_client.get_recent_changes('task', minutes_ago=5)
            
            # Fetch changes from sysapproval_approver table
            logging.info("📊 Fetching changes from sysapproval_approver table...")
            approval_records = sn_client.get_recent_changes('sysapproval_approver', minutes_ago=5)
        
        # Process the records
        process_task_records(task_records, event_hub_sender)
        process_approval_records(approval_records, event_hub_sender, sn_client)
        
        total_records = len(task_records) + len(approval_records)
        sync_successful = True
        
        logging.info(f'✅ ServiceNow sync completed successfully | '
                    f'Tasks: {len(task_records)} | Approvals: {len(approval_records)} | Total: {total_records}')
        
    except Exception as e:
        sync_successful = False
        error_message = str(e)
        logging.error(f'❌ Error during ServiceNow sync: {error_message}', exc_info=True)
        # Don't re-raise - we want to log the failure to Dataverse
        
    finally:
        # Log the sync attempt to Cosmos DB
        if sync_tracker:
            try:
                logging.info("💾 Logging sync attempt to Cosmos DB...")
                sync_tracker.log_sync_attempt(
                    source_system="ServiceNow",
                    success=sync_successful,
                    record_count=total_records,
                    error_message=error_message
                )
                logging.info("✓ Sync attempt logged to Cosmos DB")
            except Exception as e:
                logging.error(f"❌ Failed to log sync attempt to Cosmos DB: {str(e)}")
        
        # Clean up Event Hub connections
        if event_hub_sender:
            try:
                event_hub_sender.close_all()
                logging.info("✓ Event Hub connections closed")
            except Exception as e:
                logging.warning(f"⚠️ Error closing Event Hub connections: {str(e)}")
        
        # If sync failed, re-raise the exception after logging
        if not sync_successful and error_message:
            raise Exception(f"ServiceNow sync failed: {error_message}")
