# ServiceNow to Azure Event Hub Sync Function

Azure Function that automatically synchronizes data from ServiceNow every 5 minutes and sends it directly to Azure Event Hubs.

## Features

- **Timer-triggered**: Runs automatically every 5 minutes
- **ServiceNow Integration**: Fetches changes from:
  - `task` table
  - `sysapproval_approver` table
- **Smart Sync Tracking**: Tracks sync history in Dataverse `new_sync` table
  - Records all sync attempts (success and failure)
  - Queries from last successful sync to ensure no missed changes
  - Automatic failure recovery
- **Smart Filtering**: Retrieves records since last successful sync (or last 5 minutes if no previous sync)
- **Event Hub Routing**: Automatically routes records to the correct Event Hub based on record type:
  - `task` → `task360-events`
  - `sc_request` → `task360-requests`
  - `sc_req_item` → `task360-requests`
  - `sysapproval_approver` → `task360-approvals`
- **Data Formatting**: Formats data according to ServiceNow business rule specifications
- **Authentication Support**: Supports both Basic Auth and OAuth 2.0 for ServiceNow
- **Error Handling**: Comprehensive logging and error management

## Project Structure

```text
.
├── function_app.py               # Main Azure Function code
├── host.json                     # Function host configuration
├── local.settings.json           # Local development settings
├── requirements.txt              # Python dependencies
├── SYNC_TRACKING_SETUP.md       # Sync tracking documentation
├── .gitignore                   # Git ignore rules
└── README.md                    # This file
```

## Prerequisites

- Python 3.9 or later
- Azure Functions Core Tools v4
- ServiceNow instance with API access
- Azure subscription (for deployment)

## Local Development Setup

### 1. Install Azure Functions Core Tools

```powershell
# Using npm
npm install -g azure-functions-core-tools@4 --unsafe-perm true

# Or using chocolatey
choco install azure-functions-core-tools-4
```

### 2. Configure ServiceNow and Event Hub Credentials

Edit `local.settings.json` and update with your credentials:

#### ServiceNow Configuration

**Option A: Basic Authentication**

```json
{
  "Values": {
    "SERVICENOW_INSTANCE": "your-instance.service-now.com",
    "SERVICENOW_USERNAME": "your-username",
    "SERVICENOW_PASSWORD": "your-password"
  }
}
```

**Option B: OAuth 2.0 Authentication**

```json
{
  "Values": {
    "SERVICENOW_INSTANCE": "your-instance.service-now.com",
    "SERVICENOW_CLIENT_ID": "your-client-id",
    "SERVICENOW_CLIENT_SECRET": "your-client-secret"
  }
}
```

#### Azure Event Hub Configuration

Add Event Hub connection string to the same file:

```json
{
  "Values": {
    "EVENTHUB_NAMESPACE": "task360eventhubs.servicebus.windows.net",
    "EVENTHUB_CONNECTION_STRING": "Endpoint=sb://task360eventhubs.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=your-key-here"
  }
}
```

**To get your Event Hub connection string:**

```powershell
# Using Azure CLI
az eventhubs namespace authorization-rule keys list --resource-group <resource-group> --namespace-name task360eventhubs --name RootManageSharedAccessKey --query primaryConnectionString --output tsv
```

#### Dataverse Configuration (for Sync Tracking)

Add Dataverse environment URL to track sync history:

```json
{
  "Values": {
    "DATAVERSE_ENVIRONMENT_URL": "https://orgXXXXXXXX.crm.dynamics.com"
  }
}
```

**Important**: You must create a `new_sync` table in Dataverse before enabling sync tracking. See [SYNC_TRACKING_SETUP.md](SYNC_TRACKING_SETUP.md) for detailed setup instructions.

The sync tracking feature:
- Records every API call attempt (success/failure)
- Stores timestamp, record count, and error messages
- Enables the function to query from the last successful sync
- Ensures no ServiceNow changes are missed even if syncs fail

### 3. Install Python Dependencies

```powershell
# Create a virtual environment
python -m venv .venv

# Activate virtual environment
.\.venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt
```

### 4. Run Locally

```powershell
func start
```

The function will start and execute every 5 minutes. You can also test it immediately by triggering it manually through the Azure Functions Core Tools interface.

## Event Hub Routing Logic

The function automatically routes records to different Event Hubs based on the `record_type` field:

| Record Type | Event Hub Name | Description |
|------------|----------------|-------------|
| `task` | `task360-events` | Standard task records |
| `sc_request` | `task360-requests` | Service catalog requests |
| `sc_req_item` | `task360-requests` | Service catalog request items |
| `sysapproval_approver` | `task360-approvals` | Approval records |

## Data Format

### Task Records Format

```json
{
  "record_type": "task",
  "sys_id": "abc123...",
  "number": "TASK0001234",
  "short_description": "Fix login issue",
  "state": "2",
  "priority": "3",
  "assigned_to": "John Doe",
  "assignment_group": "IT Support",
  "work_notes": "Working on resolution",
  "sys_updated_on": "2026-01-26 10:30:00",
  "category": "software",
  "subcategory": "email",
  "opened_at": "2026-01-26 09:00:00"
}
```

For `sc_request` and `sc_req_item` types, an additional field is included:

```json
{
  "requested_for_email": "user@company.com"
}
```

### Approval Records Format

```json
{
  "record_type": "sysapproval_approver",
  "sys_id": "def456...",
  "state": "requested",
  "approver_email": "manager@company.com",
  "assigned_to": "Jane Manager",
  "document_id": "xyz789...",
  "short_description": "Request approval needed",
  "requested_for_email": "user@company.com",
  "sys_updated_on": "2026-01-26 10:30:00",
  "opened_at": "2026-01-26 09:00:00"
}
```

## Customization

### Adjust Time Window

To change the lookback window from 5 minutes, modify the `minutes_ago` parameter in [function_app.py](function_app.py#L368):

```python
task_records = sn_client.get_recent_changes('task', minutes_ago=10)  # 10 minutes
```

### Change Schedule

Modify the cron expression in the `@app.timer_trigger` decorator in [function_app.py](function_app.py#L343):

```python
@app.timer_trigger(
    schedule="0 */10 * * * *",  # Every 10 minutes
    # schedule="0 0 * * * *",    # Every hour
    # schedule="0 0 0 * * *",    # Every day at midnight
    ...
)
```

### Add Custom Processing

After events are sent to Event Hub, you can add additional processing logic in the `process_task_records()` and `process_approval_records()` functions.

## Azure Event Hub Setup

### Create Event Hubs

You need to create the following Event Hubs in your `task360eventhubs` namespace:

```powershell
# Create the Event Hub namespace (if not already created)
az eventhubs namespace create --name task360eventhubs --resource-group <your-rg> --location eastus --sku Standard

# Create the individual Event Hubs
az eventhubs eventhub create --name task360-events --namespace-name task360eventhubs --resource-group <your-rg>
az eventhubs eventhub create --name task360-requests --namespace-name task360eventhubs --resource-group <your-rg>
az eventhubs eventhub create --name task360-approvals --namespace-name task360eventhubs --resource-group <your-rg>
```

## Deployment to Azure

### Using Azure Functions Core Tools

```powershell
# Login to Azure
az login

# Create a resource group
az group create --name rg-servicenow-sync --location eastus

# Create a storage account
az storage account create --name stservicenowsync --resource-group rg-servicenow-sync --location eastus --sku Standard_LRS

# Create a Function App (Flex Consumption plan)
az functionapp create --name func-servicenow-sync --resource-group rg-servicenow-sync --storage-account stservicenowsync --runtime python --runtime-version 3.11 --functions-version 4 --os-type Linux

# Configure application settings
az functionapp config appsettings set --name func-servicenow-sync --resource-group rg-servicenow-sync --settings \
  "SERVICENOW_INSTANCE=your-instance.service-now.com" \
  "SERVICENOW_USERNAME=your-username" \
  "SERVICENOW_PASSWORD=your-password" \
  "EVENTHUB_NAMESPACE=task360eventhubs.servicebus.windows.net" \
  "EVENTHUB_CONNECTION_STRING=<your-connection-string>"

# Deploy the function
func azure functionapp publish func-servicenow-sync
```

### Using Azure Portal

1. Create a new Function App in the Azure Portal
2. Choose Python 3.11 runtime
3. Configure Application Settings with ServiceNow credentials
4. Deploy using VS Code Azure Functions extension or ZIP deploy

## Monitoring

### View Logs

**Locally:**
Logs appear in the console where you ran `func start`

**Azure:**
- Azure Portal → Function App → Monitor → Logs
- Application Insights (if configured)

### Key Log Messages

- `ServiceNow sync function started` - Function execution began
- `Retrieved X records from [table]` - Successfully fetched data from ServiceNow
- `Sent task/approval to Event Hub` - Successfully sent event to Event Hub
- `ServiceNow sync completed successfully` - Execution completed
- `Error during ServiceNow sync` - An error occurred

## Architecture

```text
┌─────────────────┐      Every 5 min      ┌──────────────────┐
│                 │─────────────────────►  │                  │
│  Azure Function │                        │   ServiceNow     │
│   (Timer)       │  ◄─────────────────────│   REST API       │
│                 │    Fetch Changes       │                  │
└────────┬────────┘                        └──────────────────┘
         │
         │ Format & Route
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│              Azure Event Hub Namespace                       │
│                 task360eventhubs                             │
├──────────────────┬────────────────┬─────────────────────────┤
│  task360-events  │ task360-       │  task360-approvals      │
│                  │ requests       │                         │
│  (task records)  │ (sc_request,   │  (sysapproval_approver) │
│                  │  sc_req_item)  │                         │
└──────────────────┴────────────────┴─────────────────────────┘
```

## ServiceNow API Details

The function uses ServiceNow's Table API with the following query:

```
sysparm_query=sys_created_on>=YYYY-MM-DD HH:MM:SS^ORsys_updated_on>=YYYY-MM-DD HH:MM:SS
```

This retrieves records where either:
- `sys_created_on` (creation date) is within the last 5 minutes, OR
- `sys_updated_on` (last update date) is within the last 5 minutes

## Troubleshooting

### Authentication Errors

- Verify ServiceNow credentials in `local.settings.json`
- Check that the user has API access permissions
- For OAuth, ensure the client has the correct scopes

### Event Hub Connection Errors

- Verify the Event Hub connection string is correct
- Ensure the Event Hubs exist in your namespace (`task360-events`, `task360-requests`, `task360-approvals`)
- Check that the connection string has Send permissions
- Test connectivity: `Test-NetConnection task360eventhubs.servicebus.windows.net -Port 5671`

### No Records Retrieved

- Check the time zone settings (function uses UTC)
- Verify data exists in ServiceNow tables within the time window
- Check ServiceNow instance is accessible

### Function Not Triggering

- Verify the cron expression is valid
- Check Azure Functions Core Tools version
- Review function execution history in Azure Portal

## Security Best Practices

1. **Never commit `local.settings.json`** - It's in `.gitignore`
2. **Use Azure Key Vault** for production credentials
3. **Enable Managed Identity** for Azure resources (Event Hub authentication)
4. **Use OAuth 2.0** instead of basic authentication when possible for ServiceNow
5. **Implement rate limiting** if processing large volumes
6. **Use Shared Access Signatures (SAS)** for Event Hub with minimum required permissions (Send only)

## Additional Resources

- [Azure Functions Python Developer Guide](https://learn.microsoft.com/azure/azure-functions/functions-reference-python)
- [Azure Event Hubs Python SDK](https://learn.microsoft.com/python/api/overview/azure/eventhub-readme)
- [ServiceNow REST API Documentation](https://developer.servicenow.com/dev.do#!/reference/api/latest/rest/)
- [Azure Functions Timer Trigger](https://learn.microsoft.com/azure/azure-functions/functions-bindings-timer)
- [Azure Event Hubs Overview](https://learn.microsoft.com/azure/event-hubs/event-hubs-about)

## License

MIT
