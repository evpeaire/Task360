# ServiceNow Sync Tracking with Dataverse

## Overview

The ServiceNow sync function now tracks all API calls in a Dataverse table called `new_sync`. This ensures that even if some sync attempts fail, no changes are missed when the sync resumes.

## How It Works

### 1. **Sync History Tracking**
- Every time the timer function runs (every 5 minutes), it records the sync attempt in the `new_sync` table
- Each record includes:
  - Timestamp of the sync attempt
  - Whether it was successful or failed
  - Number of records retrieved
  - Error message (if failed)
  - Source system (ServiceNow)

### 2. **Smart Time Window**
- On each sync, the function queries the `new_sync` table to find the last **successful** sync
- Instead of always querying the last 5 minutes, it queries from the last successful sync until now
- This ensures that if a sync fails, the next successful sync will pick up all missed changes

### 3. **Failure Recovery**
Example scenario:
- **12:00 PM** - Sync successful, retrieved 10 records
- **12:05 PM** - Sync failed (network error)
- **12:10 PM** - Sync failed (network error)
- **12:15 PM** - Sync successful
  - Instead of querying last 5 minutes (12:10-12:15), it queries from last success (12:00-12:15)
  - Retrieves all changes including those missed during the failures

## Dataverse Table Schema

### Table: `new_sync`

You already have this table! Just need to add 2 columns (see below).

#### Your Existing Fields:

| Field Name | Type | Description | Status |
|------------|------|-------------|--------|
| `new_newcolumn` | Single Line of Text | Display name (Primary column) | ✅ Already exists |
| `new_Syncsource` | Single Line of Text | Source system name (e.g., "ServiceNow") | ✅ Already exists |
| `new_Lastsynctime` | Date and Time | When the sync attempt occurred | ✅ Already exists |
| `new_numberoftaskchanged` | Whole Number | Number of records retrieved | ✅ Already exists |

#### Fields You Need to Add:

| Field Name | Type | Description | Required |
|------------|------|-------------|----------|
| `new_success` | Yes/No (Boolean) | Whether the sync was successful | Yes |
| `new_errormessage` | Multiple Lines of Text | Error details if sync failed | No |

**See [ADD_MISSING_COLUMNS.md](ADD_MISSING_COLUMNS.md) for step-by-step instructions to add these 2 columns.**

#### Field Properties:

```
new_name:
- Max Length: 200
- Format: Text

new_sourcesystem:
- Max Length: 100
- Format: Text

new_synctime:
- Behavior: User Local
- Format: Date and Time

new_success:
- Default Value: No

new_recordcount:
- Minimum Value: 0
- Maximum Value: 2,147,483,647

new_errormessage:
- Max Length: 4000
- Format: Text
```

## Configuration

### Environment Variables

Add the following to your `local.settings.json` (local development) and Azure Function App Configuration (production):

```json
{
  "DATAVERSE_ENVIRONMENT_URL": "https://orgXXXXXXXX.crm.dynamics.com"
}
```

Replace `orgXXXXXXXX` with your actual Dataverse organization URL.

### Authentication

The function uses `DefaultAzureCredential` which supports:
- **Local Development**: Azure CLI credentials (`az login`)
- **Azure**: Managed Identity

#### Local Development Setup:
1. Install Azure CLI
2. Run: `az login`
3. Ensure you have access to the Dataverse environment

#### Azure Deployment Setup:
1. Enable **System-assigned Managed Identity** on the Function App
2. Grant the Managed Identity the following permissions in Dataverse:
   - System User role or
   - Custom role with read/write access to `new_sync` table

## Creating the Dataverse Table

### Option 1: Power Apps Portal

1. Go to [Power Apps](https://make.powerapps.com)
2. Select your environment (same as `new_task` table)
3. Navigate to **Tables** > **New table** > **Set advanced properties**
4. Configure:
   - **Display name**: Sync History
   - **Plural name**: Sync Histories
   - **Name**: new_sync
   - **Primary column**: new_name
5. Add the fields listed in the schema above
6. Save and publish

### Option 2: Solution Export/Import

Use the Power Platform CLI to export from one environment and import to another.

## Code Changes Summary

### Modified Files:

1. **requirements.txt**
   - Added `pyodbc` for potential SQL connectivity
   - Added `azure-identity` for authentication

2. **function_app.py**
   - Added `DataverseSyncTracker` class
   - Modified `ServiceNowClient.get_recent_changes()` to accept custom start time
   - Updated `servicenow_sync_timer()` to:
     - Query last successful sync from Dataverse
     - Use custom time window for ServiceNow queries
     - Log each sync attempt (success or failure)

3. **local.settings.json**
   - Added `DATAVERSE_ENVIRONMENT_URL` setting

## Testing

### Test Successful Sync:
1. Ensure Dataverse connection is configured
2. Run the function locally or in Azure
3. Check the `new_sync` table for a new record with `success = true`

### Test Failure Recovery:
1. Temporarily disable network or provide invalid credentials
2. Wait for a few failed sync attempts (check logs)
3. Restore connectivity
4. Verify the next successful sync retrieves all missed records
5. Check `new_sync` table shows both failed and successful attempts

### Verify Data:
```sql
-- Query in Dataverse (using FetchXML or OData)
SELECT new_name, new_sourcesystem, new_synctime, new_success, new_recordcount, new_errormessage
FROM new_sync
WHERE new_sourcesystem = 'ServiceNow'
ORDER BY new_synctime DESC
```

## Monitoring and Alerts

### Key Metrics to Monitor:
- Consecutive failed syncs (alert if > 3)
- Time since last successful sync (alert if > 30 minutes)
- Record count trends (alert on anomalies)

### Azure Monitor Queries:

```kusto
// Failed syncs in last hour
traces
| where message contains "ServiceNow sync failed"
| where timestamp > ago(1h)
| project timestamp, message

// Sync success rate
traces
| where message contains "ServiceNow sync"
| summarize total=count(), failures=countif(message contains "failed") by bin(timestamp, 5m)
| extend success_rate = (total - failures) * 100.0 / total
```

## Troubleshooting

### "Could not initialize sync tracker"
- Check `DATAVERSE_ENVIRONMENT_URL` is set correctly
- Verify authentication (Azure CLI login or Managed Identity)
- Ensure the `new_sync` table exists

### "No previous successful sync found"
- This is normal on first run
- Function will use default 5-minute window
- After first successful sync, subsequent runs will use custom window

### "Error logging sync attempt to Dataverse"
- Verify table permissions
- Check field names match exactly (case-sensitive)
- Ensure all required fields are present

### Records Still Missing After Failed Syncs
- Check `new_sync` table for successful sync records
- Verify the `new_synctime` values are correct
- Review function logs for query details

## Best Practices

1. **Monitor the `new_sync` table regularly** - Set up alerts for consecutive failures
2. **Keep the table clean** - Consider archiving old records (> 30 days)
3. **Test failure scenarios** - Regularly verify the recovery mechanism works
4. **Review error messages** - Failed syncs include detailed error information
5. **Set up dashboards** - Create Power BI reports showing sync health metrics

## Future Enhancements

Potential improvements:
- Add table-specific tracking (separate tracking for task vs approval syncs)
- Implement exponential backoff for failed syncs
- Add sync duration metrics
- Create automated cleanup job for old sync records
- Implement sync conflict resolution

## Support

For issues or questions:
- Check Azure Function logs for detailed error messages
- Review `new_sync` table for sync history
- Verify Dataverse connection and permissions
- Ensure ServiceNow API credentials are valid
