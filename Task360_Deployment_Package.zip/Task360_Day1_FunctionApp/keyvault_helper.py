"""
Helper module to retrieve secrets from Azure Key Vault
"""
import os
import logging
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from typing import Optional

class KeyVaultHelper:
    """Helper class to retrieve secrets from Azure Key Vault"""
    
    _client: Optional[SecretClient] = None
    _cache = {}
    
    @classmethod
    def _ensure_client(cls):
        """Initialize the Key Vault client if not already initialized"""
        if cls._client is None:
            keyvault_url = os.environ.get("KEYVAULT_URL")
            if not keyvault_url:
                raise ValueError("KEYVAULT_URL environment variable is not set")
            
            # Use DefaultAzureCredential which works with:
            # - Azure CLI (local development)
            # - Managed Identity (when deployed to Azure)
            # - Visual Studio Code authentication
            credential = DefaultAzureCredential()
            cls._client = SecretClient(vault_url=keyvault_url, credential=credential)
            logging.info(f"✓ Key Vault client initialized: {keyvault_url}")
    
    @classmethod
    def get_secret(cls, secret_name: str) -> str:
        """
        Get a secret from Key Vault with caching
        
        Args:
            secret_name: Name of the secret in Key Vault
            
        Returns:
            Secret value as a string
            
        Raises:
            Exception: If the secret cannot be retrieved
        """
        # Return from cache if available
        if secret_name in cls._cache:
            return cls._cache[secret_name]
        
        cls._ensure_client()
        
        try:
            secret = cls._client.get_secret(secret_name)
            value = secret.value
            
            # Cache the value
            cls._cache[secret_name] = value
            
            logging.debug(f"✓ Retrieved secret from Key Vault: {secret_name}")
            return value
            
        except Exception as e:
            logging.error(f"❌ Failed to retrieve secret '{secret_name}' from Key Vault: {str(e)}")
            raise
    
    @classmethod
    def clear_cache(cls):
        """Clear the secret cache (useful for testing)"""
        cls._cache.clear()
        logging.debug("Key Vault cache cleared")
