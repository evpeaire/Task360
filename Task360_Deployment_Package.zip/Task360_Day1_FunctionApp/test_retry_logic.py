"""
Test script to verify the ServiceNow API retry logic.

This script tests three scenarios:
1. ServiceNow API succeeds on first attempt
2. ServiceNow API fails once, succeeds on retry
3. ServiceNow API fails both attempts (should log failure to Dataverse)
"""

import os
import sys
from unittest.mock import Mock, patch, MagicMock
import requests
from datetime import datetime

# Import the function modules
from function_app import ServiceNowClient, DataverseSyncTracker


def test_scenario_1_success_first_attempt():
    """Test: ServiceNow API succeeds on first attempt"""
    print("\n" + "="*70)
    print("TEST 1: ServiceNow API succeeds on first attempt")
    print("="*70)
    
    with patch.object(ServiceNowClient, '__init__', return_value=None):
        with patch('requests.Session') as mock_session:
            # Setup
            client = ServiceNowClient()
            client.base_url = "https://test.service-now.com/api/now"
            client.session = mock_session.return_value
            client._get_fields_for_table = lambda x: "sys_id,number"
            
            # Mock successful response
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                'result': [
                    {'sys_id': '123', 'number': 'INC001', 'sys_updated_on': '2026-01-29 10:00:00'}
                ]
            }
            mock_response.raise_for_status = Mock()
            client.session.get.return_value = mock_response
            
            # Execute
            try:
                records = client.get_recent_changes('task', minutes_ago=5)
                print(f"✓ SUCCESS: Retrieved {len(records)} records on first attempt")
                print(f"  API call count: {client.session.get.call_count}")
                assert client.session.get.call_count == 1, "Should only call API once"
                assert len(records) == 1, "Should return 1 record"
                print("✓ Test 1 PASSED")
                return True
            except Exception as e:
                print(f"✗ Test 1 FAILED: {e}")
                return False


def test_scenario_2_retry_succeeds():
    """Test: ServiceNow API fails once, succeeds on retry"""
    print("\n" + "="*70)
    print("TEST 2: ServiceNow API fails first, succeeds on retry")
    print("="*70)
    
    with patch.object(ServiceNowClient, '__init__', return_value=None):
        with patch('requests.Session') as mock_session:
            # Setup
            client = ServiceNowClient()
            client.base_url = "https://test.service-now.com/api/now"
            client.session = mock_session.return_value
            client._get_fields_for_table = lambda x: "sys_id,number"
            
            # Mock first call fails, second succeeds
            mock_failure = Mock()
            mock_failure.raise_for_status.side_effect = requests.exceptions.HTTPError("503 Service Unavailable")
            
            mock_success = Mock()
            mock_success.status_code = 200
            mock_success.json.return_value = {
                'result': [
                    {'sys_id': '456', 'number': 'INC002', 'sys_updated_on': '2026-01-29 10:05:00'}
                ]
            }
            mock_success.raise_for_status = Mock()
            
            client.session.get.side_effect = [mock_failure, mock_success]
            
            # Execute
            try:
                records = client.get_recent_changes('task', minutes_ago=5)
                print(f"✓ SUCCESS: Retrieved {len(records)} records after retry")
                print(f"  API call count: {client.session.get.call_count}")
                assert client.session.get.call_count == 2, "Should call API twice (1 failure + 1 retry)"
                assert len(records) == 1, "Should return 1 record"
                print("✓ Test 2 PASSED")
                return True
            except Exception as e:
                print(f"✗ Test 2 FAILED: {e}")
                return False


def test_scenario_3_both_attempts_fail():
    """Test: ServiceNow API fails both attempts"""
    print("\n" + "="*70)
    print("TEST 3: ServiceNow API fails both attempts")
    print("="*70)
    
    with patch.object(ServiceNowClient, '__init__', return_value=None):
        with patch('requests.Session') as mock_session:
            # Setup
            client = ServiceNowClient()
            client.base_url = "https://test.service-now.com/api/now"
            client.session = mock_session.return_value
            client._get_fields_for_table = lambda x: "sys_id,number"
            
            # Mock both calls fail
            mock_failure = Mock()
            mock_failure.raise_for_status.side_effect = requests.exceptions.HTTPError("503 Service Unavailable")
            
            client.session.get.return_value = mock_failure
            
            # Execute
            try:
                records = client.get_recent_changes('task', minutes_ago=5)
                print(f"✗ Test 3 FAILED: Should have raised exception but got {len(records)} records")
                return False
            except requests.exceptions.HTTPError as e:
                print(f"✓ SUCCESS: Exception raised after both attempts failed")
                print(f"  API call count: {client.session.get.call_count}")
                assert client.session.get.call_count == 2, "Should call API twice (2 failures)"
                print(f"  Error message: {str(e)}")
                print("✓ Test 3 PASSED - Exception will be caught by timer function and logged to Dataverse")
                return True
            except Exception as e:
                print(f"✗ Test 3 FAILED with unexpected exception: {e}")
                return False


def test_scenario_4_dataverse_logging():
    """Test: Verify Dataverse logging works when ServiceNow fails"""
    print("\n" + "="*70)
    print("TEST 4: Verify Dataverse failure logging")
    print("="*70)
    
    with patch.object(DataverseSyncTracker, '__init__', return_value=None):
        with patch('requests.post') as mock_post:
            # Setup
            tracker = DataverseSyncTracker()
            tracker.dataverse_env = "https://test.crm.dynamics.com"
            tracker.credential = Mock()
            mock_token = Mock()
            mock_token.token = "fake_token"
            tracker.credential.get_token.return_value = mock_token
            
            # Mock successful Dataverse API call
            mock_response = Mock()
            mock_response.ok = True
            mock_response.status_code = 201
            mock_post.return_value = mock_response
            
            # Execute
            try:
                result = tracker.log_sync_attempt(
                    source_system="ServiceNow",
                    success=False,
                    record_count=0,
                    error_message="503 Service Unavailable: ServiceNow API failed after 2 attempts"
                )
                
                print(f"✓ SUCCESS: Failure logged to Dataverse")
                print(f"  Result: {result}")
                
                # Verify the payload
                call_args = mock_post.call_args
                payload = call_args[1]['json']
                print(f"  Payload sent to Dataverse:")
                print(f"    - Source: {payload.get('new_syncsource')}")
                print(f"    - Success: {payload.get('new_success')}")
                print(f"    - Record Count: {payload.get('new_numberoftaskchanged')}")
                print(f"    - Error Message: {payload.get('new_errormessage')}")
                
                assert payload['new_success'] == False, "Should mark sync as failed"
                assert payload['new_numberoftaskchanged'] == 0, "Should have 0 records"
                assert 'ServiceNow API failed' in payload.get('new_errormessage', ''), "Should contain error message"
                
                print("✓ Test 4 PASSED")
                return True
            except Exception as e:
                print(f"✗ Test 4 FAILED: {e}")
                import traceback
                traceback.print_exc()
                return False


def main():
    """Run all tests"""
    print("\n" + "="*70)
    print("SERVICENOW API RETRY LOGIC TEST SUITE")
    print("="*70)
    
    results = []
    
    # Run tests
    results.append(("Success on first attempt", test_scenario_1_success_first_attempt()))
    results.append(("Retry succeeds on second attempt", test_scenario_2_retry_succeeds()))
    results.append(("Both attempts fail (raises exception)", test_scenario_3_both_attempts_fail()))
    results.append(("Dataverse failure logging", test_scenario_4_dataverse_logging()))
    
    # Summary
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✓ PASSED" if result else "✗ FAILED"
        print(f"{status}: {test_name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n✓ ALL TESTS PASSED! Retry logic is working correctly.")
    else:
        print(f"\n✗ {total - passed} test(s) failed. Please review the output above.")
    
    return passed == total


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
