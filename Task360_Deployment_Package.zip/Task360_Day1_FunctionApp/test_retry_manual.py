"""
Manual test script for ServiceNow API retry logic.

This script lets you manually test the retry behavior by:
1. Using invalid credentials to force API failures
2. Verifying the retry logic kicks in
3. Checking that failures are logged to Dataverse

SETUP:
1. Set temporary invalid ServiceNow credentials in environment variables
2. Run this script to see the retry logic in action
"""

import os
import logging
from function_app import ServiceNowClient, DataverseSyncTracker

# Setup logging to see retry messages
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)


def test_with_invalid_credentials():
    """
    Test retry logic by using invalid ServiceNow credentials.
    This will cause the API to fail and trigger retries.
    """
    print("\n" + "="*70)
    print("MANUAL TEST: ServiceNow API with Invalid Credentials")
    print("="*70)
    print("\nThis test will:")
    print("1. Attempt to connect to ServiceNow with invalid/current credentials")
    print("2. Show retry attempts in the logs")
    print("3. Log the failure to Dataverse")
    print("\nPress Ctrl+C to cancel, or Enter to continue...")
    input()
    
    # Temporarily modify credentials to test failure scenario
    # You can also just use your real credentials if ServiceNow is down/unreachable
    
    print("\n--- Initializing ServiceNow Client ---")
    try:
        sn_client = ServiceNowClient()
        print("✓ ServiceNow client initialized")
    except Exception as e:
        print(f"✗ Failed to initialize ServiceNow client: {e}")
        return
    
    print("\n--- Attempting to fetch records (will retry on failure) ---")
    try:
        records = sn_client.get_recent_changes('task', minutes_ago=5)
        print(f"\n✓ Successfully retrieved {len(records)} records")
        print("Note: If you see retry messages above, the retry logic is working!")
    except Exception as e:
        print(f"\n✓ API failed after retries (expected): {e}")
        print("\nThis is expected behavior - both attempts failed as designed.")
        
        # Now test Dataverse logging
        print("\n--- Testing Dataverse Failure Logging ---")
        try:
            sync_tracker = DataverseSyncTracker()
            print("✓ Dataverse sync tracker initialized")
            
            result = sync_tracker.log_sync_attempt(
                source_system="ServiceNow",
                success=False,
                record_count=0,
                error_message=f"ServiceNow API failed after retries: {str(e)}"
            )
            
            if result:
                print("✓ Failure successfully logged to Dataverse new_sync table!")
                print("\nGo check your Dataverse new_sync table - you should see a new row with:")
                print("  - new_success = false")
                print("  - new_numberoftaskchanged = 0")
                print("  - new_errormessage = (the error from above)")
            else:
                print("✗ Failed to log to Dataverse")
                
        except Exception as dv_error:
            print(f"✗ Dataverse logging error: {dv_error}")


def test_with_valid_credentials():
    """
    Test with valid credentials to see normal operation with potential retries.
    """
    print("\n" + "="*70)
    print("MANUAL TEST: ServiceNow API with Valid Credentials")
    print("="*70)
    print("\nThis test will:")
    print("1. Use your configured ServiceNow credentials")
    print("2. Fetch recent records")
    print("3. Show if any retries occurred")
    print("\nPress Ctrl+C to cancel, or Enter to continue...")
    input()
    
    print("\n--- Initializing ServiceNow Client ---")
    try:
        sn_client = ServiceNowClient()
        print("✓ ServiceNow client initialized")
    except Exception as e:
        print(f"✗ Failed to initialize ServiceNow client: {e}")
        return
    
    print("\n--- Fetching task records ---")
    try:
        records = sn_client.get_recent_changes('task', minutes_ago=5)
        print(f"✓ Successfully retrieved {len(records)} task records")
        
        if len(records) > 0:
            print(f"\nSample record:")
            print(f"  Number: {records[0].get('number')}")
            print(f"  Updated: {records[0].get('sys_updated_on')}")
    except Exception as e:
        print(f"✗ Failed to fetch records: {e}")
        print("Check the logs above to see if retries occurred")


def main():
    print("\n" + "="*70)
    print("SERVICENOW RETRY LOGIC MANUAL TEST")
    print("="*70)
    print("\nChoose a test scenario:")
    print("1. Test with current credentials (see normal operation)")
    print("2. Force failure test (modify credentials temporarily)")
    print("3. Run automated unit tests")
    print("4. Exit")
    
    choice = input("\nEnter choice (1-4): ").strip()
    
    if choice == '1':
        test_with_valid_credentials()
    elif choice == '2':
        print("\n--- Force Failure Test ---")
        print("To force failures, temporarily modify your local.settings.json:")
        print("  - Change SERVICENOW_USERNAME to invalid value, OR")
        print("  - Change SERVICENOW_INSTANCE to invalid value")
        print("\nAfter testing, restore the original values!")
        input("\nPress Enter when ready to test with current settings...")
        test_with_invalid_credentials()
    elif choice == '3':
        print("\nRunning automated unit tests...")
        os.system("python test_retry_logic.py")
    elif choice == '4':
        print("Exiting...")
    else:
        print("Invalid choice")


if __name__ == "__main__":
    main()
