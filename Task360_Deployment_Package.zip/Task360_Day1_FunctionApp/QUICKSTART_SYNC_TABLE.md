# Quick Start: Creating the new_sync Table in Dataverse

## Step 1: Access Power Apps

1. Go to [https://make.powerapps.com](https://make.powerapps.com)
2. Select the **same environment** where your `new_task` table exists
   - This ensures sync tracking is in the same environment as your task data

## Step 2: Create the Table

1. Click **Tables** in the left navigation
2. Click **+ New table** > **Set advanced properties**
3. Configure the table:
   - **Display name**: `Sync History`
   - **Plural name**: `Sync Histories`
   - **Name**: `new_sync`
   - **Primary column name**: `new_name`
   - **Primary column display name**: `Name`
4. Click **Save**

## Step 3: Add Required Fields

Add these fields to the table (click **+ New** > **Column**):

### Field 1: Source System
- **Display name**: `Source System`
- **Name**: `new_sourcesystem`
- **Data type**: Text > Single line of text
- **Required**: Yes
- **Max length**: 100

### Field 2: Sync Time
- **Display name**: `Sync Time`
- **Name**: `new_synctime`
- **Data type**: Date and Time
- **Required**: Yes
- **Behavior**: User Local

### Field 3: Success
- **Display name**: `Success`
- **Name**: `new_success`
- **Data type**: Choice > Yes/No
- **Required**: Yes
- **Default value**: No

### Field 4: Record Count
- **Display name**: `Record Count`
- **Name**: `new_recordcount`
- **Data type**: Whole Number
- **Required**: Yes
- **Minimum value**: 0
- **Maximum value**: 2147483647

### Field 5: Error Message
- **Display name**: `Error Message`
- **Name**: `new_errormessage`
- **Data type**: Text > Multiple lines of text
- **Required**: No
- **Max length**: 4000

## Step 4: Save and Publish

1. Click **Save Table** at the bottom
2. Click **Publish** to make the table available

## Step 5: Update Your Configuration

Update your `local.settings.json` file with your Dataverse environment URL:

```json
{
  "Values": {
    "DATAVERSE_ENVIRONMENT_URL": "https://orgXXXXXXXX.crm.dynamics.com"
  }
}
```

To find your organization URL:
1. In Power Apps, click the **gear icon** (Settings) in the top right
2. Click **Session details**
3. Copy the **Instance url** (e.g., `https://org12345678.crm.dynamics.com`)

## Step 6: Set Up Permissions

For local development:
```powershell
# Login to Azure CLI with your account
az login

# Verify you have access to Dataverse
# Open Power Apps and ensure you can see the new_sync table
```

For Azure deployment:
1. Enable **System-assigned Managed Identity** on your Function App
2. In Power Apps, go to **Settings** > **Users + permissions** > **Users**
3. Click **+ New user** and add the Function App's managed identity
4. Assign appropriate security role (System User or custom role with access to new_sync)

## Step 7: Test the Setup

Run your function locally:
```powershell
func start
```

After it runs, check the `new_sync` table in Power Apps:
1. Go to **Tables** > **Sync History**
2. Click **Data**
3. You should see a new record with:
   - Source System: ServiceNow
   - Sync Time: Current timestamp
   - Success: Yes or No
   - Record Count: Number of records processed
   - Error Message: (empty if successful)

## Troubleshooting

**Error: "Could not initialize sync tracker"**
- Check that `DATAVERSE_ENVIRONMENT_URL` is set correctly
- Verify you're logged in with `az login`
- Ensure the URL format is correct (no trailing slash)

**Error: "Error logging sync attempt to Dataverse"**
- Verify the table name is exactly `new_sync` (case-sensitive)
- Check that all field names match exactly (e.g., `new_sourcesystem`, not `new_SourceSystem`)
- Ensure you have write permissions to the table

**No records appearing in the table**
- Check function logs for any Dataverse-related errors
- Verify the table is published (not just saved)
- Try querying the table using Power Apps to confirm it's accessible

## Next Steps

Once the table is set up and working:
1. Monitor sync history to ensure consistency
2. Set up Power BI reports to visualize sync health
3. Create alerts for consecutive failures
4. Consider implementing data retention policies for old records

For more detailed information, see [SYNC_TRACKING_SETUP.md](SYNC_TRACKING_SETUP.md).
