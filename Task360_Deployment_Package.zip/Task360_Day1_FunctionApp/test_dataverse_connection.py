"""
Test script to verify Dataverse connection and new_sync table access.
Run this before deploying the Azure Function to ensure everything is configured correctly.
"""

import os
import sys
from datetime import datetime
import requests
from azure.identity import DefaultAzureCredential

def test_dataverse_connection():
    """Test connection to Dataverse and access to new_sync table"""
    
    print("=" * 60)
    print("Dataverse Connection Test")
    print("=" * 60)
    print()
    
    # Check environment variables
    print("1. Checking environment variables...")
    dataverse_url = os.environ.get("DATAVERSE_ENVIRONMENT_URL")
    
    if not dataverse_url:
        print("   ❌ DATAVERSE_ENVIRONMENT_URL is not set")
        print("   Set it in local.settings.json or environment variables")
        return False
    
    print(f"   ✓ DATAVERSE_ENVIRONMENT_URL: {dataverse_url}")
    print()
    
    # Normalize URL
    if not dataverse_url.startswith('http'):
        dataverse_url = f'https://{dataverse_url}'
    dataverse_url = dataverse_url.rstrip('/')
    
    # Test authentication
    print("2. Testing Azure authentication...")
    try:
        credential = DefaultAzureCredential()
        token = credential.get_token(f"{dataverse_url}/.default")
        print(f"   ✓ Successfully obtained access token")
        print(f"   Token expires: {datetime.fromtimestamp(token.expires_on).isoformat()}")
    except Exception as e:
        print(f"   ❌ Failed to authenticate: {str(e)}")
        print("   Make sure you're logged in with 'az login'")
        return False
    print()
    
    # Test table access
    print("3. Testing access to new_sync table...")
    try:
        api_url = f"{dataverse_url}/api/data/v9.2/new_syncs"
        headers = {
            'Authorization': f'Bearer {token.token}',
            'Accept': 'application/json',
            'OData-MaxVersion': '4.0',
            'OData-Version': '4.0'
        }
        
        # Try to read records (limit to 1 for testing)
        params = {'$top': '1'}
        response = requests.get(api_url, headers=headers, params=params)
        
        if response.status_code == 200:
            data = response.json()
            record_count = len(data.get('value', []))
            print(f"   ✓ Successfully accessed new_sync table")
            print(f"   Current records in table: {record_count}")
        elif response.status_code == 404:
            print(f"   ❌ Table 'new_sync' not found")
            print(f"   Make sure the table exists in Dataverse")
            print(f"   See QUICKSTART_SYNC_TABLE.md for setup instructions")
            return False
        else:
            print(f"   ❌ Failed to access table: HTTP {response.status_code}")
            print(f"   Response: {response.text}")
            return False
    except Exception as e:
        print(f"   ❌ Error accessing table: {str(e)}")
        return False
    print()
    
    # Test write access
    print("4. Testing write access to new_sync table...")
    try:
        api_url = f"{dataverse_url}/api/data/v9.2/new_syncs"
        headers = {
            'Authorization': f'Bearer {token.token}',
            'Accept': 'application/json',
            'OData-MaxVersion': '4.0',
            'OData-Version': '4.0',
            'Content-Type': 'application/json'
        }
        
        # Create a test record
        test_payload = {
            'new_newcolumn': f'Connection Test - {datetime.utcnow().isoformat()}',
            'new_Syncsource': 'Test',
            'new_Lastsynctime': datetime.utcnow().isoformat() + 'Z',
            'new_success': True,
            'new_numberoftaskchanged': 0,
            'new_errormessage': 'This is a connection test record'
        }
        
        response = requests.post(api_url, headers=headers, json=test_payload)
        
        if response.status_code == 204 or response.status_code == 201:
            print(f"   ✓ Successfully created test record")
            print(f"   Check Power Apps to see the test record in new_sync table")
        else:
            print(f"   ❌ Failed to create record: HTTP {response.status_code}")
            print(f"   Response: {response.text}")
            return False
    except Exception as e:
        print(f"   ❌ Error creating record: {str(e)}")
        return False
    print()
    
    print("=" * 60)
    print("✓ All tests passed!")
    print("=" * 60)
    print()
    print("Your Dataverse connection is configured correctly.")
    print("You can now run the Azure Function with sync tracking enabled.")
    print()
    
    return True

if __name__ == "__main__":
    try:
        success = test_dataverse_connection()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\nTest cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {str(e)}")
        sys.exit(1)
