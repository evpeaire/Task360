"""
Integration test to verify that ServiceNow failures are logged to Dataverse.

This test actually connects to Dataverse to verify the logging works end-to-end.
"""

import os
import logging
from datetime import datetime
from function_app import DataverseSyncTracker

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)


def test_dataverse_failure_logging():
    """
    Test that we can actually log a failure to Dataverse.
    This is an integration test that requires valid Dataverse credentials.
    """
    print("\n" + "="*70)
    print("INTEGRATION TEST: Log ServiceNow Failure to Dataverse")
    print("="*70)
    
    print("\nThis test will:")
    print("1. Connect to your actual Dataverse instance")
    print("2. Write a test failure record to the new_sync table")
    print("3. Verify the record was created")
    print("\nMake sure your Dataverse credentials are set in local.settings.json")
    print("\nPress Ctrl+C to cancel, or Enter to continue...")
    input()
    
    try:
        # Initialize Dataverse sync tracker
        print("\n--- Step 1: Initialize Dataverse Sync Tracker ---")
        sync_tracker = DataverseSyncTracker()
        print("✓ Dataverse sync tracker initialized successfully")
        print(f"  Environment URL: {sync_tracker.dataverse_env or sync_tracker.dataverse_url}")
        
        # Test logging a failure
        print("\n--- Step 2: Log a Test Failure to Dataverse ---")
        test_error_message = f"TEST FAILURE - ServiceNow API failed after 2 retry attempts (tested at {datetime.utcnow().isoformat()})"
        
        result = sync_tracker.log_sync_attempt(
            source_system="ServiceNow",
            success=False,
            record_count=0,
            error_message=test_error_message
        )
        
        if result:
            print("✓ Test failure record logged to Dataverse successfully!")
            print("\n--- Step 3: Verify in Dataverse ---")
            print("Go to your Dataverse environment and check the 'new_sync' table.")
            print("You should see a new record with:")
            print(f"  • new_syncsource: ServiceNow")
            print(f"  • new_success: No/False")
            print(f"  • new_numberoftaskchanged: 0")
            print(f"  • new_errormessage: {test_error_message}")
            print(f"  • new_lastsynctime: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}")
            
            # Try to read it back
            print("\n--- Step 4: Query Last Sync from Dataverse ---")
            last_sync = sync_tracker.get_last_successful_sync("ServiceNow")
            if last_sync:
                print(f"✓ Last successful sync time: {last_sync}")
                print("  Note: This returns the last SUCCESSFUL sync, not our test failure")
            else:
                print("  No successful sync found (expected if you only have failure records)")
            
            print("\n" + "="*70)
            print("✓ INTEGRATION TEST PASSED")
            print("="*70)
            print("\nThe retry logic will work correctly:")
            print("  1. ServiceNow API fails on first attempt")
            print("  2. Retry logic kicks in (second attempt)")
            print("  3. If both fail, exception is raised")
            print("  4. Exception caught by timer function")
            print("  5. Failure logged to Dataverse (as demonstrated above)")
            return True
        else:
            print("✗ Failed to log test failure to Dataverse")
            print("\nCheck the logs above for error details.")
            print("Common issues:")
            print("  • Invalid Dataverse credentials")
            print("  • Insufficient permissions on new_sync table")
            print("  • Network connectivity issues")
            return False
            
    except Exception as e:
        print(f"\n✗ INTEGRATION TEST FAILED")
        print(f"Error: {str(e)}")
        print("\nPossible issues:")
        print("  • Dataverse environment variables not set correctly:")
        print("    - DATAVERSE_ENVIRONMENT_URL or DATAVERSE_URL")
        print("    - DATAVERSE_CLIENT_ID")
        print("    - DATAVERSE_CLIENT_SECRET")
        print("    - DATAVERSE_TENANT_ID")
        print("  • Dataverse new_sync table doesn't exist")
        print("  • Permission issues")
        
        import traceback
        print("\nFull error traceback:")
        traceback.print_exc()
        return False


def test_manual_trigger_with_bad_servicenow():
    """
    Manually trigger a sync with intentionally bad ServiceNow credentials
    to see the full end-to-end failure logging.
    """
    print("\n" + "="*70)
    print("END-TO-END TEST: ServiceNow Failure with Dataverse Logging")
    print("="*70)
    
    print("\nThis test simulates a real failure scenario:")
    print("1. Make ServiceNow credentials invalid (or ServiceNow is down)")
    print("2. Attempt to sync (will fail twice due to retry logic)")
    print("3. Failure gets logged to Dataverse")
    print("\nTo run this test:")
    print("  1. Temporarily edit local.settings.json")
    print("  2. Change SERVICENOW_INSTANCE to 'invalid.service-now.com'")
    print("  3. Press Enter to run the test")
    print("  4. Restore the original value after testing")
    print("\nPress Ctrl+C to cancel, or Enter to continue...")
    input()
    
    from function_app import ServiceNowClient, EventHubSender
    
    event_hub_sender = None
    sync_tracker = None
    total_records = 0
    sync_successful = False
    error_message = None
    
    try:
        print("\n--- Initializing Clients ---")
        sn_client = ServiceNowClient()
        print("✓ ServiceNow client initialized")
        
        event_hub_sender = EventHubSender()
        print("✓ Event Hub sender initialized")
        
        sync_tracker = DataverseSyncTracker()
        print("✓ Dataverse sync tracker initialized")
        
        print("\n--- Attempting ServiceNow API Call (with retries) ---")
        print("Watch for retry messages...")
        
        # This will trigger the retry logic
        task_records = sn_client.get_recent_changes('task', minutes_ago=5)
        
        print(f"✓ Retrieved {len(task_records)} records")
        total_records = len(task_records)
        sync_successful = True
        
    except Exception as e:
        sync_successful = False
        error_message = str(e)
        print(f"\n✓ Exception caught (expected): {error_message}")
        
    finally:
        print("\n--- Logging Result to Dataverse ---")
        if sync_tracker:
            try:
                result = sync_tracker.log_sync_attempt(
                    source_system="ServiceNow",
                    success=sync_successful,
                    record_count=total_records,
                    error_message=error_message
                )
                
                if result:
                    print(f"✓ Sync attempt logged to Dataverse")
                    print(f"  Success: {sync_successful}")
                    print(f"  Records: {total_records}")
                    if error_message:
                        print(f"  Error: {error_message}")
                    
                    print("\n" + "="*70)
                    print("✓ END-TO-END TEST COMPLETED")
                    print("="*70)
                    print("\nCheck your Dataverse new_sync table to verify the failure was logged.")
                else:
                    print("✗ Failed to log to Dataverse")
                    
            except Exception as e:
                print(f"✗ Error logging to Dataverse: {str(e)}")
        
        if event_hub_sender:
            event_hub_sender.close_all()


def main():
    print("\n" + "="*70)
    print("DATAVERSE INTEGRATION TESTS")
    print("="*70)
    print("\nChoose a test:")
    print("1. Test Dataverse failure logging only (quick)")
    print("2. Full end-to-end test with ServiceNow failure simulation")
    print("3. Exit")
    
    choice = input("\nEnter choice (1-3): ").strip()
    
    if choice == '1':
        success = test_dataverse_failure_logging()
        return success
    elif choice == '2':
        test_manual_trigger_with_bad_servicenow()
        return True
    elif choice == '3':
        print("Exiting...")
        return True
    else:
        print("Invalid choice")
        return False


if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)
